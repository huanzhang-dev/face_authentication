param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectPath
)

$ErrorActionPreference = "Stop"

$ProjectPath = (Resolve-Path -LiteralPath $ProjectPath).Path
if (-not (Test-Path -LiteralPath (Join-Path $ProjectPath "FaceAttendance.sln"))) {
    throw "ProjectPath must be the folder that contains FaceAttendance.sln."
}

$SourceRoot = Join-Path $PSScriptRoot "face_final"
if (-not (Test-Path -LiteralPath (Join-Path $SourceRoot "Camera.cpp"))) {
    throw "Patch source folder is missing: $SourceRoot"
}

$Files = @(
    "Camera.cpp",
    "Camera.h",
    "main.cpp",
    "Engine.cpp",
    "README.md",
    "CAMERA_UPGRADE_NOTES.md",
    "CAMERA_UPGRADE_CHANGELOG.md",
    "docs\CODE_WALKTHROUGH.md"
)

$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$ProjectName = Split-Path -Leaf $ProjectPath
$BackupRoot = Join-Path (Split-Path -Parent $ProjectPath) ($ProjectName + "_backup_camera_upgrade_" + $Stamp)
New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null

foreach ($RelativePath in $Files) {
    $Source = Join-Path $SourceRoot $RelativePath
    if (-not (Test-Path -LiteralPath $Source)) {
        throw "Patch file is missing: $Source"
    }

    $Destination = Join-Path $ProjectPath $RelativePath
    $DestinationDir = Split-Path -Parent $Destination
    New-Item -ItemType Directory -Path $DestinationDir -Force | Out-Null

    if (Test-Path -LiteralPath $Destination) {
        $Backup = Join-Path $BackupRoot $RelativePath
        New-Item -ItemType Directory -Path (Split-Path -Parent $Backup) -Force | Out-Null
        Copy-Item -LiteralPath $Destination -Destination $Backup -Force
    }

    Copy-Item -LiteralPath $Source -Destination $Destination -Force
    Write-Host "Updated: $RelativePath"
}

Write-Host ""
Write-Host "Camera upgrade patch applied."
Write-Host "Backup: $BackupRoot"
Write-Host "Next: build FaceAttendance.sln in Visual Studio (Release | x64)."
