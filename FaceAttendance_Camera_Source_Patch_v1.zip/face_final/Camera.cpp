#include "Camera.h"
#include "Util.h"
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <mferror.h>
#include <wrl/client.h>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <sstream>

using Microsoft::WRL::ComPtr;

// MFStartup is process-wide. C++11 guarantees thread-safe initialization of this local static.
static bool ensureMF()
{
    static const HRESULT startupResult = MFStartup(MF_VERSION);
    return SUCCEEDED(startupResult);
}

// KSCATEGORY_SENSOR_CAMERA: where Windows lists some Windows-Hello-style IR cameras.
// A UVC day/night camera may instead appear in the normal video-capture category.
static const GUID kSensorCamera =
    { 0x24e552d7, 0x6523, 0x47f7, { 0xa6, 0x47, 0xd3, 0x46, 0x5b, 0xf1, 0xf5, 0xca } };

static void enumCategory(bool sensor, std::vector<CameraInfo> &out)
{
    ComPtr<IMFAttributes> a;
    if (FAILED(MFCreateAttributes(&a, 2))) return;
    if (FAILED(a->SetGUID(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE,
                          MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_GUID))) return;
#ifdef NTDDI_WIN10_TH2
    if (sensor && FAILED(a->SetGUID(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_CATEGORY,
                                    kSensorCamera))) return;
#else
    if (sensor) return; // An older Windows SDK cannot request the sensor-camera category.
#endif

    IMFActivate **devs = 0;
    UINT32 n = 0;
    if (FAILED(MFEnumDeviceSources(a.Get(), &devs, &n))) return;

    for (UINT32 i = 0; i < n; ++i) {
        CameraInfo ci;
        ci.sensor = sensor;
        WCHAR *s = 0;
        UINT32 len = 0;
        if (SUCCEEDED(devs[i]->GetAllocatedString(MF_DEVSOURCE_ATTRIBUTE_FRIENDLY_NAME, &s, &len))) {
            ci.name = s;
            CoTaskMemFree(s);
        }
        s = 0;
        if (SUCCEEDED(devs[i]->GetAllocatedString(
                MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_SYMBOLIC_LINK, &s, &len))) {
            ci.link = s;
            CoTaskMemFree(s);
        }
        devs[i]->Release();

        bool dup = false;
        for (size_t k = 0; k < out.size(); ++k) {
            if (out[k].link == ci.link) { dup = true; break; }
        }
        if (!dup && !ci.link.empty()) {
            if (sensor) ci.name += L"  [IR]";
            out.push_back(ci);
        }
    }
    CoTaskMemFree(devs);
}

std::vector<CameraInfo> listCameras()
{
    std::vector<CameraInfo> v;
    if (!ensureMF()) return v;
    enumCategory(false, v);
    enumCategory(true, v);
    return v;
}

// ------------------------------------------------------------------ pixel conversion
static inline unsigned char clamp8(int v)
{
    return static_cast<unsigned char>(v < 0 ? 0 : (v > 255 ? 255 : v));
}

static inline void yuv2rgb(int y, int u, int v, unsigned char *p)
{
    int c = y - 16, d = u - 128, e = v - 128;
    p[0] = clamp8((298 * c + 409 * e + 128) >> 8);
    p[1] = clamp8((298 * c - 100 * d - 208 * e + 128) >> 8);
    p[2] = clamp8((298 * c + 516 * d + 128) >> 8);
}

enum PixFmt { FMT_UNKNOWN, FMT_RGB32, FMT_RGB24, FMT_YUY2, FMT_NV12, FMT_L8, FMT_L16 };

static PixFmt fmtOf(const GUID &g)
{
    if (g == MFVideoFormat_RGB32 || g == MFVideoFormat_ARGB32) return FMT_RGB32;
    if (g == MFVideoFormat_RGB24) return FMT_RGB24;
    if (g == MFVideoFormat_YUY2)  return FMT_YUY2;
    if (g == MFVideoFormat_NV12)  return FMT_NV12;
    if (g == MFVideoFormat_L8)    return FMT_L8;
    if (g == MFVideoFormat_L16)   return FMT_L16;
    return FMT_UNKNOWN;
}

static const char *formatName(PixFmt f)
{
    switch (f) {
    case FMT_RGB32: return "RGB32";
    case FMT_RGB24: return "RGB24";
    case FMT_YUY2:  return "YUY2";
    case FMT_NV12:  return "NV12";
    case FMT_L8:    return "L8";
    case FMT_L16:   return "L16";
    default:        return "unknown";
    }
}

static const char *subtypeName(const GUID &g)
{
    if (g == MFVideoFormat_MJPG) return "MJPEG";
    if (g == MFVideoFormat_YUY2) return "YUY2";
    if (g == MFVideoFormat_NV12) return "NV12";
    if (g == MFVideoFormat_RGB32 || g == MFVideoFormat_ARGB32) return "RGB32";
    if (g == MFVideoFormat_RGB24) return "RGB24";
    if (g == MFVideoFormat_L8) return "L8";
    if (g == MFVideoFormat_L16) return "L16";
    return "other";
}

// stride: signed bytes per row. A negative RGB stride means bottom-up storage.
static bool convertFrame(const BYTE *p, DWORD len, int w, int h, LONG stride, PixFmt f, RgbImage &out)
{
    if (!p || w <= 0 || h <= 0 || stride == 0) return false;
    const LONG absStride = stride < 0 ? -stride : stride;
    const size_t rowBytes = static_cast<size_t>(absStride);
    const bool flip = stride < 0;

    if (w > 8192 || h > 8192) return false;
    if (f == FMT_RGB32 && rowBytes < static_cast<size_t>(w) * 4) return false;
    if (f == FMT_RGB24 && rowBytes < static_cast<size_t>(w) * 3) return false;
    if (f == FMT_YUY2 && rowBytes < static_cast<size_t>(w) * 2) return false;
    if (f == FMT_NV12 && rowBytes < static_cast<size_t>(w)) return false;
    if (f == FMT_L8 && rowBytes < static_cast<size_t>(w)) return false;
    if (f == FMT_L16 && rowBytes < static_cast<size_t>(w) * 2) return false;

    size_t need = rowBytes * static_cast<size_t>(h);
    if (f == FMT_NV12) need += rowBytes * static_cast<size_t>((h + 1) / 2);
    if (need > len) return false;

    out.w = w;
    out.h = h;
    out.data.resize(static_cast<size_t>(w) * static_cast<size_t>(h) * 3);
    unsigned char *dst = &out.data[0];

    for (int y = 0; y < h; ++y) {
        const int sy = flip ? (h - 1 - y) : y;
        const BYTE *row = p + rowBytes * static_cast<size_t>(sy);
        unsigned char *d = dst + static_cast<size_t>(y) * w * 3;

        switch (f) {
        case FMT_RGB32:
            for (int x = 0; x < w; ++x, d += 3) {
                d[0] = row[x * 4 + 2]; d[1] = row[x * 4 + 1]; d[2] = row[x * 4];
            }
            break;
        case FMT_RGB24:
            for (int x = 0; x < w; ++x, d += 3) {
                d[0] = row[x * 3 + 2]; d[1] = row[x * 3 + 1]; d[2] = row[x * 3];
            }
            break;
        case FMT_YUY2: {
            int x = 0;
            for (; x + 1 < w; x += 2, d += 6) {
                const BYTE *q = row + x * 2; // Y0 U Y1 V
                yuv2rgb(q[0], q[1], q[3], d);
                yuv2rgb(q[2], q[1], q[3], d + 3);
            }
            if (x < w) {
                const BYTE *q = row + x * 2;
                yuv2rgb(q[0], q[1], q[3], d);
            }
            break;
        }
        case FMT_NV12: {
            const int uvRows = (h + 1) / 2;
            const int uvY = flip ? (uvRows - 1 - y / 2) : (y / 2);
            const BYTE *uv = p + rowBytes * static_cast<size_t>(h)
                               + rowBytes * static_cast<size_t>(uvY);
            for (int x = 0; x < w; ++x, d += 3) {
                const int uvX = (x / 2) * 2;
                yuv2rgb(row[x], uv[uvX], uv[uvX + 1], d);
            }
            break;
        }
        case FMT_L8:
            for (int x = 0; x < w; ++x, d += 3) d[0] = d[1] = d[2] = row[x];
            break;
        case FMT_L16:
            for (int x = 0; x < w; ++x, d += 3) d[0] = d[1] = d[2] = row[x * 2 + 1];
            break;
        default:
            return false;
        }
    }
    return true;
}

// ------------------------------------------------------------------ capture-mode selection
struct NativeMode
{
    ComPtr<IMFMediaType> type;
    UINT32 w, h, fpsN, fpsD;
    double fps;
    GUID subtype;
    long long score;
    NativeMode() : w(0), h(0), fpsN(0), fpsD(0), fps(0.0), subtype(GUID_NULL), score(0) {}
};

static int nativeFormatRank(const GUID &g)
{
    // MJPEG is preferred for USB bandwidth; the Source Reader should decode it to RGB32.
    if (g == MFVideoFormat_MJPG) return 0;
    if (g == MFVideoFormat_YUY2) return 1;
    if (g == MFVideoFormat_NV12) return 2;
    if (g == MFVideoFormat_RGB32 || g == MFVideoFormat_ARGB32) return 3;
    if (g == MFVideoFormat_RGB24) return 4;
    if (g == MFVideoFormat_L8) return 5;
    if (g == MFVideoFormat_L16) return 6;
    return 10;
}

static long long modeScore(const NativeMode &m)
{
    const bool rateUsable = (m.fps <= 0.0 || m.fps >= 25.0);
    int tier = 3;
    if (rateUsable && m.w == 1920 && m.h == 1080) tier = 0;
    else if (rateUsable && m.w >= 1280 && m.h >= 720 &&
             m.w <= 1920 && m.h <= 1080) tier = 1;
    else if (rateUsable && m.w >= 640 && m.h >= 480 &&
             m.w <= 1280 && m.h <= 720) tier = 2;

    const long long sizePenalty =
        std::llabs(static_cast<long long>(m.w) - 1920LL) +
        std::llabs(static_cast<long long>(m.h) - 1080LL);
    const long long fpsPenalty = m.fps > 0.0
        ? static_cast<long long>(std::fabs(m.fps - 30.0) * 100.0 + 0.5) : 1000LL;

    return static_cast<long long>(tier) * 1000000000000LL
         + sizePenalty * 10000LL
         + fpsPenalty * 10LL
         + nativeFormatRank(m.subtype);
}

static HRESULT makeOutputType(IMFSourceReader *reader, DWORD stream,
                              IMFMediaType *native, const GUID &subtype,
                              ComPtr<IMFMediaType> &current)
{
    // Reset to this native mode before each output-format attempt.
    HRESULT hr = reader->SetCurrentMediaType(stream, 0, native);
    if (FAILED(hr)) return hr;

    ComPtr<IMFMediaType> output;
    hr = MFCreateMediaType(&output);
    if (FAILED(hr)) return hr;

    UINT32 w = 0, h = 0;
    hr = MFGetAttributeSize(native, MF_MT_FRAME_SIZE, &w, &h);
    if (FAILED(hr)) return hr;

    output->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
    output->SetGUID(MF_MT_SUBTYPE, subtype);
    MFSetAttributeSize(output.Get(), MF_MT_FRAME_SIZE, w, h);

    UINT32 n = 0, d = 0;
    if (SUCCEEDED(MFGetAttributeRatio(native, MF_MT_FRAME_RATE, &n, &d)) && n && d)
        MFSetAttributeRatio(output.Get(), MF_MT_FRAME_RATE, n, d);

    if (SUCCEEDED(MFGetAttributeRatio(native, MF_MT_PIXEL_ASPECT_RATIO, &n, &d)) && n && d)
        MFSetAttributeRatio(output.Get(), MF_MT_PIXEL_ASPECT_RATIO, n, d);

    UINT32 interlace = 0;
    if (SUCCEEDED(native->GetUINT32(MF_MT_INTERLACE_MODE, &interlace)))
        output->SetUINT32(MF_MT_INTERLACE_MODE, interlace);
    else
        output->SetUINT32(MF_MT_INTERLACE_MODE, MFVideoInterlace_Progressive);

    hr = reader->SetCurrentMediaType(stream, 0, output.Get());
    if (FAILED(hr)) return hr;
    return reader->GetCurrentMediaType(stream, &current);
}

static bool chooseOutputType(IMFSourceReader *reader, DWORD stream,
                             const NativeMode &native, ComPtr<IMFMediaType> &selected,
                             PixFmt &selectedFmt)
{
    const GUID outputs[] = {
        MFVideoFormat_RGB32,
        MFVideoFormat_RGB24,
        MFVideoFormat_YUY2,
        MFVideoFormat_NV12,
        MFVideoFormat_L8,
        MFVideoFormat_L16
    };

    for (size_t i = 0; i < sizeof(outputs) / sizeof(outputs[0]); ++i) {
        ComPtr<IMFMediaType> current;
        if (SUCCEEDED(makeOutputType(reader, stream, native.type.Get(), outputs[i], current))) {
            GUID actual = GUID_NULL;
            if (SUCCEEDED(current->GetGUID(MF_MT_SUBTYPE, &actual))) {
                PixFmt f = fmtOf(actual);
                if (f != FMT_UNKNOWN) {
                    selected = current;
                    selectedFmt = f;
                    return true;
                }
            }
        }
    }

    // Last resort: accept a native format that this application can convert itself.
    if (SUCCEEDED(reader->SetCurrentMediaType(stream, 0, native.type.Get()))) {
        ComPtr<IMFMediaType> current;
        if (SUCCEEDED(reader->GetCurrentMediaType(stream, &current))) {
            GUID actual = GUID_NULL;
            if (SUCCEEDED(current->GetGUID(MF_MT_SUBTYPE, &actual))) {
                PixFmt f = fmtOf(actual);
                if (f != FMT_UNKNOWN) {
                    selected = current;
                    selectedFmt = f;
                    return true;
                }
            }
        }
    }
    return false;
}

// ------------------------------------------------------------------ Camera
struct Camera::Impl
{
    ComPtr<IMFMediaSource> source;
    ComPtr<IMFSourceReader> reader;
    int w, h;
    LONG stride;
    PixFmt fmt;
    double fps;
    std::string description;
    Impl() : w(0), h(0), stride(0), fmt(FMT_UNKNOWN), fps(0.0) {}
};

Camera::Camera() : m_impl(0), m_running(false), m_seq(0) {}
Camera::~Camera() { stop(); }

bool Camera::start(const CameraInfo &info, std::string &err)
{
    stop();
    if (!ensureMF()) {
        err = "Media Foundation startup failed";
        return false;
    }

    Impl *im = new Impl;

    ComPtr<IMFAttributes> a;
    HRESULT hr = MFCreateAttributes(&a, 3);
    if (FAILED(hr)) { err = "cannot create camera attributes"; delete im; return false; }

    a->SetGUID(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE,
               MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_GUID);
    a->SetString(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_SYMBOLIC_LINK, info.link.c_str());
#ifdef NTDDI_WIN10_TH2
    if (info.sensor) a->SetGUID(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_CATEGORY, kSensorCamera);
#endif

    hr = MFCreateDeviceSource(a.Get(), &im->source);
    if (FAILED(hr)) {
        err = "cannot open the camera (it may be in use or unavailable)";
        delete im;
        return false;
    }

    ComPtr<IMFAttributes> ra;
    hr = MFCreateAttributes(&ra, 2);
    if (FAILED(hr)) { err = "cannot create Source Reader attributes"; delete im; return false; }

    // Let Media Foundation insert video processing / decoder transforms where available.
    ra->SetUINT32(MF_SOURCE_READER_ENABLE_VIDEO_PROCESSING, TRUE);
    hr = MFCreateSourceReaderFromMediaSource(im->source.Get(), ra.Get(), &im->reader);
    if (FAILED(hr)) {
        err = "cannot create the Media Foundation Source Reader";
        delete im;
        return false;
    }

    const DWORD stream = MF_SOURCE_READER_FIRST_VIDEO_STREAM;
    std::vector<NativeMode> modes;

    for (DWORD i = 0;; ++i) {
        ComPtr<IMFMediaType> t;
        if (FAILED(im->reader->GetNativeMediaType(stream, i, &t))) break;

        NativeMode m;
        m.type = t;
        if (FAILED(MFGetAttributeSize(t.Get(), MF_MT_FRAME_SIZE, &m.w, &m.h))) continue;
        if (m.w < 320 || m.h < 240 || m.w > 8192 || m.h > 8192) continue;

        t->GetGUID(MF_MT_SUBTYPE, &m.subtype);
        if (SUCCEEDED(MFGetAttributeRatio(t.Get(), MF_MT_FRAME_RATE, &m.fpsN, &m.fpsD)) &&
            m.fpsN && m.fpsD) {
            m.fps = static_cast<double>(m.fpsN) / m.fpsD;
        }
        m.score = modeScore(m);
        modes.push_back(m);
    }

    if (modes.empty()) {
        err = "camera exposes no usable video modes";
        delete im;
        return false;
    }

    std::sort(modes.begin(), modes.end(),
        [](const NativeMode &x, const NativeMode &y) { return x.score < y.score; });

    ComPtr<IMFMediaType> cur;
    GUID nativeSubtype = GUID_NULL;
    bool selected = false;

    for (size_t i = 0; i < modes.size(); ++i) {
        PixFmt f = FMT_UNKNOWN;
        if (chooseOutputType(im->reader.Get(), stream, modes[i], cur, f)) {
            im->fmt = f;
            nativeSubtype = modes[i].subtype;
            selected = true;
            break;
        }
    }

    if (!selected || !cur) {
        err = "no usable capture mode: Media Foundation could not decode or convert the camera formats";
        delete im;
        return false;
    }

    UINT32 w = 0, h = 0;
    if (FAILED(MFGetAttributeSize(cur.Get(), MF_MT_FRAME_SIZE, &w, &h)) || !w || !h) {
        err = "Media Foundation returned an invalid capture resolution";
        delete im;
        return false;
    }

    GUID outputSubtype = GUID_NULL;
    if (FAILED(cur->GetGUID(MF_MT_SUBTYPE, &outputSubtype))) {
        err = "Media Foundation did not report the output pixel format";
        delete im;
        return false;
    }

    im->w = static_cast<int>(w);
    im->h = static_cast<int>(h);

    UINT32 fn = 0, fd = 0;
    if (SUCCEEDED(MFGetAttributeRatio(cur.Get(), MF_MT_FRAME_RATE, &fn, &fd)) && fn && fd)
        im->fps = static_cast<double>(fn) / fd;

    UINT32 strideValue = 0;
    LONG stride = 0;
    if (SUCCEEDED(cur->GetUINT32(MF_MT_DEFAULT_STRIDE, &strideValue))) {
        stride = static_cast<LONG>(static_cast<INT32>(strideValue));
    } else if (FAILED(MFGetStrideForBitmapInfoHeader(outputSubtype.Data1, w, &stride))) {
        // RGB32 / RGB24 are normally DWORD-aligned; positive stride is the safe fallback.
        if (im->fmt == FMT_RGB32) stride = static_cast<LONG>(w) * 4;
        else if (im->fmt == FMT_RGB24) stride = static_cast<LONG>((w * 3 + 3) & ~3);
        else if (im->fmt == FMT_YUY2) stride = static_cast<LONG>(w) * 2;
        else if (im->fmt == FMT_NV12) stride = static_cast<LONG>(w);
        else if (im->fmt == FMT_L16) stride = static_cast<LONG>(w) * 2;
        else stride = static_cast<LONG>(w);
    }
    im->stride = stride;

    std::ostringstream desc;
    desc << im->w << "x" << im->h;
    if (im->fps > 0.0) desc << " @ " << static_cast<int>(im->fps + 0.5) << " fps";
    desc << ", output " << formatName(im->fmt) << ", native " << subtypeName(nativeSubtype);
    if (info.sensor) desc << ", Windows sensor-camera category";
    im->description = desc.str();

    m_impl = im;
    m_running = true;
    m_thread = std::thread(&Camera::captureLoop, this);
    err = im->description; // On success, err carries the selected mode for the status line.
    return true;
}

std::string Camera::captureDescription() const
{
    return m_impl ? m_impl->description : std::string();
}

void Camera::stop()
{
    m_running = false;
    if (m_thread.joinable()) m_thread.join();
    if (m_impl) {
        if (m_impl->source) m_impl->source->Shutdown();
        delete m_impl;
        m_impl = 0;
    }
}

void Camera::captureLoop()
{
    const HRESULT comHr = CoInitializeEx(0, COINIT_MULTITHREADED);
    Impl *im = m_impl;
    while (m_running) {
        DWORD idx = 0, flags = 0;
        LONGLONG ts = 0;
        ComPtr<IMFSample> sample;
        HRESULT hr = im->reader->ReadSample(
            MF_SOURCE_READER_FIRST_VIDEO_STREAM, 0, &idx, &flags, &ts, &sample);
        if (FAILED(hr) || (flags & MF_SOURCE_READERF_ERROR)) break;
        if (flags & MF_SOURCE_READERF_ENDOFSTREAM) break;
        if (!sample) continue;

        ComPtr<IMFMediaBuffer> buf;
        if (FAILED(sample->ConvertToContiguousBuffer(&buf))) continue;

        BYTE *p = 0;
        DWORD maxLen = 0, curLen = 0;
        if (FAILED(buf->Lock(&p, &maxLen, &curLen))) continue;

        RgbImage img;
        const bool ok = convertFrame(p, curLen, im->w, im->h, im->stride, im->fmt, img);
        buf->Unlock();
        if (!ok) continue;

        {
            std::lock_guard<std::mutex> lk(m_mutex);
            m_frame.w = img.w;
            m_frame.h = img.h;
            m_frame.data.swap(img.data);
            ++m_seq;
        }
        m_cv.notify_all();
    }
    m_running = false;
    if (SUCCEEDED(comHr)) CoUninitialize();
}

void Camera::injectFrame(const RgbImage &img)
{
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_frame = img;
        ++m_seq;
    }
    m_cv.notify_all();
}

bool Camera::waitFrame(RgbImage &out, unsigned long long &lastSeq, int timeoutMs)
{
    std::unique_lock<std::mutex> lk(m_mutex);
    if (!m_cv.wait_for(lk, std::chrono::milliseconds(timeoutMs),
                       [&] { return m_seq != lastSeq; }))
        return false;
    out.w = m_frame.w;
    out.h = m_frame.h;
    out.data = m_frame.data; // Copy: the camera thread keeps writing.
    lastSeq = m_seq;
    return !out.data.empty();
}
