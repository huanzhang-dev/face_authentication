# Camera upgrade notes

## What changed
- Camera mode selection now prefers 1920x1080 at 25 FPS or higher, targeting 30 FPS; then 1280x720; then 640x480; then another usable mode.
- MJPEG is preferred as the native USB format when equivalent; Media Foundation is asked to decode it to RGB32/RGB24. YUY2, NV12, L8 and L16 remain supported fallbacks.
- The app displays the actual selected capture mode in the status line.
- The IR checkbox is now explicitly labelled as grayscale preprocessing only. It does not control LEDs, the IR-cut filter or exposure.
- The existing 960-pixel processing width and 24-pixel eye-distance quality gate are unchanged.

## Recommended hardware
For one person at 1–2 m indoors, start with an ELP OV2710 UVC camera:
- ELP USBFHD05MT-KFVIR varifocal 2.8–12 mm, adjusted near 6 mm; or
- ELP USBFHD05MT-UL60IR fixed 6 mm option.

Ask the supplier to confirm the exact SKU's 850 nm LED wavelength, IR-cut behavior, lens field of view and continuous-use rating. These details can differ between suffixes / configurations.

## Windows driver
For a standards-compliant UVC camera, use Microsoft's inbox `usbvideo.sys` driver. Capture is through Media Foundation. No proprietary camera driver is required for ordinary UVC streaming.

## Build
Open `FaceAttendance.sln` in Visual Studio and build `Release | x64`. The project uses the bundled ncnn library and its configured toolset. This source package has been updated but was not compiled against a Windows/MSVC toolchain in this environment; compile and test on the target Windows machine before deployment.

## Hardware verification checklist
1. Connect the camera directly to a USB 3.x port (avoid an unpowered hub).
2. Confirm Windows Device Manager loads `usbvideo.sys`.
3. Start the app and read the status line: expect 1920x1080 @ 30 fps where the camera exposes that mode.
4. Confirm the app receives live frames and the displayed image is not rotated or vertically inverted.
5. Test face detection and eye landmark separation at 1.0 m, 1.5 m and 2.0 m.
6. Turn off visible room lighting and verify the camera's IR illumination and exposure. The application itself does not switch the IR hardware.
7. Register people using the same camera and lighting conditions used for attendance.
8. Test for flicker, glare from glasses, motion blur and exposure hunting before accepting the installation.

## Known limits
- Media Foundation conversion depends on the Windows decoder / video-processing transforms available on the target PC and the camera's advertised UVC modes.
- The selected mode is reported, but the application does not yet expose a GUI selector for capture resolution / FPS.
- Generic UVC does not provide a universal standard control for every IR LED, IR-cut filter or exposure implementation.
- A 6 mm lens / 53-degree FOV calculation is an estimate. Verify actual framing on the installed camera.
- Infrared capture does not replace liveness / anti-spoofing detection.
