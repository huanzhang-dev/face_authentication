#include "Engine.h"
#include "ImageIO.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>

static std::string iniStr(const std::string &file, const char *sec, const char *key, const char *def)
{
    char buf[512];
    GetPrivateProfileStringA(sec, key, def, buf, sizeof(buf), file.c_str());
    return buf;
}

static std::vector<std::string> splitList(const std::string &s)
{
    std::vector<std::string> v;
    std::string cur;
    for (size_t i = 0; i <= s.size(); ++i) {
        if (i == s.size() || s[i] == ',') {
            size_t a = cur.find_first_not_of(" \t"), b = cur.find_last_not_of(" \t");
            v.push_back(a == std::string::npos ? std::string() : cur.substr(a, b - a + 1));
            cur.clear();
        } else cur += s[i];
    }
    return v;
}

Engine::Engine(Camera *cam, SharedState *st, HWND hwnd)
    : m_cam(cam), m_st(st), m_hwnd(hwnd), m_stop(false), m_ready(false), m_galLocked(false), m_detSize(640),
      m_detThr(0.5f), m_thr(0.45f), m_ir(true), m_margin(0.04f), m_votes(2), m_nextId(1), m_seq(0) {}

Engine::~Engine() { stop(); }

void Engine::start(const std::wstring &dataDir, const std::wstring &modelDir)
{
    m_dataDir = dataDir;
    m_modelDir = modelDir;
    m_stop = false;
    m_thread = std::thread(&Engine::run, this);
}

void Engine::stop()
{
    m_stop = true;
    if (m_thread.joinable()) m_thread.join();
}

void Engine::post(const std::function<void()> &fn)
{
    std::lock_guard<std::mutex> lk(m_cmdMutex);
    m_cmds.push_back(fn);
}

void Engine::runCommands()
{
    std::vector<std::function<void()> > local;
    {
        std::lock_guard<std::mutex> lk(m_cmdMutex);
        local.swap(m_cmds);
    }
    for (size_t i = 0; i < local.size(); ++i) local[i]();
}

// ---------------------------------------------------------------- thread + start-up
void Engine::run()
{
    CoInitializeEx(0, COINIT_MULTITHREADED);           // WIC needs COM
    m_ready = init();
    ULONGLONG lastFlush = GetTickCount64();
    while (!m_stop) {
        runCommands();
        RgbImage img;
        if (m_cam->waitFrame(img, m_seq, 40)) processFrame(img);
        if (m_att.pending() > 0 && GetTickCount64() - lastFlush > 3000) {   // retry rows the CSV refused
            lastFlush = GetTickCount64();
            if (m_att.flush()) setMessage("Attendance saved: attendance.csv is free again.");
        }
    }
    if (m_att.pending() > 0 && !m_att.flush()) m_att.spill();   // leaving: never drop unsaved rows
    CoUninitialize();
}

bool Engine::init()
{
    CreateDirectoryW(m_dataDir.c_str(), 0);
    std::string warn;                                   // goes in front of the status text
    const std::wstring galPath = m_dataDir + L"\\gallery.bin";
    if (!m_gal.load(galPath)) {
        // Unreadable, damaged or unknown version. NEVER overwrite it: move it aside for recovery.
        SYSTEMTIME t;
        GetLocalTime(&t);
        wchar_t stamp[32];
        swprintf(stamp, 32, L"%04d%02d%02d-%02d%02d%02d", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond);
        const std::wstring bad = galPath + L".corrupt-" + stamp;
        if (MoveFileExW(galPath.c_str(), bad.c_str(), 0)) {
            warn = "WARNING: gallery.bin could not be read; kept as " + toUtf8(bad.substr(bad.find_last_of(L"\\/") + 1))
                 + ". Starting with an empty list: restore a backup. ";
            m_gal.load(galPath);                        // now missing = empty gallery, path remembered
        } else {
            m_galLocked = true;
            warn = "WARNING: gallery.bin could not be read or moved; registration is disabled to protect it. ";
        }
        MessageBeep(MB_ICONWARNING);
    }
    m_att.open(m_dataDir + L"\\attendance.csv");
    publishState();

    const std::string ini = toAnsi(m_modelDir + L"\\models.ini");
    int threads = atoi(iniStr(ini, "general", "threads", "4").c_str());
    if (threads <= 0) threads = 4;
    m_detSize = atoi(iniStr(ini, "detector", "size", "640").c_str());
    m_detThr = static_cast<float>(atof(iniStr(ini, "detector", "score", "0.5").c_str()));

    if (!m_det.load(toAnsi(m_modelDir + L"\\det.param"), toAnsi(m_modelDir + L"\\det.bin"),
                    iniStr(ini, "detector", "input", "in0"),
                    splitList(iniStr(ini, "detector", "out_score", "out0,out1,out2")),
                    splitList(iniStr(ini, "detector", "out_bbox", "out3,out4,out5")),
                    splitList(iniStr(ini, "detector", "out_kps", "out6,out7,out8")), threads)) {
        setMessage(warn + "ERROR: cannot load models\\det.param/det.bin (see README, section 3)");
        return false;
    }
    if (!m_rec.load(toAnsi(m_modelDir + L"\\rec.param"), toAnsi(m_modelDir + L"\\rec.bin"),
                    iniStr(ini, "recognizer", "input", "in0"), iniStr(ini, "recognizer", "output", "out0"),
                    static_cast<float>(atof(iniStr(ini, "recognizer", "mean", "127.5").c_str())),
                    static_cast<float>(atof(iniStr(ini, "recognizer", "norm", "0.007843137").c_str())),
                    iniStr(ini, "recognizer", "contrast_stretch", "true") != "false", threads)) {
        setMessage(warn + "ERROR: cannot load models\\rec.param/rec.bin (see README, section 3)");
        return false;
    }
    char b[64];
    std::sprintf(b, "Models loaded (%d threads)", threads);
    setMessage(warn + b);
    return true;
}

// ---------------------------------------------------------------- UI hand-over
void Engine::setMessage(const std::string &msg)
{
    {
        std::lock_guard<std::mutex> lk(m_st->m);
        m_st->message = msg;
    }
    PostMessage(m_hwnd, WM_APP_STATE, 0, 0);
}

void Engine::publishState()
{
    {
        std::lock_guard<std::mutex> lk(m_st->m);
        m_st->today = m_att.today();
        m_gal.labels(m_st->personIds, m_st->personTexts);
    }
    PostMessage(m_hwnd, WM_APP_STATE, 0, 0);
}

// ---------------------------------------------------------------- helpers
static float iou(float ax0, float ay0, float ax1, float ay1,
                 float bx0, float by0, float bx1, float by1)
{
    float iw = std::min(ax1, bx1) - std::max(ax0, bx0);
    float ih = std::min(ay1, by1) - std::max(ay0, by0);
    if (iw <= 0 || ih <= 0) return 0.f;
    float inter = iw * ih;
    return inter / ((ax1 - ax0) * (ay1 - ay0) + (bx1 - bx0) * (by1 - by0) - inter);
}

// Reject faces that would give unreliable embeddings: tiny or strongly turned.
bool Engine::goodQuality(const FaceDet &f) const
{
    float ex = f.lx[1] - f.lx[0], ey = f.ly[1] - f.ly[0];
    if (std::sqrt(ex * ex + ey * ey) < 24.f) return false;        // eyes closer than 24 px
    if (!(f.lx[2] > f.lx[0] && f.lx[2] < f.lx[1])) return false;   // nose must lie between the eyes
    return true;
}

// Compare with the whole gallery. Brute-force dot products: thousands of 512-d
// vectors cost well under a millisecond.
Engine::Match Engine::match(const FloatVec &e) const
{
    Match m;
    const std::vector<GalleryEntry> &g = m_gal.entries();
    int bi = -1;
    float best = -2.f;
    for (size_t i = 0; i < g.size(); ++i) {
        if (g[i].emb.size() != e.size()) continue;
        float s = 0.f;
        for (size_t k = 0; k < e.size(); ++k) s += e[k] * g[i].emb[k];
        if (s > best) { best = s; bi = static_cast<int>(i); }
    }
    if (bi < 0) return m;
    // runner-up must be a DIFFERENT person, otherwise two photos of one person would "tie"
    float second = -1.f;
    for (size_t i = 0; i < g.size(); ++i) {
        if (g[i].id == g[bi].id || g[i].emb.size() != e.size()) continue;
        float s = 0.f;
        for (size_t k = 0; k < e.size(); ++k) s += e[k] * g[i].emb[k];
        second = std::max(second, s);
    }
    m.id = g[bi].id;  m.name = g[bi].name;  m.score = best;
    m.ok = (best >= m_thr) && (best - second >= m_margin);
    return m;
}

// ---------------------------------------------------------------- one camera frame
void Engine::processFrame(RgbImage &img)
{
    LARGE_INTEGER t0, t1, fr;
    QueryPerformanceFrequency(&fr);
    QueryPerformanceCounter(&t0);

    if (m_ir) toGray(img);                              // Software grayscale preprocessing; does not control camera IR hardware.
    if (img.w > 960) shrinkToWidth(img, 960);           // big frames only cost time

    FaceViewList views;
    if (m_ready) {
        // 1) detect every face in the frame
        std::vector<FaceDet> dets = m_det.detect(img, m_detSize, m_detThr);

        // 2) tracking: greedy IoU matching of detections to existing tracks
        struct Pair { float iou; size_t t, d; };
        std::vector<Pair> pairs;
        for (size_t t = 0; t < m_tracks.size(); ++t)
            for (size_t d = 0; d < dets.size(); ++d) {
                float v = iou(m_tracks[t].bx0, m_tracks[t].by0, m_tracks[t].bx1, m_tracks[t].by1,
                              dets[d].x0, dets[d].y0, dets[d].x1, dets[d].y1);
                if (v > 0.25f) { Pair p = { v, t, d }; pairs.push_back(p); }
            }
        std::sort(pairs.begin(), pairs.end(), [](const Pair &a, const Pair &b) { return a.iou > b.iou; });

        std::vector<char> tUsed(m_tracks.size(), 0), dUsed(dets.size(), 0);
        for (size_t k = 0; k < pairs.size(); ++k) {
            if (tUsed[pairs[k].t] || dUsed[pairs[k].d]) continue;
            Track &t = m_tracks[pairs[k].t];
            const FaceDet &d = dets[pairs[k].d];
            t.det = d;
            t.bx0 = 0.5f * t.bx0 + 0.5f * d.x0;  t.by0 = 0.5f * t.by0 + 0.5f * d.y0;   // smooth jitter
            t.bx1 = 0.5f * t.bx1 + 0.5f * d.x1;  t.by1 = 0.5f * t.by1 + 0.5f * d.y1;
            t.missed = 0;  t.age++;
            tUsed[pairs[k].t] = dUsed[pairs[k].d] = 1;
        }
        for (size_t t = 0; t < m_tracks.size(); ++t)
            if (!tUsed[t]) m_tracks[t].missed++;
        for (size_t t = 0; t < m_tracks.size(); ++t)
            if (m_tracks[t].enrolling && m_tracks[t].missed > 8)
                setMessage("Registration cancelled: the face left the picture.");
        m_tracks.erase(std::remove_if(m_tracks.begin(), m_tracks.end(),
                                      [](const Track &t) { return t.missed > 8; }), m_tracks.end());
        for (size_t d = 0; d < dets.size(); ++d) {
            if (dUsed[d]) continue;
            Track t;
            t.id = m_nextId++;  t.det = dets[d];
            t.bx0 = dets[d].x0; t.by0 = dets[d].y0; t.bx1 = dets[d].x1; t.by1 = dets[d].y1;
            m_tracks.push_back(t);
        }

        // 3) recognise. A budget per frame keeps latency flat when many faces appear.
        int budget = 3;
        for (size_t i = 0; i < m_tracks.size() && budget > 0; ++i) {
            Track &t = m_tracks[i];
            if (t.missed > 0) continue;
            const bool need = t.enrolling
                           || (!t.confirmed && t.age - t.lastRecog >= 2)     // keep trying unknown faces
                           || ( t.confirmed && t.age - t.lastRecog >= 45);   // re-verify known faces now and then
            if (!need || !goodQuality(t.det)) continue;
            --budget;
            t.lastRecog = t.age;

            FloatVec emb;
            if (!m_rec.extract(img, t.det, emb)) continue;

            if (t.enrolling) {                           // manual registration: average 5 views
                t.enrollEmbs.push_back(emb);
                if (t.enrollEmbs.size() >= 5) {
                    FloatVec avg(emb.size(), 0.f);
                    for (size_t a = 0; a < t.enrollEmbs.size(); ++a)
                        for (size_t k = 0; k < avg.size(); ++k) avg[k] += t.enrollEmbs[a][k];
                    float len = 0.f;
                    for (size_t k = 0; k < avg.size(); ++k) len += avg[k] * avg[k];
                    len = std::sqrt(len) + 1e-9f;
                    for (size_t k = 0; k < avg.size(); ++k) avg[k] /= len;
                    addTemplate(t.enrollId, t.enrollName, avg);
                    setMessage("Registered " + t.enrollName);
                    t.enrolling = false;  t.enrollEmbs.clear();
                }
                continue;
            }

            Match m = match(emb);
            if (m.ok) {
                if (m.id == t.candId) t.streak++; else { t.candId = m.id; t.streak = 1; }
                t.score = m.score;
                if (t.confirmed && m.id != t.personId) { // identity changed: start over
                    t.confirmed = false;  t.reported = false;  t.streak = 1;
                }
                if (t.streak >= m_votes && !t.confirmed) {
                    t.confirmed = true;  t.personId = m.id;  t.name = m.name;
                    if (!t.reported) {
                        t.reported = true;
                        const std::string kind = m_att.mark(m.id, m.name, m.score, 30);   // 30 min minimum gap
                        if (!kind.empty()) {
                            char tm[16];
                            time_t now = time(0);
                            struct tm l;
                            localtime_s(&l, &now);
                            strftime(tm, sizeof(tm), "%H:%M:%S", &l);
                            publishState();
                            std::string msg = m.name + " (" + m.id + ") checked " + kind + " at " + tm;
                            if (m_att.pending() > 0)    // the CSV refused the row (open in Excel?): it is kept and retried
                                msg += "  (NOT SAVED YET: attendance.csv is locked, close it in Excel; retrying)";
                            setMessage(msg);
                            MessageBeep(MB_OK);
                        }
                    }
                }
            } else {
                t.candId.clear();  t.streak = 0;  t.score = m.score;
                t.confirmed = false;  t.reported = false;
            }
        }

        // 4) describe everything the window has to draw
        for (size_t i = 0; i < m_tracks.size(); ++i) {
            const Track &t = m_tracks[i];
            if (t.missed > 0) continue;
            FaceView v;
            v.trackId = t.id;
            v.x = t.bx0 / img.w;  v.y = t.by0 / img.h;
            v.w = (t.bx1 - t.bx0) / img.w;  v.h = (t.by1 - t.by0) / img.h;
            for (int k = 0; k < 5; ++k) { v.lx[k] = t.det.lx[k] / img.w; v.ly[k] = t.det.ly[k] / img.h; }
            v.score = t.score;
            char b[64];
            if (t.enrolling) {
                std::sprintf(b, "Registering %d/5", static_cast<int>(t.enrollEmbs.size()));
                v.state = 1; v.label = b;
            } else if (t.confirmed) {
                std::sprintf(b, " %.2f", t.score);
                v.state = 2; v.label = t.name + b;
            } else if (!t.candId.empty()) { v.state = 1; v.label = "Verifying..."; }
            else { v.state = 0; v.label = "Unknown"; }
            views.push_back(v);
        }
    }

    QueryPerformanceCounter(&t1);
    {
        std::lock_guard<std::mutex> lk(m_st->m);
        m_st->frame.w = img.w;  m_st->frame.h = img.h;  m_st->frame.data.swap(img.data);
        m_st->faces.swap(views);
        m_st->ms = (t1.QuadPart - t0.QuadPart) * 1000.0 / fr.QuadPart;
        m_st->frameNew = true;
    }
    PostMessage(m_hwnd, WM_APP_FRAME, 0, 0);
}

// ---------------------------------------------------------------- enrolment
void Engine::addTemplate(const std::string &id, const std::string &name, const FloatVec &emb)
{
    if (m_galLocked) { setMessage("Registration is disabled: gallery.bin is damaged and could not be moved aside."); return; }
    m_gal.add(id, name, emb);
    if (!m_gal.save()) setMessage("WARNING: cannot write data\\gallery.bin");
    publishState();
}

void Engine::requestEnroll(int trackId, const std::string &id, const std::string &name)
{
    post([=] {
        for (size_t i = 0; i < m_tracks.size(); ++i) {
            if (m_tracks[i].id != trackId) continue;
            m_tracks[i].enrolling = true;  m_tracks[i].enrollId = id;
            m_tracks[i].enrollName = name; m_tracks[i].enrollEmbs.clear();
            setMessage("Hold still, capturing 5 samples...");
            return;
        }
        setMessage("Selected face is no longer visible.");
    });
}

// Embedding of the LARGEST face of a still photo.
bool Engine::embedBest(const RgbImage &img, FloatVec &emb, std::string &err) const
{
    std::vector<FaceDet> d = m_det.detect(img, m_detSize, 0.5f);
    if (d.empty()) { err = "no face found"; return false; }
    size_t bi = 0;
    float ba = 0;
    for (size_t i = 0; i < d.size(); ++i) {
        float a = (d[i].x1 - d[i].x0) * (d[i].y1 - d[i].y0);
        if (a > ba) { ba = a; bi = i; }
    }
    if (d.size() > 1) err = "several faces, used the largest";
    if (!m_rec.extract(img, d[bi], emb)) { err = "embedding failed"; return false; }
    return true;
}

static std::string baseName(const std::wstring &p)
{
    return toUtf8(p.substr(p.find_last_of(L"\\/") + 1));
}

void Engine::doEnrollFiles(const std::string &id, const std::string &name, const std::vector<std::wstring> &files)
{
    if (!m_ready) { setMessage("Models are not loaded."); return; }
    int ok = 0;
    for (size_t i = 0; i < files.size(); ++i) {
        RgbImage im;
        if (!loadImageRgb(files[i], im)) { setMessage(baseName(files[i]) + ": cannot read image"); continue; }
        FloatVec emb;
        std::string err;
        if (embedBest(im, emb, err)) {
            addTemplate(id, name, emb);
            ++ok;
            if (!err.empty()) setMessage(baseName(files[i]) + ": " + err);
        } else {
            setMessage(baseName(files[i]) + ": " + err);
        }
    }
    char b[64];
    std::sprintf(b, ": %d of %d photos registered", ok, static_cast<int>(files.size()));
    setMessage(name + b);
}

void Engine::enrollImages(const std::string &id, const std::string &name, const std::vector<std::wstring> &files)
{
    post([=] { doEnrollFiles(id, name, files); });
}

void Engine::enrollFolder(const std::wstring &dir)
{
    post([=] {
        WIN32_FIND_DATAW fd;
        HANDLE h = FindFirstFileW((dir + L"\\*").c_str(), &fd);
        if (h == INVALID_HANDLE_VALUE) { setMessage("Cannot open the folder."); return; }
        std::vector<std::wstring> subs;
        do {
            if ((fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) && fd.cFileName[0] != L'.')
                subs.push_back(fd.cFileName);
        } while (FindNextFileW(h, &fd));
        FindClose(h);

        for (size_t i = 0; i < subs.size(); ++i) {
            size_t us = subs[i].find(L'_');                    // "1001_Alice" -> id 1001, name Alice
            std::string id   = toUtf8(us != std::wstring::npos && us > 0 ? subs[i].substr(0, us) : subs[i]);
            std::string name = toUtf8(us != std::wstring::npos && us > 0 ? subs[i].substr(us + 1) : subs[i]);
            std::vector<std::wstring> files;
            const wchar_t *pats[] = { L"*.jpg", L"*.jpeg", L"*.png", L"*.bmp" };
            for (int p = 0; p < 4; ++p) {
                HANDLE f = FindFirstFileW((dir + L"\\" + subs[i] + L"\\" + pats[p]).c_str(), &fd);
                if (f == INVALID_HANDLE_VALUE) continue;
                do { files.push_back(dir + L"\\" + subs[i] + L"\\" + fd.cFileName); } while (FindNextFileW(f, &fd));
                FindClose(f);
            }
            if (!files.empty()) doEnrollFiles(id, name, files);
        }
        setMessage("Folder import finished.");
    });
}

void Engine::removePerson(const std::string &id)
{
    post([=] {
        if (m_gal.remove(id)) { m_gal.save(); setMessage("Removed " + id); }
        else setMessage("ID not found: " + id);
        for (size_t i = 0; i < m_tracks.size(); ++i)            // forget cached identities
            if (m_tracks[i].personId == id) { m_tracks[i].confirmed = false; m_tracks[i].reported = false; m_tracks[i].candId.clear(); }
        publishState();
    });
}
