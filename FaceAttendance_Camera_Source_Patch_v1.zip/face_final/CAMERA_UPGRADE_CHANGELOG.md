# Face Attendance camera upgrade v1

## Files changed
- `Camera.cpp`
  - Replaced the 640x480-nearest mode selection with a ranked capture-mode policy.
  - Prefers 1920x1080 at 25 FPS or higher (target 30 FPS), then 1280x720, then 640x480, then other usable modes.
  - Prefers native MJPEG for USB bandwidth when otherwise equivalent.
  - Tries Media Foundation output formats RGB32, RGB24, YUY2, NV12, L8 and L16, then a supported native uncompressed format.
  - Validates frame dimensions, stride and buffer length before pixel conversion.
  - Records the actual capture mode and output format.
- `Camera.h`
  - Adds `captureDescription()` and documents the mode-selection policy.
- `main.cpp`
  - Shows the actual selected capture mode in the status line.
  - Renames the IR checkbox to make clear that it performs grayscale processing only.
- `Engine.cpp`
  - Clarifies that grayscale processing does not control IR hardware.
- `README.md`, `docs/CODE_WALKTHROUGH.md`
  - Updates capture policy, IR behavior, hardware recommendations and source fingerprints.
- `CAMERA_UPGRADE_NOTES.md`
  - Provides hardware, driver, build and verification guidance.

## Behavior intentionally unchanged
- The SCRFD detector and ArcFace recognizer models.
- The 960-pixel maximum processing width.
- The 24-pixel inter-eye quality gate.
- Tracking, matching threshold, voting and attendance rules.
- NCNN runtime and project link settings.

## Important hardware boundary
The application uses Media Foundation / UVC. It does not implement vendor-specific UVC extension controls for IR LEDs, IR-cut filters or exposure. The renamed checkbox only converts frames to grayscale. Select a camera whose firmware handles day/night illumination automatically, or integrate the exact manufacturer's SDK / UVC extension controls separately.

## Build and test status
The project files were updated and statically inspected. This environment does not have Windows Media Foundation headers, the Windows SDK or MSBuild, so the modified C++ project was **not compiled here**. Build it on the target Windows PC in Visual Studio, then test the selected camera mode and image orientation with the actual device.

## Suggested Windows build
Open `FaceAttendance.sln`, select `Release | x64`, and build. If using MSBuild from a Developer PowerShell:
```powershell
msbuild .\FaceAttendance.sln /m /p:Configuration=Release /p:Platform=x64
```

## Hardware acceptance test
1. Connect a standards-compliant UVC camera.
2. Confirm Device Manager uses Microsoft's `usbvideo.sys` driver.
3. Start the application and check the status line for the actual capture resolution / FPS / format.
4. Test face detection at 1.0 m, 1.5 m and 2.0 m.
5. Test normal lighting and complete darkness with the camera's IR illumination active.
6. Check glasses reflections, exposure stability, motion blur and frame rate.
7. Enroll with the same camera and lighting conditions used during attendance.
