# Code walkthrough: Face Attendance, line by line, in execution order

This document explains the program in execution order: start-up, camera frames, user actions, and shutdown. The camera-capture sections below have been updated for the 1080p-first camera upgrade. Some line references elsewhere still refer to the original uploaded snapshot; use the function names when locating code.

**Keeping it correct:** the table below stores a fingerprint (SHA-256) of every source file this text describes. After ANY change to a source file, update the matching section here, then run `powershell -File tools\check_docs.ps1 -Update`. Running `powershell -File tools\check_docs.ps1` (without `-Update`) lists the files whose code changed after the text was written. The rule is also written in `CLAUDE.md`.

<!-- HASHES:BEGIN -->
| File | SHA-256 (first 16 hex) |
|---|---|
| app.manifest | 15e083a1ad7e60f9 |
| Camera.cpp | 9ae7c839641e625e |
| Camera.h | 71e9c77e3e1f4704 |
| Demo.cpp | 0a77b9bac80f389c |
| Demo.h | 1b912111058646fe |
| Engine.cpp | db7c3763f0a0c815 |
| Engine.h | 3dee0039a154e357 |
| FaceAttendance.rc | c6ebcbb70a593eec |
| FaceDetector.cpp | d7be9992fafe4b90 |
| FaceDetector.h | 26daf00c60db8802 |
| FaceRecognizer.cpp | 723a3d3000eff939 |
| FaceRecognizer.h | 1ce135b12bd826cd |
| ImageIO.cpp | 5788304d6a7e3486 |
| ImageIO.h | 530fb018c181337d |
| main.cpp | 7291be57718aa3df |
| resource.h | 6259a22726441cb1 |
| Store.cpp | 719809cea13b23fe |
| Store.h | 9649255b2f29b338 |
| Types.h | 3f9d320a66e84dd3 |
| Util.h | 96b36247f501b83c |
<!-- HASHES:END -->

---

## 0. The big picture

Three threads cooperate:

```
 UI thread (main.cpp)              Camera thread (Camera.cpp)          Engine thread (Engine.cpp)
 window, buttons, painting         captureLoop: ReadSample             run(): processFrame per frame
        |                                 |  newest frame only                 |
        |   start camera ---------------->|----- waitFrame (copy) ------------>|
        |                                                                      | detect -> track -> recognise
        |<---- SharedState (mutex) + PostMessage(WM_APP_FRAME / WM_APP_STATE) -|     -> attendance -> publish
        |---- commands (register, remove, settings) ------------------------->|
```

* The camera thread only ever keeps the **newest** frame. If the engine is slower than the camera, frames are skipped instead of queueing up, so the picture on screen is always current.
* The engine thread owns the face templates (`Gallery`) and the attendance log (`AttendanceLog`). Nobody else touches them, so they need no locks.
* The UI thread never runs a neural network. It only copies results out of `SharedState` and paints.
* An optional fourth thread (`DemoDriver`, `Demo.cpp`) exists only in scripted test runs; a normal start never creates it.

Terms: *embedding* = a vector of 512 numbers describing a face; *cosine similarity* = how alike two embeddings are (1 = identical); *track* = one face followed across frames; *template* = a stored embedding of a registered person.

---

## 1. Start-up

### 1.1 `main.cpp`: includes, constants, `App` (L1-L53)

* **L2-L4** `#ifndef NOMINMAX ... #endif`: stop `windows.h` from defining the macros `min` and `max`, which would break `std::min` / `std::max`.
* **L5-L9** Windows headers: `windows.h` (core API), `commctrl.h` (list view, slider), `commdlg.h` (file-open dialog), `shellapi.h` (`ShellExecute`), `shlobj.h` (folder-picker dialog).
* **L10-L12** `<algorithm>` for `std::min/max`; `<cmath>` for `fabs`; `<cstdio>` for `sprintf`.
* **L13-L17** the project headers: `Camera.h`, `Demo.h` (options for scripted runs), `Engine.h`, `Util.h` (string conversions), `resource.h` (control ids).
* **L19** `#pragma comment(linker, ...)`: tells the linker to put a dependency on the modern (version 6) common controls into the manifest, so buttons, list view and slider get the current Windows look. The display-scaling declaration is in `app.manifest` (section 5).
* **L21-L27** constants and test overrides. **L21** comment: every size in this file is written for 96 dpi (Windows scaling 100 %) and multiplied by the real scaling. **L22** `PANEL_W = 400`: width of the right-hand control panel. **L23** `MIN_CLIENT_H = 450`: the smallest client height in which every control still fits. **L24** `DEFAULT_ASPECT = 4/3`: the shape of the video area until the camera reports its own. **L25** `kClass`: name under which the window class is registered. **L26** `g_scalePct`: test override of the display scaling (0 = use Windows' value). **L27** `g_screen`: test override of the monitor work area (empty = the real monitor).
* **L29-L53** `struct App`: everything the window needs, kept in one object so no global variables are needed.
  * **L31** `hwnd`: handle of the main window. **L32** `font`, `fontBold`: GDI fonts (normal for controls, bold for face labels).
  * **L33** `camera`: the capture object. **L34** `shared`: data handed over by the engine thread. **L35** `engine`: pointer to the engine (created later, once the window exists).
  * **L36** `cams`: cameras found at start. **L37** `settingsFile`: full path of `settings.ini`.
  * **L40-L42** the picture currently shown: `image` (RGB), `bgr` (the same picture converted for GDI), `faces` (boxes to draw).
  * **L43** `selected`: id of the face the user clicked (-1 = none). **L44-L46** FPS bookkeeping: `frames` counted since `fpsStart`, `fps`, `ms` (analysis time of the last frame). **L47** `message`: last status text.
  * **L48** `aspect`: width / height of the video area, i.e. the camera's shape. **L49** `adjusting`: true while the program itself resizes the window, so it does not "correct" its own change.
  * **L51-L52** constructor: sets numbers and pointers to a safe initial value (`aspect` = 4/3).

### 1.1a Display scaling and window shape: the helpers (main.cpp L55-L168)

Goal: the window looks the same, undistorted, on every screen size and every Windows display scaling (100 %, 125 %, 150 %, 200 %, ...), and the video area always has exactly the camera's aspect ratio (no black bars, no stretching).

* **L56** `setText`: sets the text of a control from a UTF-8 string.
* **L59-L71** `dpiOf(hwnd)`: the display scaling of the window as "dots per inch" (96 = 100 %, 120 = 125 %, 144 = 150 %, 192 = 200 %). **L63** a test override (`--scale`) wins. **L64-L65** `GetDpiForWindow` (Windows 10 version 1607 and newer) is looked up in `user32.dll` at run time, so the program still starts on older Windows and still compiles with an older SDK. **L66** ask Windows for this window's value (per monitor). **L67-L70** fallback for older Windows: the system-wide value from the screen's device caps; 96 if unknown.
* **L73** `px(hwnd, at96)`: converts a size designed for 96 dpi to real pixels: `at96 * dpi / 96`.
* **L76-L82** `workArea(hwnd)`: the usable part of the monitor (without the task bar): the test override if set, otherwise `rcWork` of the monitor the window is on.
* **L84-L86** the shape rule, written as a comment, and `panelWidth` = panel (400) + gap (8), both scaled. Rule: `client width = client height x aspect + panel`.
* **L88-L95** `layoutRects`: the video area is everything left of the panel: `right = client width - panel` (never less than 100), full height.
* **L97-L104** `frameSize`: the size of title bar and borders (window size minus client size), needed to convert between client size and window size.
* **L108-L132** `fitWindow(a, wantH)`: resize the window so its client height is `wantH` and the video area has the right shape. **L111-L114** work area, frame size, panel width. **L115** the height is at least `px(450)`. **L116** the width follows from the rule (rounded). **L117-L120** never larger than the work area **nor than Windows allows a window to grow** (`SM_CXMAXTRACK` / `SM_CYMAXTRACK`; otherwise the system would limit only one side and the shape would be lost). **L121-L122** if too wide, shrink the width and recompute the height; if too tall, shrink the height and recompute the width: the shape is kept. **L123-L128** keep the current top-left corner but pull the window inside the work area. **L129-L131** `SetWindowPos` with `adjusting` set, so the resize handlers ignore it.
* **L135-L148** `lockAspect(a, edge, r)`: called while the user drags an edge or corner; corrects the rectangle `r` Windows proposes. **L141** proposed client size. **L142** dragging the left or right edge: the width leads and the height is computed from it. **L143** any other edge or corner: the height leads and the width is computed. **L144** not below the minimum height. **L145** the corrected outer size. **L146-L147** apply it to the edge being dragged (left-side edges move the left side, others the right side; top-side edges move the top, others the bottom), so the opposite side stays where it is.
* **L151** `setFontProc`: sets the font of one window. **L153-L168** `applyFonts`: **L156** font height = -(9 pt x dpi / 72) pixels (negative = character height); **L157** ClearType smoothing; **L158** Segoe UI; **L159-L162** a normal and a bold font; **L163** give the normal font to every child window; **L164-L165** free the old fonts; **L166-L167** remember the new ones.

### 1.2 `wWinMain` (main.cpp L687-L751), first half

* **L687** entry point of a Windows GUI program (wide-character version: command line is UTF-16).
* **L689** `OleInitialize(0)`: starts COM on the UI thread as a single-threaded apartment. The folder-picker dialog needs it.
* **L690-L691** `InitCommonControlsEx`: registers the list-view and slider window classes (`ICC_LISTVIEW_CLASSES`, `ICC_BAR_CLASSES`).
* **L693-L694** `DemoOptions demo; parseDemoArgs(demo);`: reads the command line (section 5, `Demo.cpp`). A normal start has no options, so nothing changes. **L695** copy the scaling override. **L696** a `--screen WxH` option becomes the pretend work area rectangle (0, 0, W, H).
* **L697** `base` = folder of the exe (`exeDir()` is in `Util.h`). **L698** `dataDir` = `base\data`, or the folder given with `--data`.
* **L700** `App app;` creates the application object on the stack (it lives until `wWinMain` returns). Its members `camera` and `shared` are constructed here.
* **L701** `settingsFile` = `settings.ini` in the exe folder, or in the `--data` folder. **L702** create that folder if given. **L703** `--ir` writes the IR flag into the settings. **L704** `listCameras()` (Camera.cpp, section 1.5) fills `app.cams`, unless `--no-camera` was given: then no camera is even enumerated.
* **L706-L711** describe and register the window class: `lpfnWndProc = wndProc` (function receiving all window messages), instance, arrow cursor, class name.
* **L712-L713** `CreateWindowExW`: creates the main window, resizable (`WS_OVERLAPPEDWINDOW`), `WS_CLIPCHILDREN` so the window does not paint over its child controls. The 1280x760 is only provisional; the real size is set at L716-L723 (section 1.6). The last argument `&app` is delivered to `WM_CREATE` (L585).
* **L714** if the window could not be created, quit with error code 1.

During `CreateWindowExW`, Windows sends `WM_CREATE` to `wndProc`:

### 1.3 `wndProc`, `WM_CREATE` (main.cpp L580-L590)

* **L582** read the `App*` stored in the window (null before `WM_CREATE`).
* **L585** on `WM_CREATE` the pointer comes from the creation parameters (`lpCreateParams` = `&app`).
* **L586** store it in the window (`GWLP_USERDATA`) so every later message can fetch it (L582). **L587** remember the window handle. **L588** `createControls(a)`.

### 1.4 `createControls`, `layoutControls` and helpers (main.cpp L479-L489, L491-L538, L540-L568)

* **L479-L483** `make(...)`: creates one child control. `WS_CHILD | WS_VISIBLE` plus the given style; position and size are dummy (10x10), `layoutControls` sets the real ones; `id` becomes the control id (used by `GetDlgItem` and in `WM_COMMAND`).
* **L485-L489** `setColumnWidths`: the five table columns have widths 70/70/130/45/50 at 96 dpi; each is multiplied by the display scaling (`px`). Called at creation and whenever the scaling changes.
* **L491-L538** `createControls`:
  * **L494** drop-down list (`COMBOBOX`, `CBS_DROPDOWNLIST` = choose only) for cameras. **L495** check box "IR image processing (grayscale only)". **L496** label. **L497** slider (`TRACKBAR_CLASSW`). **L498** label showing the slider value. **L499-L501** three registration buttons. **L502-L504** label, list box of registered people, remove button. **L505** label. **L506** list view in report (table) mode for today's attendance. **L507** CSV button. **L508** status text (multi-line).
  * **L510** `applyFonts(a)`: creates fonts for the current display scaling (section 1.1a) and gives them to all controls just created.
  * **L511** list view: select a full row, draw grid lines. **L512-L519** create the five columns Time, ID, Name, Type, Score (`LVCOLUMNW c`, fill `mask`, `pszText`, `cx`, send `LVM_INSERTCOLUMNW`), all with a provisional width of 50 (L517). **L520** `setColumnWidths` sets the real, scaled widths.
  * **L522-L524** add every camera name to the combo box (or "(no camera found)").
  * **L527-L529** read saved settings from `settings.ini`: threshold (integer, default 45 = 0.45), IR flag (default 1), camera index (default 0). **L530** an invalid saved camera index becomes 0.
  * **L531-L532** slider range 20..90 (0.20..0.90) and initial position. **L533** check box state. **L534** select the saved camera in the combo box. **L535-L537** show the threshold text, e.g. `0.45`.
* **L540-L568** `layoutControls`: computes the position of each control.
  * **L542-L543** the client rectangle. **L544** the lambda `S` converts a 96-dpi design value to real pixels. **L545** `x` = left edge of the panel = client width - `S(400)`; `w` = control width = `S(400) - S(8)`. **L546** `y` = running vertical position, starts at `S(8)`. **L547** the lambda `put(id, design height, x, width)` moves one control to the current `y` with height `S(height)`.
  * **L548-L555** the top part, each line followed by moving `y` down: camera list (L548), IR check box (L549), label + slider + value (L550-L552), the three buttons (L553-L555).
  * **L556-L560** the two flexible areas. All the other controls together need 364 design pixels; `flex` is the height that is left (at least `S(80)`); `listH` = 35 % of it for the list of people (at least `S(40)`); `tableH` = the rest for today's table (at least `S(40)`). This is why the panel still works at small window heights (down to 450 design px).
  * **L561-L567** the rest from top to bottom: label, list of people (height `listH`), remove button, label, table (height `tableH`), CSV button, status text.

### 1.5 `listCameras` (Camera.cpp L13-L65)

* **L13-L17** `ensureMF`: calls `MFStartup` (starts Media Foundation) exactly once; the `static bool done` remembers.
* **L19-L21** the GUID of Windows' "sensor camera" device category; IR cameras of Windows-Hello-style devices are registered there.
* **L23-L56** `enumCategory(sensor, out)`: asks Media Foundation for capture devices.
  * **L25-L26** create an attribute store (a small key/value bag used as the search filter).
  * **L27** filter: only video-capture devices.
  * **L28-L32** if `sensor` is true, additionally restrict to the sensor-camera category. This only compiles with a Windows 10 SDK (`NTDDI_WIN10_TH2`); with an older SDK the IR pass returns immediately.
  * **L33-L35** `MFEnumDeviceSources` returns an array `devs` of `n` device activators.
  * **L36-L54** for each device: **L37-L38** make a `CameraInfo`, remember the category; **L39-L42** read the friendly name (a string allocated by Media Foundation, freed with `CoTaskMemFree`); **L43-L46** read the symbolic link (the unique device path used later to open it); **L47** release the activator; **L48-L49** skip duplicates (a camera can be listed in both categories); **L50-L53** if new and valid, append " [IR]" to the name of sensor cameras and add it to the result.
  * **L55** free the array.
* **L58-L65** `listCameras`: start Media Foundation, collect normal cameras, then IR cameras, return the list.

### 1.6 `wWinMain`, second half (main.cpp L716-L738)

* **L716-L723** initial window size. **L719-L720** the size of title bar and borders. **L721** the work area of the monitor. **L722** `fitWindow(&app, min(px(780), 90 % of the work-area height - frame))`: the wanted client height is 780 design pixels but at most 90 % of the usable monitor height; the width follows from the video shape (4/3 until a camera reports another one). So the window never starts with wrong proportions, and on a small screen such as a 1366x768 laptop it shrinks (keeping the shape) to fit.
* **L726** create the `Engine`, giving it the camera, the shared state and the window handle (to post messages to).
* **L727-L728** initial threshold and IR flag from `settings.ini`.
* **L729** `engine->start(dataDir, base\models)`: starts the engine thread (section 1.7).
* **L730** compute the layout. **L731-L732** show and repaint the window.
* **L733-L736** unless `--no-camera`: **L734** start the camera chosen in the combo box (`startCamera`, section 1.10); **L735** if there is none, say so in the status text.
* **L737-L738** `DemoDriver driver; driver.start(...)`: starts the scripted-run thread; it does nothing when no scripted actions were given (section 5, `Demo.cpp`).

### 1.7 Engine start (Engine.cpp L30-L48, L67-L136)

* **L30-L32** constructor: stores the pointers; defaults: detector size 640, detector threshold 0.5, match threshold 0.45, IR on, margin 0.04, 2 votes needed, first track id 1, frame counter 0.
* **L36-L42** `start`: remember the folders, clear the stop flag, **create the thread** running `Engine::run`.
* **L67-L83** `run` (the engine thread):
  * **L69** `CoInitializeEx(..., MULTITHREADED)`: COM for this thread (the photo loader needs it).
  * **L70** `m_ready = init()`: load everything; false if a model is missing. **L71** `lastFlush`: time of the last attempt to write queued attendance rows.
  * **L72-L80** loop until `stop`: **L73** run queued commands from the UI (section 3); **L74** an empty image; **L75** wait up to 40 ms for a new frame (`waitFrame`, copy of the newest), and if one arrived call `processFrame` (section 2); **L76-L79** if attendance rows are queued because the CSV was locked (`pending() > 0`) and 3 seconds passed since the last try, try again (`flush`, section 2.7); when it works show "Attendance saved".
  * **L81** leaving: if rows are still queued, try one last time and otherwise write them to a side file (`spill`), so no recorded attendance is ever dropped. **L82** uninitialise COM.
* **L85-L136** `init`:
  * **L87** create the `data` folder if missing. **L88** `warn`: a text that is put in front of the status message. **L89-L106** load `gallery.bin` (section 1.8) and protect it: if loading fails (damaged file, wrong version) the file is **never overwritten**: **L92-L96** build a time stamp and the name `gallery.bin.corrupt-<yyyymmdd-hhmmss>`; **L97-L100** move the bad file to that name, set `warn` ("could not be read; kept as ...; starting with an empty list: restore a backup") and load again (a missing file = empty gallery, and the path is remembered for later saves); **L101-L104** if the move itself fails, set `m_galLocked` so that registration is disabled and the file stays untouched; **L105** warning beep. **L107** load `attendance.csv` (today's rows). **L108** `publishState()` so the window shows them.
  * **L110** full path of `models.ini` converted to the ANSI code page (needed by `GetPrivateProfileStringA`).
  * **L111-L112** thread count from the ini (default 4; invalid becomes 4). **L113** detector input size (640). **L114** detector confidence threshold (0.5).
  * **L116-L123** load the detector: model files, input blob name, three lists of output blob names (split by commas), thread count. On failure: show `warn` + an error text and return false.
  * **L124-L131** load the recognizer: files, input and output blob names, `mean` 127.5, `norm` 0.007843137 (= 1/127.5), whether to stretch contrast. On failure: `warn` + error text, return false.
  * **L132-L135** format and show `warn` + "Models loaded (4 threads)". Return true.
* **L9-L14** `iniStr`: reads one value from the ini file with a default (`GetPrivateProfileStringA`). **L16-L28** `splitList`: splits "out0,out1,out2" at commas and trims spaces/tabs from each item.
* **L44-L48** `stop`: set the stop flag and wait for the thread to end (`join`). Called again from the destructor (L34); calling it twice is harmless.

### 1.8 Loading the stored data

`Gallery::load` (Store.cpp L15-L40): file layout is `"FGAL"`, version 1, count, then per person-template: id length + id, name length + name, vector length + floats.
* **L17-L18** remember the path, clear memory. **L19-L20** open the file; if missing (first run) return true with an empty gallery.
* **L21-L24** read the 4-byte magic and compare with `FGAL`; read version (must be 1) and the count; any mismatch returns false (and `Engine::init` then moves the file aside instead of overwriting it, section 1.7).
* **L25-L38** for each entry: **L28-L30** read the id length (sanity limit 4096) and the id bytes; **L31-L33** same for the name; **L34-L36** read the vector length (1..4096) and the floats; **L37** append.
* **L12-L13** helpers `putU32` / `getU32` write/read a 4-byte unsigned number.

`AttendanceLog::open` (Store.cpp L147-L164): **L149-L151** remember path, find today's date text (`nowText(...).substr(0,10)` = `yyyy-mm-dd`), clear lists. **L152-L153** open the CSV; missing = nothing to load. **L155-L162** read line by line: **L156** split into columns (`splitCsv`, L107-L123, understands quotes); **L157** skip the header and rows of other days; **L158-L161** build an `AttRow`, add it to today's list and remember the time of the last record for this id (`parseTime`, L132-L139).

`nowText` (L97-L104): formats a time as `yyyy-mm-dd hh:mm:ss` in local time. `splitCsv` (L107-L123): walks the characters; inside quotes a doubled `""` means one quote; outside quotes a comma ends the field; `\r` is ignored. `csvQuote` (L125-L130): wraps text in quotes and doubles inner quotes. `parseTime` (L132-L139): reads `yyyy-mm-dd hh:mm:ss` with `sscanf`, converts year/month to the `tm` conventions (year-1900, month-1) and `mktime` to a time value. `AttendanceLog::rollDay` (L141-L145): if the date changed since last call (program left running over midnight) it clears today's data.

### 1.9 Loading the models

`FaceDetector::load` (FaceDetector.cpp L8-L27):
* **L13** require exactly three output names per kind. **L14-L18** copy them (strides 8, 16, 32). **L19** thread count. **L20** `use_vulkan_compute = false`: run on the CPU everywhere. **L21** input blob name. **L23-L24** `load_param` (network structure) and `load_model` (weights); non-zero means failure. **L25-L26** mark loaded.

`FaceRecognizer::load` (FaceRecognizer.cpp L14-L28): same pattern; additionally stores input/output blob names (L20), `mean` and `norm` (L21), the contrast-stretch flag (L22).

### 1.10 `startCamera` and `Camera::start`

`startCamera` opens the selected device. On success it reads `Camera::captureDescription()` and shows the actual capture mode in the status line, for example `1920x1080 @ 30 fps, output RGB32, native MJPEG`. On failure it displays the Media Foundation error.

`Camera::start` now:
* Stops any previous stream and checks that Media Foundation started successfully.
* Opens the device using its symbolic link; sensor-category devices are opened with the Windows sensor-camera category when the SDK supports it.
* Enumerates the camera's native media types and ranks them. The policy prefers 1920x1080 at 25 FPS or higher (targeting 30 FPS), then 1280x720, then 640x480, then the best remaining usable mode. Within a resolution tier it prefers a frame rate close to 30 FPS and MJPEG as the native USB format when otherwise equivalent.
* For each candidate native mode, asks the Source Reader for RGB32, then RGB24, YUY2, NV12, L8 or L16 output. This lets Media Foundation decode MJPEG where a suitable decoder is available. If conversion is unavailable, a supported native uncompressed format is accepted; unsupported compressed formats are skipped.
* Reads back the actual output dimensions, subtype, frame rate and signed stride. The selected mode is retained in `Impl` and reported by `captureDescription()`.
* Starts the capture thread only after a usable output format has been selected.

---

## 2. Every camera frame

### 2.1 Camera thread: `captureLoop` and `convertFrame` (Camera.cpp)

* `captureLoop` initializes COM for its worker thread, repeatedly calls `IMFSourceReader::ReadSample`, and skips gaps / failed samples.
* Each sample is converted to one contiguous buffer, locked, converted to packed RGB, and unlocked. A failed conversion drops that frame rather than reading beyond the buffer.
* Under the mutex, the newest RGB frame replaces the previous frame and the sequence counter increments. The condition variable wakes the engine thread. The capture loop clears its running flag when it exits.

`convertFrame` validates dimensions, stride and buffer length before allocating the RGB output. It handles RGB32, RGB24, YUY2, NV12, L8 and L16. Negative stride is treated as bottom-up storage. NV12 uses a separate interleaved chroma plane; YUY2 shares chroma between pairs of pixels. Unsupported formats are rejected.

`yuv2rgb` performs the integer YUV-to-RGB conversion; `clamp8` keeps channel values in the 0–255 range.

### 2.2 `Camera::waitFrame` and `injectFrame` (Camera.cpp)

* `waitFrame` locks the mutex and waits up to `timeoutMs` for a sequence number newer than `lastSeq`. It copies the newest frame out, updates `lastSeq`, and returns false on timeout or an empty frame.
* `injectFrame` stores a frame as if the camera produced it (used by `tools\app_test.cpp` and demos).

### 2.3 Engine thread: `processFrame` (Engine.cpp L207-L355)

**Preparation**
* **L209-L211** start a high-resolution timer.
* **L213** if IR mode: `toGray(img)` makes the picture pure grey (`ImageIO.cpp` L75-L84: `(77R+150G+29B)>>8` into all three channels).
* **L214** frames wider than 960 px are shrunk (`shrinkToWidth`, ImageIO.cpp L86-L115: bilinear sampling).
* **L216** `views` collects what the window will draw. **L217** only if the models loaded.

**Step 1: detect (L219)** `m_det.detect(img, 640, 0.5)`: section 2.4.

**Step 2: tracking (L221-L256)** keeps the same identity on a face from frame to frame.
* **L222-L229** for every (existing track, new detection) pair compute the overlap `iou` (L159-L167: intersection area / union area); pairs above 0.25 are candidates.
* **L230** sort candidates best first.
* **L232** `tUsed`, `dUsed` mark who is already paired. **L233-L242** walk the sorted pairs; skip if either side is used; otherwise update the track: **L237** store the new detection, **L238-L239** move the smoothed box halfway to the new box (reduces jitter), **L240** reset `missed`, increase `age`, **L241** mark both used.
* **L243-L244** tracks without a detection count one more miss. **L245-L247** if a track being registered is lost for more than 8 frames, tell the user. **L248-L249** delete tracks missed more than 8 frames.
* **L250-L256** every unpaired detection becomes a new track with the next id (`m_nextId++`).

**Step 3: recognise (L258-L321)**
* **L259** `budget = 3`: at most three embeddings per frame so a crowd cannot stall the frame rate.
* **L260-L262** for each visible track.
* **L263-L265** `need` = the track is being registered, or is unconfirmed and 2 frames have passed since the last attempt, or is confirmed and 45 frames have passed (re-check now and then).
* **L266** skip if not needed or `goodQuality` fails (L170-L176: eyes at least 24 px apart; nose x between the two eyes, which rejects tiny and strongly turned faces).
* **L267-L268** use one unit of budget; remember when it was tried.
* **L270-L271** compute the embedding (section 2.5); skip if it failed.
* **L273-L288** registration mode: **L274** keep this embedding; **L275** after 5: **L276-L282** average them, normalise the average to length 1; **L283** store as a template (`addTemplate`, section 3); **L284** message; **L285** leave registration mode. **L287** `continue`: a face being registered is not also matched.
* **L290** `match(emb)` (section 2.6).
* **L291-L316** accepted match: **L292** same person as the candidate of the previous attempt: `streak++`, else start a new candidate with streak 1; **L293** remember the score; **L294-L296** a confirmed track suddenly matching someone else is reset; **L297** after `m_votes` (2) agreeing results and not yet confirmed: **L298** confirm and remember who; **L299-L300** only the first time (`reported`): **L301** `m_att.mark(...)` decides IN / OUT / duplicate (section 2.7); **L302-L314** if a row was recorded: format the time (L303-L307), `publishState()` to refresh the table (**L308**), build the text "NAME (ID) checked IN at HH:MM:SS" (**L309**), append "NOT SAVED YET: attendance.csv is locked, close it in Excel; retrying" if the file refused the row (`pending() > 0`, **L310-L311**), show it (**L312**), beep (**L313**).
* **L317-L320** no accepted match: forget the candidate, keep the score, un-confirm.

**Step 4: describe the faces for the window (L323-L343)** for each visible track build a `FaceView`: **L329-L330** box as fractions of the image (0..1) so the window does not need to know the image size; **L331** the five landmarks the same way; **L334-L341** the label and colour state: registering ("Registering n/5", orange), confirmed (name + score, green), candidate ("Verifying...", orange), otherwise "Unknown" (red).

**Hand-over (L346-L354)**
* **L346** stop the timer. **L347-L353** under the mutex: move the picture into `SharedState`, move the face list, compute the milliseconds, set `frameNew`. **L354** `PostMessage(WM_APP_FRAME)` wakes the UI thread.

### 2.4 `FaceDetector::detect` (FaceDetector.cpp L57-L132)

* **L60** return nothing if the model is not loaded or the image is empty.
* **L63** `scale` fits the longer side into `S` (640). **L64-L65** the resized size `nw` x `nh`. **L66** network size `tw`,`th` = 640. **L67** `sx`,`sy`: factor to convert network pixels back to image pixels (1/scale).
* **L71-L72** resize the RGB image to `nw` x `nh`. **L73-L75** normalise each channel `(x - 127.5) / 128` (what SCRFD was trained with). **L76-L77** pad bottom/right with 0 (the mean colour after normalisation) up to 640x640. The model has this size baked in, so every input must be exactly 640x640.
* **L79-L80** create an extractor and feed the input blob.
* **L86** the three strides 8, 16, 32 (each output grid cell covers that many pixels). **L88-L120** for each stride:
  * **L91-L94** fetch three outputs: scores (`cls`), box distances (`box`), landmark offsets (`lmk`); skip the stride if any fails.
  * **L95** `fw` = number of grid columns. **L97** number of candidate rows `rows` (two anchors per cell). **L98** raw float pointers.
  * **L100-L119** for each row `r`: **L101-L102** discard scores below the threshold; **L104** `cell = r/2` (two anchors share a cell); **L105-L106** the cell's centre in network pixels; **L107-L108** this row's box and landmark data (`box.w`=4, `lmk.w`=10 floats per row); **L110-L118** build a `FaceDet`: box = centre minus/plus the four distances times stride, landmarks = centre plus offsets times stride, all multiplied by `sx`/`sy` to get image pixels; **L118** keep it.
* **L123** `nms` (L41-L53): sort by score, keep a box only if it overlaps no better kept box by more than 0.4 (`iouOf`, L29-L38). **L124-L130** clip every box to the image and drop empty ones.

### 2.5 `FaceRecognizer::extract` (FaceRecognizer.cpp L100-L128)

* **L102** need loaded model and image. **L104-L105** `alignFace` writes a 112x112 RGB crop into `crop`. **L106** optional contrast stretch.
* **L108-L111** make an ncnn image from the crop and normalise `(x - mean) * norm` (127.5 and 1/127.5).
* **L113-L116** run the network and read the output blob.
* **L118-L120** copy the 512 numbers into `emb`.
* **L122-L126** L2-normalise (divide by the vector length) so that a dot product of two embeddings equals their cosine similarity.

`alignFace` (L47-L78) makes every face upright and the same size:
* **L49-L51** the mean of the detected landmarks (`ms*`) and of the template landmarks (`md*`). The template (L8-L9) is the standard ArcFace position of the 5 points in a 112x112 image.
* **L53-L60** accumulate, over the centred points, `num_a = sum(sx*dx + sy*dy)`, `num_b = sum(sx*dy - sy*dx)`, `den = sum(sx^2 + sy^2)`.
* **L62** the best rotation+scale as a complex number `a + ib = num / den` (matrix `[a -b; b a]`). **L63-L64** the shift so that the mean maps onto the mean. **L65** `inv` = the factor for the inverse matrix.
* **L68-L77** for each output pixel find where it came from: **L70-L72** inverse transform; **L73-L75** sample the source with `sampleChannel` (L31-L42: bilinear interpolation, coordinates clamped to the border) for R, G, B.

`stretchContrast` (L82-L98): **L84-L86** histogram of luminance; **L87-L91** find the 1% and 99% levels `lo`, `hi`; **L92** skip almost-flat images; **L93-L97** map `lo..hi` linearly to 0..255 for every channel value. This makes dim infra-red faces comparable to well lit ones.

### 2.6 `Engine::match` (Engine.cpp L180-L204)

* **L183** the stored templates. **L186-L191** for each template with the same vector length compute the dot product (= cosine) and keep the best (`best`, index `bi`). **L192** no templates: return "no match".
* **L194-L200** `second` = best score among templates of a **different person** (two photos of one person must not count as a tie).
* **L201** result carries the best person's id, name and score. **L202** `ok` only if `best >= threshold` **and** `best - second >= margin (0.04)`.

### 2.7 `AttendanceLog::mark`, `flush`, `spill` (Store.cpp L166-L232)

* **`mark` (L166-L187)** decides and records an event. **L168** roll the day if needed. **L169** current time. **L170** default kind `IN`. **L171-L175** if this person already has a record today: **L173** less than `gapMinutes` (30) ago means duplicate: return an empty string; **L174** otherwise the new record is `OUT`.
* **L177-L178** build the row. **L182-L184** record it in memory **first**: today's list (shown in the table), the "last record" map (used by the 30-minute rule), and the queue `m_pending` of rows not yet in the file. **L185** `flush()` tries to write the queue. **L186** return the kind. Because the event is already in memory and queued, it can no longer be lost when the file is locked.
* **L189-L190** `kBom` (UTF-8 byte-order mark, so Excel shows any language) and `kHeader`. **L192-L197** `writeRow`: writes `time,"id","name",kind,score` and CRLF.
* **`flush` (L199-L218)** appends the queued rows to `attendance.csv`. **L201** nothing queued: success. **L202-L206** is the file new or empty (`fresh`)? **L207-L208** open for append; if another program (Excel) holds the file, opening fails and the function returns false: the rows **stay queued** for the next attempt (every 3 s from `Engine::run`). **L209** a new file starts with BOM and header. **L210-L215** write the rows one by one, flushing after each, and stop at the first write error. **L216** remove from the queue only the rows really written. **L217** true when the queue is empty.
* **`spill` (L220-L232)** last resort when the program quits with rows still queued: writes them, with BOM and header, to a new file `attendance.csv.unsaved-<time>.csv` next to the log (**L223-L227**), so the administrator can merge them later (section 4.1 of `DATABASE_MANAGEMENT.md`).

### 2.8 `publishState` and `setMessage` (Engine.cpp L139-L156)

Both lock the shared mutex, copy the data (message, or today's rows and the people list from `Gallery::labels`, Store.cpp L81-L94) and post `WM_APP_STATE` so the window refreshes. `labels` lists each person once as `id - name  [number of templates]`.

### 2.9 UI thread: `WM_APP_FRAME` (main.cpp L630-L637, `takeFrame` L294-L341)

* **L296-L305** under the mutex: **L298** leave if nothing new; **L299** clear the flag; **L300-L302** copy size, swap the pixels; **L303** copy the faces; **L304** the milliseconds.
* **L306-L316** the camera's shape: **L307** the new frame's width / height; **L308** if it differs by more than 1 % from `a->aspect`: **L309** remember it; **L310** unless the window is maximised or minimised, **L311-L313** `fitWindow(a, client height)`: same height, new width, so the video area fits the new picture exactly. This happens once for the first frame of a 16:9 camera, and again if the user switches to a camera with another shape.
* **L317-L319** clear the selection if the selected face disappeared.
* **L321-L328** convert RGB to BGR with rows padded to a multiple of 4 bytes (what GDI requires).
* **L330-L340** count the frame; once per second compute the frames per second and write status text "Analysis: x fps, y ms/frame, n face(s)".
* **L632-L635** `WM_APP_FRAME` calls `takeFrame`, then invalidates the video rectangle so Windows sends `WM_PAINT`.

### 2.10 `WM_PAINT`, `paintAll`, `paintVideo`, `drawFaces` (main.cpp L603-L614, L570-L578, L263-L291, L224-L261)

* **L603-L604** `WM_ERASEBKGND` returns 1: we paint everything ourselves, so Windows must not erase first (no flicker).
* **L605-L611** `WM_PAINT`: `BeginPaint`, `paintAll`, `EndPaint`. **L612-L614** `WM_PRINTCLIENT`: the same painting into the device context Windows hands over; this is what `PrintWindow` uses for screenshots.
* **L570-L578** `paintAll`: **L573** the video area; **L574-L576** fill the panel area with the standard button colour; **L577** `paintVideo`.
* **L263-L291** `paintVideo`: **L265-L268** create an off-screen bitmap the size of the video area; **L269-L270** fill black; **L272-L273** compute where the picture goes (`imageRect`, L171-L183: scale to fit keeping the aspect ratio, centred; because the window obeys the shape rule the picture normally fills the whole area); **L274-L280** describe the BGR image (negative height = top-down); **L281-L284** `StretchDIBits` draws it with smoothing; **L285** `drawFaces`; **L287** one `BitBlt` copies the finished picture to the window; **L288-L290** free the GDI objects.
* **L224-L261** `drawFaces`: **L226** size of the picture area in pixels; **L227-L229** drawing setup (no fill, bold font, opaque text background). For each face: **L232-L234** colour by state (green confirmed, orange verifying, red unknown, cyan if selected); **L236-L237** the box in pixels; **L238-L243** draw the rectangle with a pen whose width is `px(2)` (`px(4)` if selected), so lines scale with the display; **L245-L254** the five landmarks as dots of radius `px(3)` (L248-L252); **L256-L259** the label on a coloured background `px(20)` above the box.

### 2.11 Keeping the window's shape: `WM_SIZE`, `WM_SIZING`, `WM_DPICHANGED`, `WM_GETMINMAXINFO` (main.cpp L591-L602, L615-L629, L671-L679)

* **WM_SIZE (L591-L602)**: **L593** if the window has a normal (restored) size and we did not cause the change ourselves (the system resized it: clamping, snapping to a screen half, ...): **L596** compute the actual shape `(client width - panel) / client height`; **L597** if it differs from `aspect` by more than 1.5 %, `fitWindow` restores it. **L599-L600** then re-layout the controls and repaint.
* **WM_SIZING (L615-L617)**: while the user drags an edge, `lockAspect` (section 1.1a) corrects the proposed rectangle before Windows applies it; returning TRUE tells Windows it was changed. The window therefore resizes only in the correct proportions.
* **WM_DPICHANGED (L618-L629)**: the window was moved to a monitor with another display scaling. **L620** Windows proposes a new rectangle for that monitor; **L621-L623** apply it (with `adjusting` set); **L624** new fonts; **L625** new column widths; **L626** re-layout (every size is recomputed from `px`); **L627** repaint. The panel, buttons, fonts and lines all keep their proportions.
* **WM_GETMINMAXINFO (L671-L679)**: the smallest allowed window: height `px(450)` plus frame, width from the shape rule. It is also what prevents the controls from being squeezed.
* A **maximised** window does not obey the shape rule (Windows fills the screen); the picture is then centred by `imageRect` with black bars, never stretched.


---

## 3. User actions (`WM_COMMAND` and friends)

### 3.1 Selecting a face: `WM_LBUTTONDOWN` (main.cpp L641-L655)
Convert the click position to fractions of the picture (`nx`, `ny`, L646-L647) and select the track whose box contains it (L649-L652); repaint.

### 3.2 Threshold slider: `WM_HSCROLL` (L656-L667)
Read the slider (`v`, L658), show it as `0.vv` (L659-L661), tell the engine (`setThreshold`, L662, an atomic variable), save it in `settings.ini` (L663-L665).

### 3.3 `onCommand` (main.cpp L408-L476)
* **IDC_CAMERA (L411-L417)** a new selection restarts the camera and saves the index.
* **IDC_IR (L418-L423)** read the check box, tell the engine (`setIr`), save.
* **IDC_BTN_SEL (L424-L429)** needs a selected face; `askIdName` opens the dialog; `requestEnroll` sends the command to the engine.
* **IDC_BTN_PHOTOS (L430-L438)** ask ID and name, `pickPhotos` (L388-L406: file dialog with multi-select; the result buffer holds `dir\0file1\0file2\0\0`, or just the full path for a single file), then `enrollImages`.
* **IDC_BTN_FOLDER (L439-L453)** folder picker (`SHBrowseForFolderW`), convert the chosen item to a path, `enrollFolder`; `CoTaskMemFree` releases the item.
* **IDC_BTN_REMOVE (L454-L466)** find the selected list entry's id under the mutex, ask for confirmation, `removePerson`.
* **IDC_BTN_CSV (L467-L474)** open `data\attendance.csv` with the default program (Excel).

`askIdName` (L212-L221) shows dialog `IDD_REGISTER` (defined in `FaceAttendance.rc`); `regProc` (L188-L210): **L192** keep the pointer to the result struct; **L195-L205** on OK read the two edit fields, trim trailing spaces of the id, refuse an empty id, use the id as name if the name is empty, close the dialog; **L206** cancel closes it.

### 3.4 How commands reach the engine thread
`Engine::post` (Engine.cpp L50-L54) appends a function to a list under a mutex; `runCommands` (L56-L64) swaps the list out (short lock) and runs the functions on the engine thread at the top of every loop turn (L73). So all gallery changes happen on one thread.

### 3.5 Registration from the camera: `requestEnroll` (Engine.cpp L366-L378)
Find the track with that id; set `enrolling`, the id/name, clear collected embeddings; show "Hold still...". During the next frames the code at L273-L288 (section 2.3) collects 5 embeddings, averages them and calls `addTemplate` (L358-L364): **L360** first refuse (with a message) if the gallery file was damaged and could not be moved aside (`m_galLocked`, see section 1.7); then `Gallery::add` (Store.cpp L64-L71: updates the name of an existing id, appends the template), `Gallery::save` (L42-L62: writes to `gallery.bin.tmp`, then renames over the old file, so a crash cannot leave a half-written file), `publishState`.

### 3.6 Registration from photos: `enrollImages`, `doEnrollFiles` (Engine.cpp L401-L426)
For each file: **L407** `loadImageRgb`; **L410** `embedBest` (L381-L394: detect, take the face with the largest box area, embed); **L411** `addTemplate`; messages for problems; **L418-L420** final "name: n of m photos registered".

`loadImageRgb` (ImageIO.cpp L32-L73): **L34-L37** create the Windows Imaging Component factory; **L39-L44** open the file and take frame 0; **L46-L54** read the EXIF orientation tag (274) if present; **L56-L60** a format converter to 24-bit RGB; **L62-L69** read the size and copy the pixels; **L71** `applyOrientation` (L10-L30) rotates by 90/180/270 degrees according to the tag, so phone photos are upright.

### 3.7 Folder import: `enrollFolder` (Engine.cpp L428-L457)
Lists sub-folders (L432-L439), splits each folder name at the first `_` into id and name (`1001_Alice`, L442-L444), collects `*.jpg *.jpeg *.png *.bmp` (L446-L452), and calls `doEnrollFiles` for each person.

### 3.8 Removing a person: `removePerson` (Engine.cpp L459-L468)
Deletes all templates with that id (`Gallery::remove`, Store.cpp L73-L79), saves, resets any live track that was confirmed as that person, publishes the new lists.

### 3.9 `WM_APP_STATE` (main.cpp L638-L640, `takeState` L343-L377)
Copies message, today's rows and the people list under the mutex; shows the message; rebuilds the list view newest first (**L359-L370**: one row per record, columns time-of-day, id, name, kind, score) with redraw switched off while rebuilding (L357, L371); rebuilds the people list box (L373-L376).

---

## 4. Shutdown (main.cpp L740-L751, L680-L682)

* **L740-L743** the message loop: `GetMessageW` waits for a message; `IsDialogMessageW` handles Tab navigation between controls, otherwise the message is translated and dispatched to `wndProc`.
* **L680-L682** closing the window sends `WM_DESTROY`, which posts `WM_QUIT`; `GetMessageW` then returns 0 and the loop ends.
* **L745** `driver.stop()` joins the scripted-run thread. **L746** `engine->stop()` joins the engine thread (which first writes any unsaved attendance, section 1.7); **L747** `camera.stop()` joins the capture thread and shuts the device down (Camera.cpp L204-L213); **L748** delete the engine; **L749** `OleUninitialize`; **L750** exit code 0.


---

## 5. Headers and small files (no line numbers: described member by member)

### `Types.h`
* `FaceDet`: one detection in pixel coordinates: box `x0,y0,x1,y1`, `score`, five landmarks `lx[5]`,`ly[5]` (left eye, right eye, nose, left and right mouth corner).
* `RgbImage`: width `w`, height `h`, `data` = tightly packed RGB bytes (3 per pixel, no padding).
* `GalleryEntry`: person `id`, `name` (UTF-8) and one `emb` vector (one stored template).
* `FaceView`: what the window draws: `trackId`, box `x,y,w,h` and landmarks as fractions 0..1, `label`, `state` (0 unknown, 1 verifying, 2 confirmed), `score`. The constructor zeroes everything.
* `FloatVec`, `FaceViewList`: short names for vectors.

### `Util.h`
`toWide` / `toUtf8` convert between UTF-8 `std::string` (used inside the program) and UTF-16 `std::wstring` (used by Windows APIs) with `MultiByteToWideChar` / `WideCharToMultiByte`; `toAnsi` converts to the system code page (ncnn and `GetPrivateProfileStringA` need it); `exeDir` returns the folder of the running exe (`GetModuleFileNameW`, cut at the last backslash).

### `Store.h`
Declares `Gallery` (`load`, `save`, `add`, `remove`, `entries`, `labels`), `AttRow` (one attendance record) and `AttendanceLog` (`open`, `mark`, `today`, and `flush`, `pending`, `spill` for rows the CSV could not take). Private members: file path, the list of templates / today's rows, the queue `m_pending` of rows not yet written to the file, the current day text, and a map `id -> time of the last record today`.

### `ImageIO.h`
Declares `loadImageRgb`, `toGray`, `shrinkToWidth` (described in sections 2.3 and 3.6).

### `Camera.h`
`CameraInfo` (name, symbolic link, `sensor` flag), `listCameras`, class `Camera`: `start`, `stop`, `captureDescription`, `waitFrame`, `injectFrame`; private: `captureLoop`, a hidden `Impl` (COM objects, selected mode and stride), the capture thread, an atomic `m_running`, a mutex + condition variable, the newest frame `m_frame` and its counter `m_seq`.

### `Engine.h`
* `WM_APP_FRAME`, `WM_APP_STATE`: private window messages the engine posts.
* `SharedState`: mutex `m` guarding the last analysed `frame`, its `faces`, `ms`, `frameNew`, the status `message`, `today`'s rows and the people lists.
* `Engine`: public thread-safe setters `setThreshold`, `setIr` and commands `requestEnroll`, `enrollImages`, `enrollFolder`, `removePerson`. Private: `Track` (one followed face: latest detection, smoothed box, miss/age counters, candidate id and streak, confirmed flag, registration state), `Match` (result of a gallery search), the models, the stores, the flag `m_galLocked` (gallery file damaged and could not be moved aside: never write it), atomics `m_thr` / `m_ir` (written by the UI thread, read by the engine thread), the command list with its mutex, the track list and counters.

### `FaceDetector.h`, `FaceRecognizer.h`
Declare the classes with `load` and `detect` / `extract` and the private ncnn network plus configuration strings.

### `Demo.h`, `Demo.cpp` (scripted runs without a camera)
Used for the workflow demonstration and the screen-size tests (`tools\run_demo.ps1`); a normal start has none of these options and the thread is never created.

Command line: `--no-camera` (never list or open a camera), `--data <folder>`, `--ir <0|1>`, `--scale <percent>`, `--screen <W>x<H>`, `--import <folder>@<ms>`, `--feed <image>@<ms>` (`none` stops), `--shot <png>@<ms>`, `--report <txt>@<ms>`, `--quit@<ms>`; `@<ms>` = time after start.

* `Demo.h`: `DemoAction` (time, kind, argument), `DemoOptions` (all settings; `active()`), `parseDemoArgs`, class `DemoDriver` (`start`, `stop`, private `run`, the thread and a stop flag).
* **Demo.cpp L15-L17** defines `PW_RENDERFULLCONTENT` for older SDKs.
* **L19-L26** `restoreIfMinimized`: a minimised window has no client area (0x0), so a screenshot or layout report of it is useless. If something on the desktop minimised the window (this happened in about 1 of 12 repeated test runs), **L23** return if it is not minimised, **L24** `ShowWindow(SW_RESTORE)`, **L25** wait half a second for the window to lay itself out again. Called first in `shot` (L90) and `report` (L129).
* **L29-L36** `splitAt`: splits `"value@1234"` at the LAST `@` into the value and the time in ms.
* **L38-L67** `parseDemoArgs`: **L41** split the command line into arguments (`CommandLineToArgvW`); **L44-L62** walk them: **L47-L51** simple options (`--no-camera`, `--data`, `--ir`, `--scale`, `--screen WxH` parsed with `swscanf`); **L52-L55** the timed options `--import/--feed/--shot/--report`: kind = option name without `--`, argument and time via `splitAt`; **L56-L59** `--quit@ms`; **L61** unknown options are ignored on purpose. **L63** free the argument list. **L64-L65** sort the actions by time (stable). **L66** false if an option was malformed.
* **L70-L86** `savePng`: writes a 32-bit BGRA picture as PNG with the Windows Imaging Component: factory (L72-L73), file stream (L74-L75), PNG encoder (L76-L77), one frame (L78-L80), size and pixel format (L81-L83), the pixels (L84), commit (L85).
* **L88-L109** `shot`: screenshot of the window's client area: **L92-L94** size; **L95-L98** a memory bitmap of that size; **L99** `PrintWindow(..., PW_CLIENTONLY | PW_RENDERFULLCONTENT)` makes the window paint itself into it (also works for parts outside the real screen; this uses the `WM_PRINTCLIENT` handler, section 2.10); **L100-L105** read the pixels top-down with `GetDIBits`; **L106** set alpha to opaque; **L107** free; **L108** save as PNG.
* **L112-L125** `reportChild`: writes one line `control <id> <class> <left> <top> <right> <bottom>` for a control, in client coordinates; **L116** skips parts that live inside a control (for example the edit box inside a combo box).
* **L127-L140** `report`: writes `client W H`, `window W H`, `system_dpi N` and the control lines. `tools\check_layout.py` reads this to check that all controls lie inside the window and do not overlap.
* **L143-L157** `DemoDriver` constructor, destructor, `start` (starts the thread only if there are actions), `stop`.
* **L159-L183** `run` (the demo thread): **L161** COM for this thread; **L162** start time; **L163-L165** the picture being fed, whether feeding, index of the next action; **L166-L181** loop every 100 ms: **L167** elapsed time; **L168-L178** run every action whose time has come: **L170** `import` -> `Engine::enrollFolder`; **L171-L174** `feed` -> load the picture (or stop); **L175** `shot`; **L176** `report`; **L177** `quit` -> post `WM_CLOSE` to the window and leave; **L179** while feeding, `Camera::injectFrame` sends the picture as a camera frame (about 10 per second, like a slow camera); **L180** wait 100 ms.

### `app.manifest`
An XML file the linker merges into the exe (project setting *Additional Manifest Files*). It declares `dpiAware true/pm` and `dpiAwareness PerMonitorV2,PerMonitor`: the program handles display scaling itself, per monitor, so Windows does not stretch its window as a blurry bitmap on 125 %, 150 % or 200 % screens (Windows 10 version 1703 uses PerMonitorV2; older Windows 10 uses the `true/pm` entry; Windows 7 ignores both). It also lists Windows 10 and 8.1 as supported systems.

### `resource.h`, `FaceAttendance.rc`
Numeric ids for the dialog (`IDD_REGISTER`), its two edit fields and every control of the main window. The `.rc` file defines the dialog: two labels, two edit boxes (ID, name), OK and Cancel.

### `models\models.ini`
`[general] threads`; `[detector]` input blob, the three lists of output blobs, `size`, `score`; `[recognizer]` input/output blob, `mean`, `norm`, `contrast_stretch`.

### Files created at run time (next to the exe)
`settings.ini` (threshold, IR flag, camera index), `data\gallery.bin` (templates), `data\attendance.csv` (attendance, UTF-8 with BOM).

---

## 6. Change log of this document
* Initial version: describes the plain Win32 / Media Foundation / WIC program (no Qt).
* Data-loss fixes: a damaged `gallery.bin` is moved aside (`.corrupt-<time>`) instead of being overwritten (`Engine::init`, `m_galLocked`); attendance rows are recorded in memory first, queued when `attendance.csv` is locked, retried every 3 s and written to a side file at exit (`AttendanceLog::flush/spill`, `Engine::run`). All `Engine.cpp` line numbers re-numbered; sections 1.7, 2.3, 2.7, 3.5 and the `Store.h` / `Engine.h` notes updated.
* Demo driver: `restoreIfMinimized` added (a desktop-minimised window gave an empty 0x0 report in some runs); `Demo.cpp` line numbers re-numbered.
* Interface scaling and shape: per-monitor DPI awareness (`app.manifest`, `dpiOf`/`px`), fonts and all sizes scaled, window kept in the video's aspect ratio (`fitWindow`, `lockAspect`, `WM_SIZING`, `WM_SIZE`, `WM_DPICHANGED`), flexible lists so the panel fits down to a 450 px client height, aspect re-fitted when the camera's shape is known; scripted-run options and driver (`Demo.cpp`, `Demo.h`); `main.cpp` line numbers re-numbered; sections 1.1-1.4, 1.6, 2.9-2.11, 4 and 5 rewritten.
