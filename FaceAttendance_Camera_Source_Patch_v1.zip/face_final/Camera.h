// Camera.h - UVC / Media Foundation capture for normal and supported sensor cameras.
#pragma once
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include "Types.h"

struct CameraInfo
{
    std::wstring name;
    std::wstring link;      // Symbolic link identifies the device.
    bool sensor;            // Enumerated from the Windows sensor-camera category.
    CameraInfo() : sensor(false) {}
};

std::vector<CameraInfo> listCameras();

class Camera
{
public:
    Camera();
    ~Camera();

    // Capture-mode policy:
    // 1) Prefer 1920x1080 at >=25 FPS, targeting 30 FPS.
    // 2) Fall back to 1280x720 at >=25 FPS.
    // 3) Fall back to 640x480 at >=25 FPS, then the best remaining usable mode.
    // MJPEG is preferred as the native USB format when otherwise equivalent; Media
    // Foundation is asked to decode it to RGB32/RGB24, with YUY2/NV12/grayscale fallbacks.
    bool start(const CameraInfo &info, std::string &err);
    void stop();

    // Describes the actual selected mode, e.g. "1920x1080 @ 30 fps, output RGB32, native MJPEG".
    // Empty when the camera is stopped.
    std::string captureDescription() const;

    // Waits until a frame newer than lastSeq exists (or timeout). Only the newest frame is
    // kept, so a slow consumer automatically skips frames and latency does not build up.
    bool waitFrame(RgbImage &out, unsigned long long &lastSeq, int timeoutMs);

    // Feeds a frame as if the camera had delivered it (used by tests and demos).
    void injectFrame(const RgbImage &img);

private:
    void captureLoop();

    struct Impl;
    Impl *m_impl;
    std::thread m_thread;
    std::atomic<bool> m_running;
    std::mutex m_mutex;
    std::condition_variable m_cv;
    RgbImage m_frame;
    unsigned long long m_seq;
};
