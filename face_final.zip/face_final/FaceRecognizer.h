// FaceRecognizer.h - landmark alignment + MobileFaceNet/ArcFace embedding on NCNN.
#pragma once
#include <net.h>
#include <string>
#include "Types.h"

class FaceRecognizer
{
public:
    FaceRecognizer();

    bool load(const std::string &paramPath, const std::string &binPath,
              const std::string &inputName, const std::string &outputName,
              float mean, float norm, bool contrastStretch, int threads);

    // Warp the face to the canonical 112x112 pose, then run the network.
    // emb receives an L2-normalised vector, so cosine similarity == dot product.
    bool extract(const RgbImage &img, const FaceDet &face, FloatVec &emb) const;

private:
    ncnn::Net   m_net;
    std::string m_in, m_out;
    float       m_mean, m_norm;
    bool        m_stretch, m_loaded;
};
