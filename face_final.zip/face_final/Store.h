// Store.h - persistence without a database: a small binary file for the face
// templates and a CSV file for the attendance log (opens directly in Excel).
// Used by the engine thread only.
#pragma once
#include <ctime>
#include <map>
#include <string>
#include <vector>
#include "Types.h"

class Gallery
{
public:
    bool load(const std::wstring &path);     // missing file = empty gallery (not an error)
    bool save() const;
    void add(const std::string &id, const std::string &name, const FloatVec &emb);
    bool remove(const std::string &id);
    const std::vector<GalleryEntry> &entries() const { return m_e; }
    void labels(std::vector<std::string> &ids, std::vector<std::string> &texts) const;  // one per person

private:
    std::wstring m_path;
    std::vector<GalleryEntry> m_e;
};

struct AttRow
{
    std::string time, id, name, kind;        // kind = IN / OUT
    float score;
    AttRow() : score(0.f) {}
};

class AttendanceLog
{
public:
    bool open(const std::wstring &path);
    // Returns "IN" / "OUT" if a record was written, "" if the person was already
    // recorded less than gapMinutes ago.
    std::string mark(const std::string &id, const std::string &name, float score, int gapMinutes);
    const std::vector<AttRow> &today() const { return m_today; }

    // Rows that could not be appended (typically: the CSV is open in Excel) wait here.
    bool   flush();                          // try to append the queued rows; false = still locked
    size_t pending() const { return m_pending.size(); }
    bool   spill();                          // last resort at exit: write queued rows to a side file

private:
    void rollDay();
    std::vector<AttRow> m_pending;           // recorded in memory, not yet in the file
    std::wstring m_path;
    std::string  m_day;                      // "yyyy-mm-dd" of the rows in m_today
    std::vector<AttRow> m_today;
    std::map<std::string, time_t> m_last;    // person id -> last record today
};
