# Database management: Face Attendance

Audience: developers and administrators who run, back up and maintain the program.

**How to read this document.** Sections marked **[Implemented]** describe what the code does today. Sections marked **[Recommended]** are proposals that are *not* in the code yet. Nothing here has been tested on a production deployment.

## Contents
1. What data exists
2. Current storage design [Implemented]
3. Known weaknesses of the current design
4. Daily operations: backup, restore, export, import, deletion
5. Data integrity and recovery
6. Privacy and security of biometric data
7. Capacity and performance
8. When and how to move to a real database [Recommended]
9. Rules for changing the data format
10. Administrator checklists

---

## 1. What data exists

| Data | Content | Sensitivity | Where |
|---|---|---|---|
| **Face templates** | For each registered person: ID, name, and one or more 512-number vectors (embeddings) | **High**: derived from the face, i.e. biometric data | `data\gallery.bin` |
| **Attendance log** | One row per IN/OUT event: time, ID, name, type, match score | Medium: personal data about presence and times | `data\attendance.csv` |
| **Settings** | Match threshold, IR mode, camera index | Low | `settings.ini` (next to the exe) |
| **Model files** | Neural-network weights and blob names | Not personal; licence applies | `models\` |

The program does **not** store photos or video. Registration photos are read, turned into a vector and discarded. Embeddings cannot easily be turned back into a picture, but treat them as biometric data anyway: they identify a person.

All paths are relative to the folder of `FaceAttendance.exe`.

## 2. Current storage design [Implemented]

The program uses plain files instead of a database engine: no installation, nothing to configure, easy to copy. All access happens in one place: the **engine thread** owns the gallery and the log (`Engine.cpp`, `Store.cpp`). The window thread only receives copies. Because only one thread touches the files, no locking inside the program is needed.

### 2.1 Face templates: `data\gallery.bin`
Binary file, little-endian:

| Offset | Field | Meaning |
|---|---|---|
| 0 | `"FGAL"` (4 bytes) | magic: identifies the file type |
| 4 | `u32` version | currently `1`; any other value makes loading fail |
| 8 | `u32` count | number of templates in the file |
| then, per template | `u32` idLen, id bytes (UTF-8) | person ID |
| | `u32` nameLen, name bytes (UTF-8) | display name |
| | `u32` dim, `dim` x `float32` | the embedding (512 values, length 1) |

* **One person can have many templates** (day photo, IR capture, 5-frame camera capture). All rows with the same ID belong to the same person. Matching takes the best template of each person.
* **Saving** (`Gallery::save`): the whole file is written to `gallery.bin.tmp`, then renamed over the old file with `MoveFileExW(... REPLACE_EXISTING)`. A crash while writing leaves the old file intact; there is never a half-written `gallery.bin`.
* **Loading** (`Gallery::load`): checks the magic, the version and sanity limits (name/id at most 4096 bytes, vector 1..4096 numbers). A missing file is treated as "first run" (empty gallery).
* **If loading fails** (damaged file, unknown version) the program **never overwrites the file**: it renames it to `gallery.bin.corrupt-<yyyymmdd-hhmmss>`, starts with an empty list and shows a warning (with a beep). If even the renaming fails, registration is disabled for that run so the file stays untouched. See 4.7 for what to do.
* Adding a template with an existing ID updates the name of all that person's rows (rename by re-registering).

### 2.2 Attendance log: `data\attendance.csv`
UTF-8 text with a byte-order mark (so Excel shows any language), CRLF line ends, one header line:

```
Time,ID,Name,Type,Score
2026-11-05 08:02:11,"1001","Alice",IN,0.714
2026-11-05 17:31:40,"1001","Alice",OUT,0.688
```

* `Time` is local time `yyyy-mm-dd hh:mm:ss`. `ID` and `Name` are quoted (a `"` inside is written as `""`). `Type` is `IN` or `OUT`. `Score` is the cosine similarity of the match.
* **Append only.** Each event is appended and flushed (`AttendanceLog::flush`). Old rows are never rewritten by the program.
* **Events are never dropped.** A recognised person is first recorded in memory and put in a queue; only then does the program try to append the row. If the file is locked by another program (Excel), the row stays queued, the screen says "NOT SAVED YET", the program retries every 3 seconds and confirms with "Attendance saved" when it works. If the program is closed while rows are still queued, it writes them to `attendance.csv.unsaved-<time>.csv` next to the log (see 4.7). Rows queued in memory are lost only if the program or the PC crashes (power failure) before the file becomes free.
* **Rule that decides IN/OUT/ignore:** first record of a person for the day = `IN`. Any later sighting at least **30 minutes** after that person's previous record = `OUT` (the last `OUT` of the day is the departure). A sighting less than 30 minutes after the previous record is ignored. The 30 minutes are a constant in `Engine.cpp` (`m_att.mark(..., 30)`).
* At start-up the program reads the file and keeps **only today's rows** in memory (for the table and for the 30-minute rule). Rows of other days are not loaded.

### 2.3 Settings: `settings.ini`
Windows INI file, section `[app]`: `threshold` (integer, 45 = 0.45), `ir` (0/1), `camera` (index). Written whenever the user changes the control.

### 2.4 Who is allowed to change what
| Action | Changes |
|---|---|
| Register (camera / photos / folder) | appends templates to `gallery.bin` (file rewritten atomically) |
| Remove person | deletes all templates of that ID from `gallery.bin`; **attendance rows are not touched** |
| A person is recognised | appends a row to `attendance.csv` (subject to the 30-minute rule) |
| Slider / IR / camera | `settings.ini` |

## 3. Known weaknesses of the current design

These are real limitations of the code as it is. Items 1 and 2 used to lose data; **they are fixed [Implemented]** and covered by an automatic test (`tools\app_test_bugs.cpp`, 14 checks). Items 3 to 8 are still open.

1. **~~A damaged `gallery.bin` was silently overwritten.~~ FIXED.** Before the fix, `Engine::init` ignored a failed load and the next registration saved a new file over the damaged one. Now the damaged file is moved to `gallery.bin.corrupt-<time>` and the screen shows "WARNING: gallery.bin could not be read; kept as ...". The program starts with an empty list, so **people will seem to have disappeared: restore a backup** (section 4.7) instead of registering everybody again. Test: a garbage file survives byte for byte, and a later registration creates a fresh valid `gallery.bin` next to it.
2. **~~A locked CSV dropped events.~~ FIXED.** Before the fix, a row was lost if Excel held `attendance.csv`. Now the event is recorded in memory and queued, the screen says "NOT SAVED YET", the program retries every 3 s, and at exit writes anything left to `attendance.csv.unsaved-<time>.csv`. Test: a row recorded while the file is locked (like Excel: others may read, nobody may write) appears in the file within a few seconds after the lock is released, with BOM and header; and quitting while locked produces the side file. *Remaining limit:* queued rows live only in memory until written, so a crash or power loss while the file is locked loses them. Still close the CSV in Excel when you can.
3. **No checksum.** A bit error inside the vector data is not detected (only the header and sizes are checked).
4. **No history of changes.** There is no log of who registered or removed whom, and when.
5. **Attendance keeps names and IDs forever.** Removing a person deletes the templates only; their history stays in the CSV (see 4.5 for what to do).
6. **One machine only.** Two computers cannot share the data; copying files between them gives two diverging copies.
7. **Not safe against two instances.** Running two copies of the program on the same folder can corrupt the log or overwrite the gallery. Run exactly one.
8. **The unique key is the ID the operator types.** Registering a *different* person under an existing ID silently merges their face into the first person's templates.

## 4. Daily operations

### 4.1 Backup [Recommended procedure]
What to copy: the whole `data\` folder (`gallery.bin`, `attendance.csv`) and `settings.ini`. `models\` can be re-created from the project and does not need a daily backup.

* **Best time:** with the program closed. While it runs, `gallery.bin` is safe to copy (it is replaced atomically, so you get either the old or the new complete file) and `attendance.csv` is append-only (a copy may miss the last row, which is harmless).
* **Schedule:** at least daily for the attendance log; after every registration session for the gallery. Keep 7 daily, 4 weekly and 12 monthly copies.
* **Naming:** `FaceAttendance-backup-yyyymmdd-hhmm\data\...`. Store a copy **on another disk or machine**; a backup on the same disk does not protect against disk failure.
* **Protect backups like the live data** (section 6): they contain the same biometric and personal information.

A minimal PowerShell backup (run with the program closed or open):
```powershell
$src = "C:\FaceAttendance\data"
$dst = "D:\Backups\FaceAttendance\" + (Get-Date -Format "yyyyMMdd-HHmm")
New-Item -ItemType Directory -Force $dst | Out-Null
Copy-Item "$src\*" $dst -Recurse
Copy-Item "C:\FaceAttendance\settings.ini" $dst
```

### 4.2 Restore
1. Close the program.
2. Rename the current `data\` folder to `data.broken-<date>` (do not delete it yet).
3. Copy the chosen backup's files into a new `data\` folder.
4. Start the program, check the people list and today's table, then register or recognise one test person.
5. Keep `data.broken-<date>` until you are sure the restore is complete.

### 4.3 Export and reporting
* **Attendance:** the CSV is the export format. Use "Open attendance CSV (Excel)" or copy the file. It is already UTF-8 with BOM; Excel shows accents and non-Latin names correctly.
* **Monthly report:** filter by `Time` and pair each day's `IN` with the last `OUT` of that day. Do this in Excel or a script on a *copy* of the file.
* **Gallery:** there is no human-readable export. A list of people is visible in the window; the file itself is a private binary format.

### 4.4 Bulk import of people
Use "Import folder": a folder with one sub-folder per person, named `ID_Name` (for example `1001_Alice`), each containing `jpg/jpeg/png/bmp` photos. Good practice: 3-5 photos per person, frontal, good light, no sunglasses; add an IR capture for the night camera. After a bulk import, make a backup.

### 4.5 Deleting data (leavers, requests to erase)
* **Face templates:** select the person in the list and use "Remove selected person". All templates of that ID are removed and the file is rewritten.
* **Attendance history:** the program has no function to delete or anonymise rows. Decide a policy (for example: keep payroll-relevant rows for the legally required period, then delete) and apply it on a **copy of the CSV with the program closed**: remove or replace the ID and name in the affected rows, then replace the file. Make a backup first and keep the header line.
* **Backups:** old backups still contain the person. Your retention schedule (4.1) must be short enough to honour deletion promises, or backups must be purged too.

### 4.7 Recovering from the safety files [Implemented behaviour, manual procedure]
**`gallery.bin.corrupt-<time>` exists** (the screen warned that the gallery could not be read):
1. Close the program. Do **not** register anybody yet.
2. Copy the `.corrupt-...` file somewhere safe (it is the only evidence of what went wrong; do not edit it).
3. Restore the most recent good `gallery.bin` from your backup (4.2) into `data\`.
4. Start the program; the people list must show everyone. Any registrations made after the backup must be repeated.
5. Keep the `.corrupt` file until you know the cause (disk error, interrupted copy, an old program version).

**`attendance.csv.unsaved-<time>.csv` exists** (the program was closed while the CSV was locked):
1. Close Excel and the program.
2. Open the side file and `attendance.csv` in a text editor (or Excel on copies). Append the data rows of the side file (everything except its header line) to the end of `attendance.csv`, keeping the time order.
3. Move the side file into your backup folder; do not leave it next to the log, so it is not merged twice.

If neither file exists but a row seems missing, see 5.2.

### 4.6 Moving the program to another PC
Copy the whole program folder (exe, `models\`, `data\`, `settings.ini`). The camera list is different on the new PC: re-select the camera. Embeddings from the old PC stay valid because they depend only on the model files, **not** on the machine. If you ever change the recognition model, **all old templates become useless** and everyone must be registered again (section 9).

## 5. Data integrity and recovery

### 5.1 What protects the data today
* Atomic replace of `gallery.bin` (no half-written file).
* Magic, version and size checks when loading the gallery; a file that fails them is moved aside, never overwritten.
* Every attendance event is held in memory and queued until it is really written; append + flush per row; retry every 3 s; side file at exit.
* Automatic regression tests for the two cases above (`tools\app_test_bugs.cpp`; build with `tools\build_app_test.bat app_test_bugs`).

### 5.2 Signs of a problem
| Symptom | Likely cause | Action |
|---|---|---|
| Everybody shows "Unknown" after an update | wrong or changed model (`rec.*`), or empty/unreadable `gallery.bin` | check `models\`, check the people list; restore a backup |
| People list empty after start, with a WARNING in the status text | `gallery.bin` was damaged or had a wrong version; it was moved to `gallery.bin.corrupt-<time>` | follow 4.7: restore the backup **before registering anyone** |
| People list empty, no warning | `gallery.bin` was missing (first run, or the file was deleted) | restore the backup (4.2) |
| Status says "NOT SAVED YET" | `attendance.csv` is open in Excel or locked by another program | close it; the program retries by itself and confirms with "Attendance saved" |
| Attendance rows missing | the 30-minute rule ignored the event; or a crash happened while the CSV was locked; or rows are in an `attendance.csv.unsaved-*.csv` side file | check for the side file (4.7); check the rule in 2.2 |
| Garbled names in Excel | file saved again by an editor in another encoding | re-save as "CSV UTF-8" or restore |

### 5.3 Checking the files [Recommended]
A small verification tool should read `gallery.bin` and report: version, number of templates, number of people, vector length, any entry whose length is not 512 or whose norm is not about 1. It should read the CSV and report malformed rows. Run it before every backup and after every restore.

## 6. Privacy and security of biometric data

Face data is among the most sensitive personal data. The rules below are good practice, **not legal advice**: check the law that applies where you operate (for example GDPR in Europe, BIPA in Illinois, PIPA in Korea) and your employment agreements.

1. **Lawful basis and consent.** Tell people what is stored, why, for how long, and get consent or another valid legal basis. Offer an alternative way to check in for people who decline.
2. **Data minimisation.** The program already keeps no photos. Do not keep the original registration photos longer than needed (delete them after registration), and do not store video.
3. **Access control.** Put the program folder on an NTFS location readable only by the operating account and administrators (`icacls`). The `data\` folder and every backup need the same protection.
4. **Encryption at rest.** The files are **not encrypted** by the program. Use BitLocker on the disk (recommended) or EFS on the folder; encrypt backups too. [Recommended future: encrypt `gallery.bin` with Windows DPAPI.]
5. **Do not commit `data\` to version control or e-mail it.** The repository rules in the project exclude `data\` and `settings.ini`.
6. **Retention.** Define how long templates and attendance rows are kept, and delete on schedule (section 4.5). Leavers' templates should be removed promptly.
7. **Logging of administration.** Record who registered and removed people (currently not recorded by the program; keep a manual log or add an audit table, section 8).
8. **Anti-spoofing.** The program has no liveness detection. An IR camera helps against screens and prints, but is not a guarantee; do not use the system alone for security-critical access control.
9. **Model licence.** The bundled InsightFace models are for non-commercial research. Using the system commercially requires a licence or other models, and affects what you may store and sell.

## 7. Capacity and performance

* One template = 512 float32 = **2 KB** plus the id and name. 1,000 people with 5 templates each = about 10 MB. 10,000 people with 5 templates = about 100 MB.
* **Matching** compares the new face with *every* template (brute-force dot products): about `templates x 512` multiply-adds. 10,000 templates is about 5 million operations per face, a few milliseconds on a modern CPU, small compared with the 8 ms the network needs for one embedding. Up to **a few tens of thousands of templates** the brute force approach is fine.
* **Saving** rewrites the whole file on every added template. A 100 MB file written in one step takes about a second; this is acceptable for occasional registration but makes a *large bulk import* slow (each template triggers a full rewrite). For bulk imports of thousands of photos, plan time or change the code to save once at the end.
* **Attendance CSV** grows by about 70 bytes per event; 1,000 people with 2 events per day for a year is about 50 MB. Start-up reads the whole file once (fast for tens of MB). Archive old years (section 8.5) when the file passes a few hundred MB.
* **Memory:** all templates are held in memory (the sizes above).

## 8. When and how to move to a real database [Recommended]

### 8.1 Decide
Stay with files while: one PC, one program instance, under about 20,000 templates, simple CSV reports. Move to a database when **any** of these happens:
* several terminals (doors/PCs) must share the same people and one common attendance log;
* you need queries and reports (late arrivals, monthly totals), an audit trail, or a web/admin interface;
* the CSV lock problem (weakness 2) hits you, or you need transactions so that a registration and its log entry are never half-done;
* the gallery grows beyond roughly 50,000 templates (then also consider an approximate nearest-neighbour index such as FAISS or HNSW instead of brute force).

| Need | Choice |
|---|---|
| One PC, more reliability and reporting | **SQLite** (single file, no server, ACID transactions, easy backup) |
| Several terminals, central data | **PostgreSQL** (or SQL Server in a Windows shop) with a small service in between; terminals send embeddings or check-ins, they do not open the database file over the network |
| Very large galleries (> ~100k templates) | database for people + a vector index (FAISS/HNSW) loaded in memory |

Do **not** share an SQLite file over a network share between machines; it is not safe.

### 8.2 Proposed SQLite schema
```sql
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

CREATE TABLE schema_info   (version INTEGER NOT NULL);              -- 1 row, current schema version

CREATE TABLE person (
    id          TEXT PRIMARY KEY,                -- the operator-chosen ID
    name        TEXT NOT NULL,
    active      INTEGER NOT NULL DEFAULT 1,      -- 0 = left the organisation (templates can be purged)
    created_at  TEXT NOT NULL,                   -- ISO 8601
    updated_at  TEXT NOT NULL
);

CREATE TABLE template (
    seq         INTEGER PRIMARY KEY AUTOINCREMENT,
    person_id   TEXT NOT NULL REFERENCES person(id) ON DELETE CASCADE,
    model_id    TEXT NOT NULL,                   -- e.g. 'w600k_mbf-1': templates of different models never mix
    vec         BLOB NOT NULL,                   -- 512 x float32
    source      TEXT NOT NULL,                   -- 'camera', 'camera-ir', 'photo:<file>'
    created_at  TEXT NOT NULL
);

CREATE TABLE attendance (
    seq         INTEGER PRIMARY KEY AUTOINCREMENT,
    person_id   TEXT NOT NULL,                   -- no foreign key: history survives person deletion
    name_at_time TEXT NOT NULL,                  -- name when the event happened
    ts          TEXT NOT NULL,                   -- ISO 8601 local time with offset
    kind        TEXT NOT NULL CHECK (kind IN ('IN','OUT')),
    score       REAL NOT NULL,
    terminal    TEXT NOT NULL DEFAULT 'main'     -- which PC / door
);
CREATE INDEX idx_att_person_ts ON attendance(person_id, ts);
CREATE INDEX idx_att_ts ON attendance(ts);

CREATE TABLE audit (                              -- who changed what
    seq     INTEGER PRIMARY KEY AUTOINCREMENT,
    ts      TEXT NOT NULL,
    actor   TEXT NOT NULL,                       -- Windows user
    action  TEXT NOT NULL,                       -- 'register','remove','export','settings'
    detail  TEXT
);
```
Reasons: `model_id` makes a model change safe (section 9); attendance has no foreign key and stores the name at the time so that history stays meaningful when a person is removed; `audit` supports the privacy requirement in section 6; WAL mode lets the program read and write safely and survive crashes.

### 8.3 Migration plan (files to SQLite)
1. Make a full backup (section 4.1) and keep it until the migration is confirmed.
2. Write a one-off importer: read `gallery.bin` (format in 2.1) into `person` and `template` (`model_id` = the current model, `source` = 'migrated'); read `attendance.csv` into `attendance` (strip the BOM, parse the quoted fields).
3. Check: number of people and templates equal the old counts; the number of attendance rows equals the CSV rows minus the header; spot-check five people.
4. Switch the program to the new storage layer behind the same interface (`Gallery` / `AttendanceLog` in `Store.h` are the only classes to replace).
5. Keep the old files read-only for one month, then archive them.
6. Update `CODE_WALKTHROUGH.md` (Store section) and this document in the same change, as required by `CLAUDE.md`.

### 8.4 Rules once a database is used
* All changes in a **transaction** (registering a person with five templates is all-or-nothing).
* Back up with the SQLite online-backup API or `VACUUM INTO 'file'` (a plain file copy is only safe when no one is writing).
* Run `PRAGMA integrity_check;` before each backup.
* Never let several machines write to one file; use a server database for that.

### 8.5 Archiving
Once a year (or when the log passes a few hundred MB): copy the old year's attendance rows into `attendance-<year>.csv` (or an archive table), verify the row count, store it with the backups, then delete those rows from the live log.

## 9. Rules for changing the data format

1. **Never edit the on-disk format without raising the version.** `gallery.bin` has a version field for this purpose. A new version needs: a loader for the new format, a loader (or a one-time converter) for every older version, and a test with an old file.
2. **Changing the recognition model invalidates every template.** Embeddings of different models are not comparable. Procedure: keep the old gallery as a backup, ask everyone to re-register (or re-import photos with "Import folder"), and only then switch. Record the model name and file hash with each backup. In the SQLite design the `model_id` column enforces this.
3. **Changing the preprocessing** (contrast stretch, alignment, mean/norm in `models.ini`) also changes embeddings. Treat it like a model change.
4. **Changing the CSV columns** breaks Excel sheets and scripts people already built. Add columns only at the end and update the header; do not reorder.
5. **Document every format change** in `CODE_WALKTHROUGH.md` and here, and keep the test files (`tools\app_test.cpp`) in step.

## 10. Administrator checklists

**Before go-live**
- [ ] Program folder on an encrypted disk (BitLocker) with restricted NTFS permissions
- [ ] Backup job created and a **restore tested once**
- [ ] Consent / notice and retention period defined
- [ ] CSV is not kept open in Excel while the program runs (a locked file no longer loses events, but rows are only in memory until it is free)
- [ ] Exactly one instance of the program runs on the data folder
- [ ] Match threshold tuned on the real cameras (record the value)

**Every day**
- [ ] Program running; status text shows "Models loaded"
- [ ] Backup finished (attendance log)

**After registering people**
- [ ] People list shows the expected names; test recognition of one registered person
- [ ] Backup of `data\gallery.bin`

**Every month**
- [ ] Restore a backup to a test folder and open it
- [ ] Remove templates of people who left; apply the attendance retention rule
- [ ] Check disk space and the size of `attendance.csv`

**When something goes wrong** (people unknown, list empty, rows missing): close the program, copy `data\` aside, read section 5.2, restore the last good backup, and only then continue working.

## 11. Open improvements (suggested order)
1. ~~Fix weakness 1~~ done. ~~Fix weakness 2~~ done (see section 3).
2. Persist queued attendance rows immediately in a small journal file, so a crash while the CSV is locked loses nothing (today queued rows are only in memory).
3. Add the verification tool (5.3) and a backup button or scheduled task.
4. Add a checksum to `gallery.bin` (new format version 2).
5. Move to SQLite (section 8) when the criteria in 8.1 are met.

Any change that implements one of these must update this document, `README.md` and `CODE_WALKTHROUGH.md`.
