# Workflow demonstration and screen-size test

Written for: someone who wants to see that the program works from the first start to the final authentication, and that the window keeps its proportions on different Windows 10 screens.

Everything below was produced by the real program (`bin\Release\FaceAttendance.exe`) with `tools\run_demo.ps1`. **No camera was opened**: the test pictures are sent into the program exactly as camera frames would be (`--no-camera`, `--feed`). You can repeat all of it:

```
powershell -File tools\run_demo.ps1
```
(about 2 minutes; output in `tools\demo_output\`; the pictures shown here are copies in `demo\`).

## What is and is not proven

* **Proven:** the complete flow (start, unknown faces, registration from photos, authentication, attendance record, restart with saved data, night/IR mode) works in the real program, and the window layout is correct and undistorted at 7 screen sizes / display scalings with two camera shapes.
* **Not proven:** recognition accuracy on real cameras and people. There was only one photograph with faces (InsightFace's six-person sample), so **all test pictures are derived from that one photograph**. The "camera frames" are mirrored, re-compressed and noisy copies with another crop and scale, so the match is not a pixel-for-pixel comparison, but it is still the same people in the same lighting. A real accuracy test needs real photos taken with your cameras.
* The real camera, real IR illumination, and the on-screen mouse operation (clicking buttons, file dialogs) were not exercised; the scripted run drives the same program code through command-line options instead. Windows' own display-scaling change between monitors (`WM_DPICHANGED`) was not triggered; scaling was simulated with `--scale`.

## The generated test pictures (`tools\make_test_images.py`)

| File | What it is |
|---|---|
| `register_portrait_A.jpg` (and 5 more in `tools\testdata\workflow\register\`) | ID-style portraits of three of the six people ("Person A/B/C", IDs 1001-1003), two photos each (different scale, small rotation, brightness). Folder names `1001_Person A` etc. are what "Import folder" expects. |
| `frame_day_16x9.png` | a 1280x720 "camera frame": the scene mirrored, JPEG-compressed, with sensor noise. Shows all six people; three are registered, three are strangers. |
| `frame_night_ir.png` | the same at night: grey, very dark (gain 0.32), stronger noise: what an IR camera at night delivers. |
| `tools\testdata\workflow\frame_4x3.png` | a 960x720 frame (a 4:3 camera) used for the aspect-ratio tests. |

## Part B: the workflow (screen 1920x1080, 100 %)

**Step 1. Start.** The program starts, loads the models ("Models loaded (4 threads)"), nothing is registered, the video area is black because no frame has arrived yet.

![start](demo/1_start.png)

**Step 2. Before registration.** The day frame arrives. All six faces are found (red boxes, five landmark dots each) and labelled **Unknown**, because nobody is registered. The people list and the attendance table are empty.

![before registration](demo/2_before_registration.png)

**Step 3. Register from photos, then authenticate.** The folder with the three portrait folders is imported (the same as the "Import folder" button). The list shows `1001 - Person A [2]`, `1002 - Person B [2]`, `1003 - Person C [2]` (two templates each). The program immediately recognises the three registered people: green boxes with name and similarity (**Person B 0.89, Person C 0.93, Person A 0.93**), and writes three attendance rows `IN`. The three strangers stay red **Unknown**. Nothing was clicked by hand; the status line shows the last event.

![registered and authenticated](demo/3_registered_and_authenticated.png)

**Step 4. Restart.** The program is closed and started again with the same data folder. Before any picture arrives, the people list and today's attendance table are already filled from disk (`gallery.bin`, `attendance.csv`): the data persists.

![restart](demo/4_restart_loaded_from_disk.png)

**Step 5. Night / IR.** The IR/night checkbox is on (it forces grayscale), and the dark noisy night frame arrives. The registered people are recognised again (**Person B 0.67, Person C 0.82, Person A 0.81**); the strangers stay Unknown. Scores are lower than by day, as expected, but above the threshold 0.45. No new rows were added: the 30-minute rule (a person already recorded is not recorded again for 30 minutes) suppressed the duplicates, so the table still has exactly three rows.

![night IR](demo/5_night_ir.png)

**Result file** (`demo\attendance_result.csv`):

```
Time,ID,Name,Type,Score
2026-11-05 03:35:06,"1001","Person A",IN,0.927
2026-11-05 03:35:06,"1002","Person B",IN,0.893
2026-11-05 03:35:06,"1003","Person C",IN,0.934
```
`gallery.bin` held 6 templates (12,444 bytes).

## Part A: aspect ratio and layout at different resolutions

Method: for each screen size and Windows display scaling, the program is started with `--screen WxH` (the usable work area of a pretend monitor, i.e. without the task bar) and `--scale N` (the pretend Windows scaling), fed a 16:9 and then a 4:3 camera picture, and then (1) a report of every control's rectangle is written and (2) a screenshot of the window is taken. `tools\check_layout.py` measures the screenshot and checks: all controls are inside the window, no two controls overlap, the video picture has the camera's aspect ratio and fills its area (no black bars, no stretching), the control panel is 400 px x scaling wide, and the window fits the screen.

Result: **14 of 14 runs passed all checks.**

| Screen (work area) | Scaling | Camera | Client area | Video area | Video aspect (camera) | Window |
|---|---|---|---|---|---|---|
| 1366x728 | 100 % | 16:9 | 1348x528 | 945x528 | 1.790 (1.778) | 1366x575 |
| 1600x860 | 125 % | 16:9 | 1582x603 | 1080x603 | 1.791 (1.778) | 1600x650 |
| 1280x680 | 100 % | 16:9 | 1262x480 | 860x480 | 1.792 (1.778) | 1280x527 |
| 1920x1040 | 100 % | 16:9 | 1795x780 | 1393x780 | 1.786 (1.778) | 1813x827 |
| 1920x1040 | 150 % | 16:9 | 1902x725 | 1299x725 | 1.792 (1.778) | 1920x772 |
| 2560x1400 | 150 % | 16:9 | 2542x1085 | 1939x1085 | 1.787 (1.778) | 2560x1132 |
| 3840x2100 | 200 % | 16:9 | 2770x1099 | 1968x1099 | 1.791 (1.778) | 2788x1146 |
| 1366x728 | 100 % | 4:3 | 1219x608 | 817x608 | 1.344 (1.333) | 1237x655 |
| 1600x860 | 125 % | 4:3 | 1479x727 | 977x727 | 1.344 (1.333) | 1497x774 |
| 1280x680 | 100 % | 4:3 | 1161x565 | 759x565 | 1.343 (1.333) | 1179x612 |
| 1920x1040 | 100 % | 4:3 | 1448x780 | 1046x780 | 1.341 (1.333) | 1466x827 |
| 1920x1040 | 150 % | 4:3 | 1797x889 | 1195x889 | 1.344 (1.333) | 1815x936 |
| 2560x1400 | 150 % | 4:3 | 2077x1099 | 1475x1099 | 1.342 (1.333) | 2095x1146 |
| 3840x2100 | 200 % | 4:3 | 2281x1099 | 1479x1099 | 1.346 (1.333) | 2299x1146 |

The measured aspect is within 1 % of the camera's; the small excess is the one or two pixels at the picture's edge. Notes:

* The window height is limited by the screen (about 90 % of the work area) and the width follows from the camera's shape, so every row has the picture's proportions. The window shrinks to fit small screens (the first rows) instead of leaving the screen.
* On the 2560x1400 / 150 % row (16:9) the window is limited by the pretend screen's width (2560), so the height shrinks to keep the shape. On the 3840x2100 / 200 % rows and the 2560x1400 / 150 % row with the 4:3 camera the window stops at 1146 px outer height: this PC's real monitor is smaller than the pretend one and Windows does not allow a window taller than the real screen. The program respects that limit and keeps the proportions instead of letting only one side be clamped.
* The smallest tested work area is 1280x680 at 100 % (or 1600x860 at 125 %, which is the same 1280 design pixels wide). With a 16:9 camera the controls need about 1230 x 500 design pixels; below that the window would be larger than the screen. A 1024x768 screen is therefore not supported.
* A **maximised** window is the one case where the shape cannot be enforced (Windows fills the screen); the picture is then centred with black bars, never stretched.

Selected screenshots (the full set is in `tools\demo_output\`):

The smallest tested size, 1280x680 work area at 100 %: every control still fits (the two lists get smaller):

![1280x720](demo/layout_1280x720_100pct.png)

A 1366x728 laptop work area at 100 %:

![1366x768](demo/layout_1366x768_100pct.png)

1920x1080 at 150 % with a 4:3 camera: fonts, buttons and lines scale, the picture has no bars:

![150 %](demo/layout_1920x1080_150pct_cam4x3.png)

3840x2160 at 200 %:

![200 %](demo/layout_3840x2160_200pct.png)

## How the window keeps its shape (summary)

* **Per-monitor DPI awareness** (`app.manifest`): Windows does not stretch the window; the program draws at the real resolution. All sizes are written for 96 dpi and multiplied by the real scaling (`px`); fonts, line widths and table columns follow.
* **Shape rule:** client width = client height x camera aspect + control panel. `fitWindow` applies it at start and when the camera's shape becomes known; `lockAspect` applies it while the user drags an edge; `WM_SIZE` restores it if the system resizes the window.
* **Fits any screen:** the initial height is at most 90 % of the work area; if the width does not fit, the window is reduced keeping the shape. The panel's two lists share the leftover height so the panel works down to a 450 px client height.
* Line-by-line explanation: `CODE_WALKTHROUGH.md`, sections 1.1a, 1.6, 2.9-2.11 and the `Demo.cpp` / `app.manifest` entries in section 5.
