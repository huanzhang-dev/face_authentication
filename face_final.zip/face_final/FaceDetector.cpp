#include "FaceDetector.h"
#include <algorithm>
#include <cmath>
#include <cstdio>

FaceDetector::FaceDetector() : m_loaded(false) {}

bool FaceDetector::load(const std::string &paramPath, const std::string &binPath,
                        const std::string &inputName, const std::vector<std::string> &outScore,
                        const std::vector<std::string> &outBox,
                        const std::vector<std::string> &outKps, int threads)
{
    if (outScore.size() != 3 || outBox.size() != 3 || outKps.size() != 3) return false;
    for (int i = 0; i < 3; ++i) {                    // order: stride 8, 16, 32
        m_outScore[i] = outScore[i];
        m_outBox[i]   = outBox[i];
        m_outKps[i]   = outKps[i];
    }
    m_net.opt.num_threads = threads;
    m_net.opt.use_vulkan_compute = false;       // CPU only: portable, no driver issues
    m_input = inputName;
    // paths must be in the ANSI code page: ncnn opens them with fopen()
    if (m_net.load_param(paramPath.c_str()) != 0) return false;
    if (m_net.load_model(binPath.c_str()) != 0) return false;
    m_loaded = true;
    return true;
}

static float iouOf(const FaceDet &a, const FaceDet &b)
{
    float ix0 = std::max(a.x0, b.x0), iy0 = std::max(a.y0, b.y0);
    float ix1 = std::min(a.x1, b.x1), iy1 = std::min(a.y1, b.y1);
    float iw = ix1 - ix0, ih = iy1 - iy0;
    if (iw <= 0.f || ih <= 0.f) return 0.f;
    float inter = iw * ih;
    float ua = (a.x1 - a.x0) * (a.y1 - a.y0) + (b.x1 - b.x0) * (b.y1 - b.y0) - inter;
    return inter / ua;
}

// Non-maximum suppression: keep the best box, drop overlapping weaker ones.
static void nms(std::vector<FaceDet> &v, float thr)
{
    std::sort(v.begin(), v.end(),
              [](const FaceDet &a, const FaceDet &b) { return a.score > b.score; });
    std::vector<FaceDet> keep;
    for (size_t i = 0; i < v.size(); ++i) {
        bool ok = true;
        for (size_t k = 0; k < keep.size(); ++k)
            if (iouOf(v[i], keep[k]) > thr) { ok = false; break; }
        if (ok) keep.push_back(v[i]);
    }
    v.swap(keep);
}

// The converted model has its input size baked in (640x640, see README), so every
// image is letterboxed into a fixed S x S square: scaled to fit, padded bottom/right.
std::vector<FaceDet> FaceDetector::detect(const RgbImage &img, int S, float scoreThr) const
{
    std::vector<FaceDet> result;
    if (!m_loaded || img.w <= 0 || img.h <= 0) return result;

    // 1) fit the image into S x S, keeping the aspect ratio
    const float scale = static_cast<float>(S) / std::max(img.w, img.h);
    const int nw = std::max(1, static_cast<int>(img.w * scale + 0.5f));
    const int nh = std::max(1, static_cast<int>(img.h * scale + 0.5f));
    const int tw = S, th = S;                       // network input size
    const float sx = 1.f / scale, sy = 1.f / scale; // network pixel -> image pixel

    // 2) resize (RGB order), normalise (x - 127.5) / 128 as InsightFace SCRFD, then pad
    //    with 0 (= the mean colour after normalisation)
    ncnn::Mat small = ncnn::Mat::from_pixels_resize(img.data.data(), ncnn::Mat::PIXEL_RGB,
                                                    img.w, img.h, nw, nh);
    const float mean[3] = { 127.5f, 127.5f, 127.5f };
    const float norm[3] = { 1.f / 128.f, 1.f / 128.f, 1.f / 128.f };
    small.substract_mean_normalize(mean, norm);
    ncnn::Mat in;
    ncnn::copy_make_border(small, in, 0, S - nh, 0, S - nw, ncnn::BORDER_CONSTANT, 0.f);

    ncnn::Extractor ex = m_net.create_extractor();
    ex.input(m_input.c_str(), in);

    // 3) SCRFD has 3 output groups (strides 8/16/32). Per stride, every grid cell has
    //    2 anchors, giving N = fh*fw*2 rows:  score (N x 1), bbox (N x 4), kps (N x 10).
    //    Anchor centre = (j*stride, i*stride). bbox = distances (left, top, right, bottom)
    //    in units of stride; kps = offsets from the centre in units of stride.
    static const int strides[3] = { 8, 16, 32 };
    std::vector<FaceDet> cand;
    for (int c = 0; c < 3; ++c) {
        const int stride = strides[c];
        ncnn::Mat cls, box, lmk;
        if (ex.extract(m_outScore[c].c_str(), cls) != 0 ||
            ex.extract(m_outBox[c].c_str(),   box) != 0 ||
            ex.extract(m_outKps[c].c_str(),   lmk) != 0)
            continue;
        const int fw = (tw + stride - 1) / stride;          // feature-map width of this stride
        // scores are one flat vector of N values (w*h), boxes N x 4, keypoints N x 10
        const int rows = std::min(cls.w * cls.h, box.h);
        const float *pS = cls, *pB = box, *pK = lmk;

        for (int r = 0; r < rows; ++r) {
            const float s = pS[r];
            if (s < scoreThr) continue;

            const int cell = r / 2;                          // 2 anchors share one cell
            const float cx = static_cast<float>((cell % fw) * stride);
            const float cy = static_cast<float>((cell / fw) * stride);
            const float *b = pB + r * box.w;
            const float *k = pK + r * lmk.w;

            FaceDet f;
            f.score = s;
            f.x0 = (cx - b[0] * stride) * sx;  f.y0 = (cy - b[1] * stride) * sy;
            f.x1 = (cx + b[2] * stride) * sx;  f.y1 = (cy + b[3] * stride) * sy;
            for (int i = 0; i < 5; ++i) {
                f.lx[i] = (cx + k[2 * i]     * stride) * sx;
                f.ly[i] = (cy + k[2 * i + 1] * stride) * sy;
            }
            cand.push_back(f);
        }
    }

    // 4) remove duplicates and clip to the image
    nms(cand, 0.4f);
    for (size_t i = 0; i < cand.size(); ++i) {
        FaceDet &f = cand[i];
        f.x0 = std::max(0.f, f.x0);  f.y0 = std::max(0.f, f.y0);
        f.x1 = std::min(static_cast<float>(img.w - 1), f.x1);
        f.y1 = std::min(static_cast<float>(img.h - 1), f.y1);
        if (f.x1 > f.x0 && f.y1 > f.y0) result.push_back(f);
    }
    return result;
}
