// resource.h - control and dialog ids
#pragma once
#define IDC_STATIC          -1

#define IDD_REGISTER        101
#define IDC_EDIT_ID         1001
#define IDC_EDIT_NAME       1002

#define IDC_CAMERA          2001
#define IDC_IR              2002
#define IDC_THR             2003
#define IDC_THRTXT          2004
#define IDC_BTN_SEL         2005
#define IDC_BTN_PHOTOS      2006
#define IDC_BTN_FOLDER      2007
#define IDC_BTN_REMOVE      2008
#define IDC_PERSONS         2009
#define IDC_TABLE           2010
#define IDC_BTN_CSV         2011
#define IDC_STATUS          2012
#define IDC_LBL_TODAY       2013
#define IDC_LBL_PERSONS     2014
