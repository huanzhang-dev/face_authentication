// Camera.h - camera capture with Windows Media Foundation (works with USB webcams and,
// via the "sensor camera" category, with the IR cameras of Windows-Hello-style devices).
#pragma once
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include "Types.h"

struct CameraInfo
{
    std::wstring name;
    std::wstring link;      // symbolic link, identifies the device
    bool sensor;            // found in the IR / sensor camera category
    CameraInfo() : sensor(false) {}
};

std::vector<CameraInfo> listCameras();

class Camera
{
public:
    Camera();
    ~Camera();

    bool start(const CameraInfo &info, std::string &err);
    void stop();

    // Waits until a frame newer than lastSeq exists (or timeout). Only the NEWEST frame is
    // kept, so a slow consumer automatically skips frames and latency never builds up.
    bool waitFrame(RgbImage &out, unsigned long long &lastSeq, int timeoutMs);

    // Feeds a frame as if the camera had delivered it (used by tests and demos).
    void injectFrame(const RgbImage &img);

private:
    void captureLoop();

    struct Impl;
    Impl *m_impl;
    std::thread m_thread;
    std::atomic<bool> m_running;
    std::mutex m_mutex;
    std::condition_variable m_cv;
    RgbImage m_frame;
    unsigned long long m_seq;
};
