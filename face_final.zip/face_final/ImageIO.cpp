#include "ImageIO.h"
#include <windows.h>
#include <wincodec.h>
#include <wrl/client.h>
#include <algorithm>

using Microsoft::WRL::ComPtr;

// Rotate by the EXIF orientation tag (1 = as is, 3 = 180, 6 = 90 cw, 8 = 90 ccw).
static void applyOrientation(RgbImage &img, int orient)
{
    if (orient != 3 && orient != 6 && orient != 8) return;
    const int w = img.w, h = img.h;
    RgbImage r;
    r.w = (orient == 3) ? w : h;
    r.h = (orient == 3) ? h : w;
    r.data.resize(img.data.size());
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            int dx, dy;
            if (orient == 3)      { dx = w - 1 - x; dy = h - 1 - y; }
            else if (orient == 6) { dx = h - 1 - y; dy = x; }          // 90 clockwise
            else                  { dx = y;         dy = w - 1 - x; }  // 90 counter-clockwise
            const unsigned char *s = &img.data[(static_cast<size_t>(y) * w + x) * 3];
            unsigned char *d = &r.data[(static_cast<size_t>(dy) * r.w + dx) * 3];
            d[0] = s[0]; d[1] = s[1]; d[2] = s[2];
        }
    }
    img.w = r.w; img.h = r.h; img.data.swap(r.data);
}

bool loadImageRgb(const std::wstring &path, RgbImage &out)
{
    ComPtr<IWICImagingFactory> factory;
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, 0, CLSCTX_INPROC_SERVER,
                                IID_PPV_ARGS(&factory))))
        return false;

    ComPtr<IWICBitmapDecoder> dec;
    if (FAILED(factory->CreateDecoderFromFilename(path.c_str(), 0, GENERIC_READ,
                                                  WICDecodeMetadataCacheOnDemand, &dec)))
        return false;
    ComPtr<IWICBitmapFrameDecode> frame;
    if (FAILED(dec->GetFrame(0, &frame))) return false;

    int orient = 1;                                       // EXIF orientation, if any
    ComPtr<IWICMetadataQueryReader> mq;
    if (SUCCEEDED(frame->GetMetadataQueryReader(&mq))) {
        PROPVARIANT pv;
        PropVariantInit(&pv);
        if (SUCCEEDED(mq->GetMetadataByName(L"/app1/ifd/{ushort=274}", &pv)) && pv.vt == VT_UI2)
            orient = pv.uiVal;
        PropVariantClear(&pv);
    }

    ComPtr<IWICFormatConverter> conv;                     // any format -> 24-bit RGB
    if (FAILED(factory->CreateFormatConverter(&conv))) return false;
    if (FAILED(conv->Initialize(frame.Get(), GUID_WICPixelFormat24bppRGB,
                                WICBitmapDitherTypeNone, 0, 0.0, WICBitmapPaletteTypeCustom)))
        return false;

    UINT w = 0, h = 0;
    conv->GetSize(&w, &h);
    if (w == 0 || h == 0) return false;
    out.w = static_cast<int>(w);
    out.h = static_cast<int>(h);
    out.data.resize(static_cast<size_t>(w) * h * 3);
    if (FAILED(conv->CopyPixels(0, w * 3, static_cast<UINT>(out.data.size()), &out.data[0])))
        return false;

    applyOrientation(out, orient);
    return true;
}

void toGray(RgbImage &img)
{
    unsigned char *p = img.data.empty() ? 0 : &img.data[0];
    const size_t n = static_cast<size_t>(img.w) * img.h;
    for (size_t i = 0; i < n; ++i, p += 3) {
        // integer BT.601 luma, weights sum to 256
        unsigned char g = static_cast<unsigned char>((77 * p[0] + 150 * p[1] + 29 * p[2]) >> 8);
        p[0] = p[1] = p[2] = g;
    }
}

void shrinkToWidth(RgbImage &img, int maxW)
{
    if (img.w <= maxW || img.w <= 0) return;
    const float s = static_cast<float>(img.w) / maxW;
    const int nw = maxW, nh = std::max(1, static_cast<int>(img.h / s));
    RgbImage r;
    r.w = nw; r.h = nh;
    r.data.resize(static_cast<size_t>(nw) * nh * 3);
    for (int y = 0; y < nh; ++y) {
        float fy = std::min((y + 0.5f) * s - 0.5f, static_cast<float>(img.h - 1));
        if (fy < 0) fy = 0;
        int y0 = static_cast<int>(fy), y1 = std::min(y0 + 1, img.h - 1);
        float wy = fy - y0;
        for (int x = 0; x < nw; ++x) {
            float fx = std::min((x + 0.5f) * s - 0.5f, static_cast<float>(img.w - 1));
            if (fx < 0) fx = 0;
            int x0 = static_cast<int>(fx), x1 = std::min(x0 + 1, img.w - 1);
            float wx = fx - x0;
            for (int c = 0; c < 3; ++c) {
                float a = img.data[(static_cast<size_t>(y0) * img.w + x0) * 3 + c];
                float b = img.data[(static_cast<size_t>(y0) * img.w + x1) * 3 + c];
                float d = img.data[(static_cast<size_t>(y1) * img.w + x0) * 3 + c];
                float e = img.data[(static_cast<size_t>(y1) * img.w + x1) * 3 + c];
                float v = (a * (1 - wx) + b * wx) * (1 - wy) + (d * (1 - wx) + e * wx) * wy;
                r.data[(static_cast<size_t>(y) * nw + x) * 3 + c] = static_cast<unsigned char>(v + 0.5f);
            }
        }
    }
    img.w = r.w; img.h = r.h; img.data.swap(r.data);
}
