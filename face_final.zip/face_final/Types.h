// Types.h - small data structures shared by every module (plain C++11, no Qt).
#pragma once
#include <string>
#include <vector>

// One detected face, in PIXEL coordinates of the image that was analysed.
struct FaceDet
{
    float x0, y0, x1, y1;   // bounding box (left, top, right, bottom)
    float score;            // detector confidence 0..1
    float lx[5], ly[5];     // 5 landmarks: left eye, right eye, nose, left mouth, right mouth
};

// A tightly packed RGB image (3 bytes per pixel, no row padding).
struct RgbImage
{
    int w, h;
    std::vector<unsigned char> data;
    RgbImage() : w(0), h(0) {}
};

// One enrolled face template (a person may own several). Strings are UTF-8.
struct GalleryEntry
{
    std::string id;             // unique person id, e.g. employee number
    std::string name;           // display name
    std::vector<float> emb;     // L2-normalised embedding
};

// What the window needs to draw one face. Coordinates are NORMALISED (0..1).
struct FaceView
{
    int   trackId;
    float x, y, w, h;           // box
    float lx[5], ly[5];         // landmarks
    std::string label;          // text above the box (UTF-8)
    int   state;                // 0 = unknown, 1 = verifying, 2 = confirmed
    float score;
    FaceView() : trackId(-1), x(0), y(0), w(0), h(0), state(0), score(0.f)
    {
        for (int i = 0; i < 5; ++i) lx[i] = ly[i] = 0.f;
    }
};

typedef std::vector<float>    FloatVec;
typedef std::vector<FaceView> FaceViewList;
