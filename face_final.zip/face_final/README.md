# Face Attendance (plain C++ / Win32 + NCNN + SCRFD + ArcFace)

No Qt. Visual Studio solution `FaceAttendance.sln` (toolset v140 = VS2015), Windows only.

## 1. Status: what was verified

Built here with MSBuild (VS2019, toolset overridden to v142; VS2015 itself is not installed on this machine): **0 errors, 0 warnings**, output `bin\Release\FaceAttendance.exe`.

Tested with a test harness (`tools\app_test.cpp`, built by `tools\build_app_test.bat`) that runs the real Engine, Camera, Store and ImageIO code on a 6-person photo:

| Check | Result |
|---|---|
| Media Foundation camera enumeration | found the laptop camera |
| Photo loading through WIC | OK (1280x886 JPG) |
| Folder import `1001_Alice` | registered, shows in the person list |
| Same photo fed as camera frames | 6 faces tracked, Alice confirmed (score 1.00), the 5 others stay "Unknown" |
| Attendance | one `IN` row written to the CSV, repeated sightings ignored |
| Remove person | OK |
| Speed (this PC, 4 threads) | about 15 ms detection, 8 ms per face embedding, 45 ms for a whole 6-face frame |

Data-loss regression tests (`tools\app_test_bugs.cpp`, 14 checks, all pass): a damaged `gallery.bin` is moved aside and never overwritten; attendance rows survive a locked `attendance.csv` (queued, retried every 3 s, written to a side file at exit).

**Not verified:** (a) live camera capture and the GUI itself were not started (that would switch on the webcam), so the window layout, painting, dialogs and a real camera stream have never been seen; (b) IR cameras: the code lists the "sensor camera" category, but there was no IR camera to try; (c) accuracy on your own cameras and people: the threshold 0.45 is a starting value; (d) the VS2015 toolset itself.

## 2. Requirement map

| # | Requirement | Where |
|---|---|---|
| 1 | IR camera, works at night | `Camera.cpp` lists normal and IR/sensor cameras; "IR / night mode" forces grayscale (`ImageIO.cpp`); contrast stretch of the aligned face (`FaceRecognizer.cpp`) |
| 2 | Many faces at once | detector returns all faces, one tracker entry per face (`Engine.cpp`) |
| 3 | Register from photos or from the camera | "Register from photos", "Import folder", "Register selected face" |
| 4 | Real time | camera thread, engine thread, newest-frame-only hand-over, tracking, per-frame recognition budget |
| 5 | VS2015 | `.sln` / `.vcxproj`, C++11 only (toolset v140) |
| 6 | NCNN | `FaceDetector` (SCRFD) and `FaceRecognizer` (ArcFace) |
| 7 | Simple | about 1500 lines, no framework, no database, plain files |
| 8 | Extra strategies | section 6 |
| 9 | Line-by-line explanation | section 7 and the comments in the code |

## 3. Models (the "most recent" stack)

* Detector: **SCRFD-500M** with 5 landmarks (InsightFace `det_500m`). Recognizer: **ArcFace MobileFaceNet** `w600k_mbf`, 112x112, 512-d. Both from the InsightFace `buffalo_sc` pack, **non-commercial research licence**, check before shipping.
* I found no definitive 2026 ranking of face models, so "most recent" means the current standard open-source InsightFace stack. For higher accuracy use `det_10g` + `w600k_r50` from `buffalo_l` (about 5x slower): convert them the same way and update `models.ini`.
* Already converted to ncnn in `models\` with `pnnx` at fixed shapes `[1,3,640,640]` and `[1,3,112,112]`. **The detector input size is baked in (640x640)**: every frame is letterboxed into it. Blob names are in `models\models.ini` (detector input `in0`, outputs `out0-2` scores, `out3-5` boxes, `out6-8` landmarks for strides 8/16/32; recognizer `in0` -> `out0`). If you re-convert, check the names in the `.param` files and re-run `tools\check_models.py` (Python reference test, needs `tools\venv`).

## 4. Build and run

1. Open `FaceAttendance.sln` in Visual Studio 2015, choose **Release | x64** (or Debug | x64), Build. The bundled ncnn is a Release /MD library, so the Debug configuration is set up to match it (`/MD`, `_ITERATOR_DEBUG_LEVEL=0`): you get debug symbols and breakpoints, but not the extra runtime checks of a normal debug build, and the neural networks run slowly without optimisation (use Release to judge speed). If you later switch to a debug build of ncnn, restore `/MDd` in the Debug settings.
2. ncnn: the official prebuilt **VS2015 x64** package is already in `third_party\ncnn\x64` (static, includes the Vulkan libs, which are linked but not used: ncnn runs on the CPU). To use another copy set the environment variable `NCNN_ROOT` or edit `FaceAttendance.props`.
3. Output: `bin\Release\FaceAttendance.exe`. The post-build step copies `models\` next to it. At run time it creates `data\gallery.bin` (face templates), `data\attendance.csv` (opens in Excel) and `settings.ini`.
4. Newer Visual Studio: change *Platform Toolset* (v141/v142/v143) and, if asked, the Windows SDK version. From the command line: `MSBuild FaceAttendance.sln /p:Configuration=Release /p:Platform=x64 /p:PlatformToolset=v142 /p:WindowsTargetPlatformVersion=10.0.19041.0`.
5. IR enumeration needs the Windows 10 SDK headers (the code checks `NTDDI_WIN10_TH2`); with only the 8.1 SDK the program still works but lists normal cameras only. In the project properties set *Windows SDK Version* to an installed 10.0.x.
6. No installation needed: the program only uses Windows components (Media Foundation, WIC, GDI), ncnn is linked statically, and the C++ runtime is the VS2015 one (install the VC++ 2015 redistributable on other PCs).

### Window size, screen resolution and display scaling
* The program is **per-monitor DPI aware** (`app.manifest`): on 125 %, 150 %, 200 % screens Windows does not stretch it into a blurry bitmap; fonts, buttons, lines and columns scale.
* The window keeps the **camera's aspect ratio**: client width = client height x camera aspect + control panel. The picture is never stretched and there are no black bars (maximised window excepted). The shape is enforced at start, while you drag an edge, and when the camera reports its own shape (4:3, 16:9, ...).
* The first window is at most 90 % of the monitor's usable area, so it fits laptop screens such as 1366x768. Smallest supported size: about 1230 x 500 design pixels (1280x720 screens at 100 % work; 1024x768 does not).
* Tested at 7 sizes/scalings with two camera shapes: see `WORKFLOW_DEMO.md`. Not tested: dragging the window between two real monitors with different scaling.

### Command-line options for scripted runs (optional, no effect on a normal start)
`--no-camera`, `--data <folder>`, `--ir <0|1>`, `--scale <percent>`, `--screen <W>x<H>`, `--import <folder>@<ms>`, `--feed <image>@<ms>`, `--shot <png>@<ms>`, `--report <txt>@<ms>`, `--quit@<ms>` (see `Demo.h`). Example: `FaceAttendance.exe --no-camera --data C:\demo --feed frame.png@500 --shot out.png@3000 --quit@3500`.

### IR notes
* A camera appears twice in the list if it exists in both categories; entries ending in `[IR]` come from the Windows sensor-camera category used by Windows-Hello-style IR cameras. If your IR camera is not listed, it is not exposed through Media Foundation; its SDK can feed frames with `Camera::injectFrame(RgbImage)` (the same hook the test uses), nothing else changes.
* With an 850 nm illuminator at night the picture is IR only. **Register people with the same IR camera** (button "Register selected face") for best accuracy; photos from a phone differ in appearance. You can register one ID several times (day photo and IR capture): all templates are kept.
* The camera format is chosen near 640x480 and converted to RGB by Media Foundation; if that fails, YUY2, NV12, L8 and L16 are converted by the program itself.

## 5. Tuning
* **Match threshold** slider (default 0.45 cosine): raise it if strangers are accepted, lower it if known people are missed. Tune it on your own cameras.
* `models.ini`: `threads`, detector `score` (0.5), recognizer `mean`/`norm` (must match the model), `contrast_stretch`.
* In `Engine.cpp`: quality gate (eyes at least 24 px apart), margin 0.04, votes 2, re-verify every 45 frames, attendance gap 30 minutes.

## 6. Design decisions
1. **Two threads + newest frame only:** the camera thread keeps only the latest frame; the engine takes it when idle, so latency never builds up and the window never blocks.
2. **Tracking:** IoU tracker gives each face an ID; recognition is repeated for unknown faces (every 2nd frame) and re-verified for known faces (every 45 frames).
3. **Recognition budget:** at most 3 embeddings per frame, so a crowd cannot stall the pipeline.
4. **Quality gate:** eyes at least 24 px apart and nose between the eyes.
5. **Voting:** confirmed only after 2 consecutive agreeing frames.
6. **Margin test:** the best match must beat the best other person by 0.04.
7. **Alignment:** 5-point similarity transform to the ArcFace template.
8. **Contrast stretch** (1%..99% luminance) on the aligned face for dim IR frames.
9. **Registration averages 5 frames** from the camera; all templates of a person are kept.
10. **Attendance rule:** first sighting of the day = IN; later sightings at least 30 min after the last record = OUT (the last OUT is the departure); others ignored.
11. **Plain files, no database:** `gallery.bin` is written to a temp file and renamed (no half-written file on a crash); the CSV has a UTF-8 BOM so Excel shows any language; text is UTF-8 inside, UTF-16 at the Windows API boundary.
12. **Phone photos:** the EXIF rotation is applied when loading.
13. **Not included:** liveness (anti-spoofing). An IR camera already rejects most screens and prints; add a dedicated anti-spoof model for a security-critical use.

## 7. Step-by-step flow (follow it with the source open)

**Start-up**
1. `main.cpp wWinMain`: `OleInitialize` (COM for the folder dialog), common controls, create fonts, `listCameras()` (Media Foundation: normal + IR cameras), register the window class, `CreateWindowExW`.
2. `WM_CREATE` -> `createControls`: creates the combo box, checkbox, slider, buttons, list box, list view and status text, fills the camera list, restores `settings.ini` (threshold, IR, camera).
3. Back in `wWinMain`: create `Engine`, set threshold/IR, `engine->start(data, models)` (spawns the engine thread), `layoutControls`, `ShowWindow`, `startCamera` (spawns the capture thread), then the message loop.
4. Engine thread `Engine::run` -> `init()`: creates `data\`, loads `gallery.bin` and `attendance.csv` (today's rows), reads `models.ini`, loads the detector and the recognizer (`load_param` + `load_model`), posts "Models loaded".

**Every frame**
5. `Camera::start` (UI thread): `MFCreateDeviceSource` -> source reader with video processing, pick the mode nearest 640x480, ask for RGB32. `captureLoop` (own thread): `ReadSample` -> contiguous buffer -> `convertFrame` to packed RGB (stride sign = bottom-up flip) -> store as the newest frame, notify.
6. `Engine::run` loop: runs queued commands, then `Camera::waitFrame` (copy of the newest frame), then `processFrame`:
   1. IR mode: `toGray`; frames wider than 960 px are shrunk (`shrinkToWidth`);
   2. `FaceDetector::detect`: letterbox into 640x640, normalise `(x-127.5)/128`, run SCRFD, decode 3 strides x 2 anchors (box = distances to the cell centre times stride; landmarks = offsets times stride), threshold, NMS 0.4, clip;
   3. tracking: IoU pairs (> 0.25), greedy best-first, smooth the box, count misses, drop tracks missed more than 8 frames, new tracks for new faces;
   4. for tracks that need it and pass `goodQuality`: `FaceRecognizer::extract`: closed-form similarity transform from the 5 landmarks to the template, bilinear warp to 112x112, contrast stretch, normalise, ArcFace, L2-normalise;
   5. `match`: dot product with all stored templates (= cosine), best entry, best other person, accept if score >= threshold and margin >= 0.04;
   6. voting: same person twice in a row confirms; `AttendanceLog::mark` returns IN / OUT / "" (duplicate) and appends a CSV row; beep + status message;
   7. build the `FaceView` list (normalised coordinates, label, colour state), swap frame and faces into `SharedState`, `PostMessage(WM_APP_FRAME)`.
7. `wndProc WM_APP_FRAME` -> `takeFrame`: copy under the mutex, convert to padded BGR, update the FPS text, invalidate the video area. `WM_PAINT` -> `paintVideo`: off-screen DC, `StretchDIBits` of the frame, then `drawFaces` (box, 5 landmarks, label); one `BitBlt` to the window (no flicker).
8. `WM_APP_STATE` -> `takeState`: refreshes the status text, today's list view (newest first) and the people list.

**Registration**
* Camera: click a face (`WM_LBUTTONDOWN` selects the track under the cursor), press the button, enter ID and name (`regProc` dialog from `FaceAttendance.rc`), `Engine::requestEnroll` flags the track; the next 5 usable frames each give an embedding; their normalised mean is stored (`addTemplate` -> `Gallery::add` + `save`).
* Photos / folder: `Engine::doEnrollFiles` (engine thread): `loadImageRgb` (WIC, EXIF rotation), `embedBest` (largest face), `addTemplate`. A folder import expects sub-folders named `ID_Name`, for example `1001_Alice`.
* Remove: select a person in the list, "Remove selected person".

**Shutdown:** the loop ends on `WM_DESTROY`; `engine->stop()` joins the engine thread, `camera.stop()` joins the capture thread and shuts the device source down.

## 8. Files
**`WORKFLOW_DEMO.md`** shows the whole workflow (start, unknown faces, register from photos, authenticate, attendance, restart, night/IR) and the window-proportion tests at 7 screen sizes and scalings, with screenshots; repeat it with `powershell -File tools\run_demo.ps1` (no camera is opened). `tools\make_test_images.py` generates the test pictures, `tools\check_layout.py` measures the layout.

**`DATABASE_MANAGEMENT.md`** describes the data files, backup/restore, privacy rules, known weaknesses of the file storage and the plan for moving to SQLite.

**`CODE_WALKTHROUGH.md`** explains every statement in execution order; `CLAUDE.md` makes keeping it current a rule, and `tools\check_docs.ps1` reports which files changed after the text was written (`-Update` records the fingerprints after the text was fixed).


`main.cpp` window | `Engine.*` pipeline and decisions | `Camera.*` Media Foundation capture | `FaceDetector.*`, `FaceRecognizer.*` ncnn models | `Store.*` gallery file + attendance CSV | `ImageIO.*` WIC photo loading, helpers | `Util.h` UTF-8/UTF-16 | `Types.h` | `resource.h`, `FaceAttendance.rc` dialog | `models\` | `third_party\ncnn` | `tools\` (model conversion workspace, `check_models.py`, `app_test.cpp`; `tools\venv` is a Python environment for the conversion, safe to delete).
