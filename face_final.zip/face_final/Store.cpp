#include "Store.h"
#include <windows.h>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <set>

// ------------------------------------------------------------------ Gallery
// File layout: "FGAL" | u32 version(1) | u32 count | per entry:
//              u32 idLen, id bytes, u32 nameLen, name bytes, u32 dim, dim floats

static void putU32(std::ostream &o, unsigned v) { o.write(reinterpret_cast<const char *>(&v), 4); }
static bool getU32(std::istream &i, unsigned &v) { return !!i.read(reinterpret_cast<char *>(&v), 4); }

bool Gallery::load(const std::wstring &path)
{
    m_path = path;
    m_e.clear();
    std::ifstream f(path.c_str(), std::ios::binary);
    if (!f) return true;                                  // first run
    char magic[4];
    unsigned ver = 0, count = 0;
    if (!f.read(magic, 4) || std::string(magic, 4) != "FGAL") return false;
    if (!getU32(f, ver) || ver != 1 || !getU32(f, count)) return false;
    for (unsigned n = 0; n < count; ++n) {
        GalleryEntry e;
        unsigned len = 0, dim = 0;
        if (!getU32(f, len) || len > 4096) return false;
        e.id.resize(len);
        if (len && !f.read(&e.id[0], len)) return false;
        if (!getU32(f, len) || len > 4096) return false;
        e.name.resize(len);
        if (len && !f.read(&e.name[0], len)) return false;
        if (!getU32(f, dim) || dim == 0 || dim > 4096) return false;
        e.emb.resize(dim);
        if (!f.read(reinterpret_cast<char *>(&e.emb[0]), dim * sizeof(float))) return false;
        m_e.push_back(e);
    }
    return true;
}

bool Gallery::save() const
{
    const std::wstring tmp = m_path + L".tmp";            // write aside, then replace: no half-written file
    {
        std::ofstream f(tmp.c_str(), std::ios::binary | std::ios::trunc);
        if (!f) return false;
        f.write("FGAL", 4);
        putU32(f, 1);
        putU32(f, static_cast<unsigned>(m_e.size()));
        for (size_t i = 0; i < m_e.size(); ++i) {
            putU32(f, static_cast<unsigned>(m_e[i].id.size()));
            f.write(m_e[i].id.data(), m_e[i].id.size());
            putU32(f, static_cast<unsigned>(m_e[i].name.size()));
            f.write(m_e[i].name.data(), m_e[i].name.size());
            putU32(f, static_cast<unsigned>(m_e[i].emb.size()));
            f.write(reinterpret_cast<const char *>(&m_e[i].emb[0]), m_e[i].emb.size() * sizeof(float));
        }
        if (!f) return false;
    }
    return MoveFileExW(tmp.c_str(), m_path.c_str(), MOVEFILE_REPLACE_EXISTING) != 0;
}

void Gallery::add(const std::string &id, const std::string &name, const FloatVec &emb)
{
    for (size_t i = 0; i < m_e.size(); ++i)               // same id: keep the newest name everywhere
        if (m_e[i].id == id) m_e[i].name = name;
    GalleryEntry e;
    e.id = id; e.name = name; e.emb = emb;
    m_e.push_back(e);
}

bool Gallery::remove(const std::string &id)
{
    bool any = false;
    for (size_t i = m_e.size(); i-- > 0;)
        if (m_e[i].id == id) { m_e.erase(m_e.begin() + i); any = true; }
    return any;
}

void Gallery::labels(std::vector<std::string> &ids, std::vector<std::string> &texts) const
{
    ids.clear(); texts.clear();
    std::set<std::string> seen;
    for (size_t i = 0; i < m_e.size(); ++i) {
        if (!seen.insert(m_e[i].id).second) continue;
        int n = 0;
        for (size_t k = 0; k < m_e.size(); ++k) if (m_e[k].id == m_e[i].id) ++n;
        char cnt[32];
        std::sprintf(cnt, "  [%d]", n);
        ids.push_back(m_e[i].id);
        texts.push_back(m_e[i].id + " - " + m_e[i].name + cnt);
    }
}

// ------------------------------------------------------------------ Attendance
static std::string nowText(time_t t)
{
    char b[32];
    struct tm tmv;
    localtime_s(&tmv, &t);
    strftime(b, sizeof(b), "%Y-%m-%d %H:%M:%S", &tmv);
    return b;
}

// Splits one CSV line; understands "quoted, fields" with "" as an escaped quote.
static std::vector<std::string> splitCsv(const std::string &line)
{
    std::vector<std::string> out;
    std::string cur;
    bool q = false;
    for (size_t i = 0; i < line.size(); ++i) {
        char c = line[i];
        if (q) {
            if (c == '"') { if (i + 1 < line.size() && line[i + 1] == '"') { cur += '"'; ++i; } else q = false; }
            else cur += c;
        } else if (c == '"') q = true;
        else if (c == ',') { out.push_back(cur); cur.clear(); }
        else if (c != '\r') cur += c;
    }
    out.push_back(cur);
    return out;
}

static std::string csvQuote(const std::string &s)
{
    std::string r = "\"";
    for (size_t i = 0; i < s.size(); ++i) { if (s[i] == '"') r += '"'; r += s[i]; }
    return r + "\"";
}

static time_t parseTime(const std::string &s)
{
    struct tm t = {};
    if (std::sscanf(s.c_str(), "%d-%d-%d %d:%d:%d", &t.tm_year, &t.tm_mon, &t.tm_mday,
                    &t.tm_hour, &t.tm_min, &t.tm_sec) != 6) return 0;
    t.tm_year -= 1900; t.tm_mon -= 1; t.tm_isdst = -1;
    return mktime(&t);
}

void AttendanceLog::rollDay()
{
    const std::string day = nowText(time(0)).substr(0, 10);
    if (day != m_day) { m_day = day; m_today.clear(); m_last.clear(); }
}

bool AttendanceLog::open(const std::wstring &path)
{
    m_path = path;
    m_day = nowText(time(0)).substr(0, 10);
    m_today.clear(); m_last.clear();
    std::ifstream f(path.c_str(), std::ios::binary);
    if (!f) return true;
    std::string line;
    while (std::getline(f, line)) {
        std::vector<std::string> c = splitCsv(line);
        if (c.size() < 5 || c[0].compare(0, 10, m_day) != 0) continue;   // header or other days
        AttRow r;
        r.time = c[0]; r.id = c[1]; r.name = c[2]; r.kind = c[3]; r.score = static_cast<float>(atof(c[4].c_str()));
        m_today.push_back(r);
        m_last[r.id] = parseTime(r.time);
    }
    return true;
}

std::string AttendanceLog::mark(const std::string &id, const std::string &name, float score, int gapMinutes)
{
    rollDay();
    const time_t now = time(0);
    std::string kind = "IN";                              // first sighting of the day
    std::map<std::string, time_t>::const_iterator it = m_last.find(id);
    if (it != m_last.end()) {
        if (difftime(now, it->second) < gapMinutes * 60.0) return std::string();   // duplicate
        kind = "OUT";                                     // later sighting: the last OUT = departure
    }

    AttRow r;
    r.time = nowText(now); r.id = id; r.name = name; r.kind = kind; r.score = score;

    // The event is recorded in memory FIRST, so it can never be lost. Writing to the file is
    // a separate step: if the CSV is locked (Excel), the row stays queued and is retried.
    m_today.push_back(r);
    m_last[id] = now;
    m_pending.push_back(r);
    flush();
    return kind;
}

static const char kBom[] = "\xEF\xBB\xBF";                       // UTF-8 BOM so Excel shows any language
static const char kHeader[] = "Time,ID,Name,Type,Score\r\n";

static void writeRow(std::ostream &o, const AttRow &r)
{
    char sc[32];
    std::sprintf(sc, "%.3f", r.score);
    o << r.time << ',' << csvQuote(r.id) << ',' << csvQuote(r.name) << ',' << r.kind << ',' << sc << "\r\n";
}

bool AttendanceLog::flush()
{
    if (m_pending.empty()) return true;
    bool fresh = false;                                   // new or empty file: write BOM + header first
    {
        std::ifstream t(m_path.c_str(), std::ios::binary);
        fresh = !t || t.peek() == std::ifstream::traits_type::eof();
    }
    std::ofstream o(m_path.c_str(), std::ios::binary | std::ios::app);
    if (!o) return false;                                 // locked by another program: keep the rows queued
    if (fresh) o << kBom << kHeader;
    size_t written = 0;
    for (; written < m_pending.size(); ++written) {
        writeRow(o, m_pending[written]);
        o.flush();
        if (!o) break;
    }
    m_pending.erase(m_pending.begin(), m_pending.begin() + written);   // drop only what really got written
    return m_pending.empty();
}

bool AttendanceLog::spill()
{
    if (m_pending.empty()) return true;
    const std::wstring side = m_path + L".unsaved-" + std::to_wstring(static_cast<long long>(time(0))) + L".csv";
    std::ofstream o(side.c_str(), std::ios::binary | std::ios::trunc);
    if (!o) return false;
    o << kBom << kHeader;
    for (size_t i = 0; i < m_pending.size(); ++i) writeRow(o, m_pending[i]);
    o.flush();
    if (!o) return false;
    m_pending.clear();
    return true;
}
