// FaceDetector.h - SCRFD (InsightFace) face + 5-landmark detector on NCNN.
#pragma once
#include <net.h>        // ncnn
#include <string>
#include <vector>
#include "Types.h"

class FaceDetector
{
public:
    FaceDetector();

    // inputName: input blob of the .param. outScore/outBox/outKps: three output blob
    // names each, in the order of strides 8, 16, 32 (see models/models.ini and README).
    bool load(const std::string &paramPath, const std::string &binPath,
              const std::string &inputName, const std::vector<std::string> &outScore,
              const std::vector<std::string> &outBox, const std::vector<std::string> &outKps,
              int threads);

    // Detects faces. S = the (fixed) square network input size, 640 for the bundled
    // model; frames are letterboxed into it. Coordinates are in the pixels of img.
    std::vector<FaceDet> detect(const RgbImage &img, int S, float scoreThr) const;

private:
    ncnn::Net   m_net;
    std::string m_input;
    std::string m_outScore[3], m_outBox[3], m_outKps[3];
    bool        m_loaded;
};
