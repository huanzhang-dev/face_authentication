// main.cpp - the Win32 window: video view with overlays, buttons, attendance table.
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <shellapi.h>
#include <shlobj.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include "Camera.h"
#include "Demo.h"
#include "Engine.h"
#include "Util.h"
#include "resource.h"

#pragma comment(linker, "\"/manifestdependency:type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

// All sizes below are written for 96 dpi (Windows scaling 100 %) and multiplied by the real scaling.
static const int PANEL_W = 400;                         // right-hand control panel
static const int MIN_CLIENT_H = 450;                    // smallest client height in which every control fits
static const double DEFAULT_ASPECT = 4.0 / 3.0;         // shape of the video area until the camera reports its own
static const wchar_t *kClass = L"FaceAttendanceWnd";
static int g_scalePct = 0;                              // test override of the display scaling (0 = Windows' value)
static RECT g_screen = { 0, 0, 0, 0 };                  // test override of the monitor work area (empty = real one)

struct App
{
    HWND hwnd;
    HFONT font, fontBold;
    Camera camera;
    SharedState shared;
    Engine *engine;
    std::vector<CameraInfo> cams;
    std::wstring settingsFile;

    // what is currently on screen (copied from SharedState on every frame)
    RgbImage image;
    std::vector<unsigned char> bgr;                     // padded BGR rows for GDI
    FaceViewList faces;
    int selected;
    int frames;
    ULONGLONG fpsStart;
    double fps, ms;
    std::string message;
    double aspect;                                      // width / height of the video area (the camera's shape)
    bool adjusting;                                     // true while we resize the window ourselves

    App() : hwnd(0), font(0), fontBold(0), engine(0), selected(-1), frames(0), fpsStart(0), fps(0), ms(0),
            aspect(DEFAULT_ASPECT), adjusting(false) {}
};

// ------------------------------------------------------------------ small helpers
static void setText(HWND h, const std::string &utf8) { SetWindowTextW(h, toWide(utf8).c_str()); }

// ------------------------------------------------------------------ display scaling (DPI)
typedef UINT (WINAPI *GetDpiForWindowFn)(HWND);

static int dpiOf(HWND hwnd)
{
    if (g_scalePct > 0) return MulDiv(96, g_scalePct, 100);                 // test override
    static GetDpiForWindowFn fn = reinterpret_cast<GetDpiForWindowFn>(      // Windows 10 1607+, looked up at run time
        GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetDpiForWindow"));
    if (fn && hwnd) { const UINT d = fn(hwnd); if (d) return static_cast<int>(d); }
    HDC dc = GetDC(0);                                                      // older Windows: system-wide value
    const int d = GetDeviceCaps(dc, LOGPIXELSX);
    ReleaseDC(0, dc);
    return d > 0 ? d : 96;
}

static int px(HWND hwnd, int at96) { return MulDiv(at96, dpiOf(hwnd), 96); }

// Usable area of the monitor the window is on (without the task bar).
static RECT workArea(HWND hwnd)
{
    if (g_screen.right > g_screen.left) return g_screen;
    MONITORINFO mi = { sizeof(mi) };
    GetMonitorInfoW(MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST), &mi);
    return mi.rcWork;
}

// The window is kept in the shape  clientWidth = clientHeight * aspect + panel,  so the video area
// always has exactly the camera's aspect ratio (no black bars) at every size and scaling.
static int panelWidth(HWND hwnd) { return px(hwnd, PANEL_W) + px(hwnd, 8); }

static void layoutRects(HWND hwnd, RECT &video)
{
    RECT rc;
    GetClientRect(hwnd, &rc);
    video.left = 0; video.top = 0;
    video.right = std::max<LONG>(rc.right - panelWidth(hwnd), 100);
    video.bottom = rc.bottom;
}

static void frameSize(HWND hwnd, int &ncW, int &ncH)    // title bar and borders: window size minus client size
{
    RECT w, c;
    GetWindowRect(hwnd, &w);
    GetClientRect(hwnd, &c);
    ncW = (w.right - w.left) - c.right;
    ncH = (w.bottom - w.top) - c.bottom;
}

// Resize the window so that its client height is wantH and the video area has the right shape;
// shrink (keeping the shape) if it does not fit on the screen, and pull it inside the work area.
static void fitWindow(App *a, int wantH)
{
    HWND h = a->hwnd;
    const RECT work = workArea(h);
    int ncW, ncH;
    frameSize(h, ncW, ncH);
    const int panel = panelWidth(h);
    int ch = std::max(wantH, px(h, MIN_CLIENT_H));
    int cw = static_cast<int>(ch * a->aspect + 0.5) + panel;
    // never more than the work area, nor more than Windows lets a window grow (else the system would
    // clamp one side only and the shape would be lost)
    const int maxW = std::min<int>(work.right - work.left, GetSystemMetrics(SM_CXMAXTRACK));
    const int maxH = std::min<int>(work.bottom - work.top, GetSystemMetrics(SM_CYMAXTRACK));
    if (cw + ncW > maxW) { cw = maxW - ncW; ch = static_cast<int>((cw - panel) / a->aspect); }
    if (ch + ncH > maxH) { ch = maxH - ncH; cw = static_cast<int>(ch * a->aspect + 0.5) + panel; }
    RECT wr;
    GetWindowRect(h, &wr);
    int x = std::min<int>(wr.left, work.right - (cw + ncW));
    int y = std::min<int>(wr.top, work.bottom - (ch + ncH));
    x = std::max<int>(x, work.left);
    y = std::max<int>(y, work.top);
    a->adjusting = true;
    SetWindowPos(h, 0, x, y, cw + ncW, ch + ncH, SWP_NOZORDER | SWP_NOACTIVATE);
    a->adjusting = false;
}

// While the user drags an edge or corner: correct the proposed rectangle to keep the shape.
static void lockAspect(App *a, WPARAM edge, RECT *r)
{
    HWND h = a->hwnd;
    int ncW, ncH;
    frameSize(h, ncW, ncH);
    const int panel = panelWidth(h);
    int cw = (r->right - r->left) - ncW, ch = (r->bottom - r->top) - ncH;
    if (edge == WMSZ_LEFT || edge == WMSZ_RIGHT) ch = static_cast<int>((cw - panel) / a->aspect + 0.5);   // width leads
    else cw = static_cast<int>(ch * a->aspect + 0.5) + panel;                                          // height leads
    if (ch < px(h, MIN_CLIENT_H)) { ch = px(h, MIN_CLIENT_H); cw = static_cast<int>(ch * a->aspect + 0.5) + panel; }
    const int nw = cw + ncW, nh = ch + ncH;
    if (edge == WMSZ_LEFT || edge == WMSZ_TOPLEFT || edge == WMSZ_BOTTOMLEFT) r->left = r->right - nw; else r->right = r->left + nw;
    if (edge == WMSZ_TOP || edge == WMSZ_TOPLEFT || edge == WMSZ_TOPRIGHT) r->top = r->bottom - nh; else r->bottom = r->top + nh;
}

// Fonts follow the display scaling. Create new ones, give them to every control, then free the old ones.
static BOOL CALLBACK setFontProc(HWND h, LPARAM f) { SendMessageW(h, WM_SETFONT, f, TRUE); return TRUE; }

static void applyFonts(App *a)
{
    LOGFONTW lf = {};
    lf.lfHeight = -MulDiv(9, dpiOf(a->hwnd), 72);        // 9 pt
    lf.lfQuality = CLEARTYPE_QUALITY;
    lstrcpyW(lf.lfFaceName, L"Segoe UI");
    lf.lfWeight = FW_NORMAL;
    HFONT n = CreateFontIndirectW(&lf);
    lf.lfWeight = FW_BOLD;
    HFONT b = CreateFontIndirectW(&lf);
    EnumChildWindows(a->hwnd, setFontProc, reinterpret_cast<LPARAM>(n));
    if (a->font) DeleteObject(a->font);
    if (a->fontBold) DeleteObject(a->fontBold);
    a->font = n;
    a->fontBold = b;
}

// Where the picture is drawn inside the video area (keeps the aspect ratio).
static RECT imageRect(const App *a, const RECT &video)
{
    RECT r = video;
    if (a->image.w <= 0) return r;
    const double vw = static_cast<double>(video.right) - video.left;
    const double vh = static_cast<double>(video.bottom) - video.top;
    const double s = std::min(vw / a->image.w, vh / a->image.h);
    const int w = static_cast<int>(a->image.w * s), h = static_cast<int>(a->image.h * s);
    r.left = video.left + static_cast<int>((vw - w) / 2);
    r.top = video.top + static_cast<int>((vh - h) / 2);
    r.right = r.left + w; r.bottom = r.top + h;
    return r;
}

// ------------------------------------------------------------------ registration dialog
struct RegInfo { std::wstring id, name; };

static INT_PTR CALLBACK regProc(HWND h, UINT m, WPARAM w, LPARAM l)
{
    switch (m) {
    case WM_INITDIALOG:
        SetWindowLongPtrW(h, GWLP_USERDATA, l);
        return TRUE;
    case WM_COMMAND:
        if (LOWORD(w) == IDOK) {
            RegInfo *r = reinterpret_cast<RegInfo *>(GetWindowLongPtrW(h, GWLP_USERDATA));
            wchar_t b[256];
            GetDlgItemTextW(h, IDC_EDIT_ID, b, 256);   r->id = b;
            GetDlgItemTextW(h, IDC_EDIT_NAME, b, 256); r->name = b;
            while (!r->id.empty() && r->id.back() == L' ') r->id.pop_back();
            if (r->id.empty()) { MessageBoxW(h, L"The ID must not be empty.", L"Register", MB_ICONWARNING); return TRUE; }
            if (r->name.empty()) r->name = r->id;
            EndDialog(h, IDOK);
            return TRUE;
        }
        if (LOWORD(w) == IDCANCEL) { EndDialog(h, IDCANCEL); return TRUE; }
        break;
    }
    return FALSE;
}

static bool askIdName(HWND parent, std::string &id, std::string &name)
{
    RegInfo r;
    if (DialogBoxParamW(GetModuleHandleW(0), MAKEINTRESOURCEW(IDD_REGISTER), parent, regProc,
                        reinterpret_cast<LPARAM>(&r)) != IDOK)
        return false;
    id = toUtf8(r.id);
    name = toUtf8(r.name);
    return true;
}

// ------------------------------------------------------------------ painting
static void drawFaces(HDC dc, App *a, const RECT &ir)
{
    const int iw = ir.right - ir.left, ih = ir.bottom - ir.top;
    SelectObject(dc, GetStockObject(NULL_BRUSH));
    SelectObject(dc, a->fontBold);
    SetBkMode(dc, OPAQUE);
    for (size_t i = 0; i < a->faces.size(); ++i) {
        const FaceView &f = a->faces[i];
        COLORREF c = f.state == 2 ? RGB(0, 200, 0) : (f.state == 1 ? RGB(255, 170, 0) : RGB(220, 0, 0));
        const bool sel = (f.trackId == a->selected);
        if (sel) c = RGB(0, 200, 255);

        const int x0 = ir.left + static_cast<int>(f.x * iw), y0 = ir.top + static_cast<int>(f.y * ih);
        const int x1 = x0 + static_cast<int>(f.w * iw),      y1 = y0 + static_cast<int>(f.h * ih);
        HPEN pen = CreatePen(PS_SOLID, px(a->hwnd, sel ? 4 : 2), c);
        HGDIOBJ old = SelectObject(dc, pen);
        SelectObject(dc, GetStockObject(NULL_BRUSH));
        Rectangle(dc, x0, y0, x1, y1);
        SelectObject(dc, old);
        DeleteObject(pen);

        HBRUSH br = CreateSolidBrush(c);                  // landmarks (a quick sanity check)
        HGDIOBJ ob = SelectObject(dc, br);
        HGDIOBJ op = SelectObject(dc, GetStockObject(NULL_PEN));
        const int rad = px(a->hwnd, 3);
        for (int k = 0; k < 5; ++k) {
            const int cx = ir.left + static_cast<int>(f.lx[k] * iw), cy = ir.top + static_cast<int>(f.ly[k] * ih);
            Ellipse(dc, cx - rad, cy - rad, cx + rad, cy + rad);
        }
        SelectObject(dc, op); SelectObject(dc, ob);
        DeleteObject(br);

        SetBkColor(dc, c);
        SetTextColor(dc, RGB(255, 255, 255));
        const std::wstring t = L" " + toWide(f.label) + L" ";
        TextOutW(dc, x0, std::max<int>(y0 - px(a->hwnd, 20), static_cast<int>(ir.top)), t.c_str(), static_cast<int>(t.size()));
    }
}

static void paintVideo(HDC hdc, App *a, const RECT &video)
{
    const int W = video.right - video.left, H = video.bottom - video.top;
    HDC mem = CreateCompatibleDC(hdc);                    // draw off-screen, copy once: no flicker
    HBITMAP bm = CreateCompatibleBitmap(hdc, W, H);
    HGDIOBJ oldBm = SelectObject(mem, bm);
    RECT local = { 0, 0, W, H };
    FillRect(mem, &local, static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)));

    if (a->image.w > 0 && !a->bgr.empty()) {
        RECT ir = imageRect(a, local);
        BITMAPINFO bmi = {};
        bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bmi.bmiHeader.biWidth = a->image.w;
        bmi.bmiHeader.biHeight = -a->image.h;             // negative = top-down rows
        bmi.bmiHeader.biPlanes = 1;
        bmi.bmiHeader.biBitCount = 24;
        bmi.bmiHeader.biCompression = BI_RGB;
        SetStretchBltMode(mem, HALFTONE);
        SetBrushOrgEx(mem, 0, 0, 0);
        StretchDIBits(mem, ir.left, ir.top, ir.right - ir.left, ir.bottom - ir.top,
                      0, 0, a->image.w, a->image.h, &a->bgr[0], &bmi, DIB_RGB_COLORS, SRCCOPY);
        drawFaces(mem, a, ir);
    }
    BitBlt(hdc, video.left, video.top, W, H, mem, 0, 0, SRCCOPY);
    SelectObject(mem, oldBm);
    DeleteObject(bm);
    DeleteDC(mem);
}

// ------------------------------------------------------------------ data from the engine
static void takeFrame(App *a)
{
    {
        std::lock_guard<std::mutex> lk(a->shared.m);
        if (!a->shared.frameNew) return;
        a->shared.frameNew = false;
        a->image.w = a->shared.frame.w;
        a->image.h = a->shared.frame.h;
        a->image.data.swap(a->shared.frame.data);
        a->faces = a->shared.faces;
        a->ms = a->shared.ms;
    }
    if (a->image.h > 0) {                                 // the camera's shape changed (new camera / first frame)?
        const double asp = static_cast<double>(a->image.w) / a->image.h;
        if (std::fabs(asp - a->aspect) > 0.01) {
            a->aspect = asp;
            if (!IsZoomed(a->hwnd) && !IsIconic(a->hwnd)) {
                RECT rc;
                GetClientRect(a->hwnd, &rc);
                fitWindow(a, rc.bottom);                  // same height, new width: video area fits exactly
            }
        }
    }
    bool still = false;                                   // forget the selection if that face vanished
    for (size_t i = 0; i < a->faces.size(); ++i) if (a->faces[i].trackId == a->selected) still = true;
    if (!still) a->selected = -1;

    // RGB (packed) -> BGR with 4-byte aligned rows, which is what GDI wants
    const int stride = (a->image.w * 3 + 3) & ~3;
    a->bgr.resize(static_cast<size_t>(stride) * a->image.h);
    for (int y = 0; y < a->image.h; ++y) {
        const unsigned char *s = &a->image.data[static_cast<size_t>(y) * a->image.w * 3];
        unsigned char *d = &a->bgr[static_cast<size_t>(y) * stride];
        for (int x = 0; x < a->image.w; ++x, s += 3, d += 3) { d[0] = s[2]; d[1] = s[1]; d[2] = s[0]; }
    }

    ++a->frames;
    const ULONGLONG now = GetTickCount64();
    if (a->fpsStart == 0) a->fpsStart = now;
    if (now - a->fpsStart >= 1000) {
        a->fps = a->frames * 1000.0 / static_cast<double>(now - a->fpsStart);
        a->frames = 0; a->fpsStart = now;
        char b[160];
        std::sprintf(b, "%s\r\nAnalysis: %.1f fps, %.0f ms/frame, %d face(s)", a->message.c_str(), a->fps, a->ms,
                     static_cast<int>(a->faces.size()));
        setText(GetDlgItem(a->hwnd, IDC_STATUS), b);
    }
}

static void takeState(App *a)
{
    std::vector<AttRow> today;
    std::vector<std::string> ids, texts;
    {
        std::lock_guard<std::mutex> lk(a->shared.m);
        a->message = a->shared.message;
        today = a->shared.today;
        ids = a->shared.personIds;
        texts = a->shared.personTexts;
    }
    setText(GetDlgItem(a->hwnd, IDC_STATUS), a->message);

    HWND lv = GetDlgItem(a->hwnd, IDC_TABLE);
    SendMessageW(lv, WM_SETREDRAW, FALSE, 0);
    ListView_DeleteAllItems(lv);
    for (size_t i = 0; i < today.size(); ++i) {           // newest first
        const AttRow &r = today[today.size() - 1 - i];
        char sc[32];
        std::sprintf(sc, "%.2f", r.score);
        const std::wstring cols[5] = { toWide(r.time.substr(11)), toWide(r.id), toWide(r.name), toWide(r.kind), toWide(sc) };
        LVITEMW it = {};
        it.mask = LVIF_TEXT;
        it.iItem = static_cast<int>(i);
        it.pszText = const_cast<wchar_t *>(cols[0].c_str());
        const int row = static_cast<int>(SendMessageW(lv, LVM_INSERTITEMW, 0, reinterpret_cast<LPARAM>(&it)));
        for (int c = 1; c < 5; ++c) ListView_SetItemText(lv, row, c, const_cast<wchar_t *>(cols[c].c_str()));
    }
    SendMessageW(lv, WM_SETREDRAW, TRUE, 0);

    HWND lb = GetDlgItem(a->hwnd, IDC_PERSONS);
    SendMessageW(lb, LB_RESETCONTENT, 0, 0);
    for (size_t i = 0; i < texts.size(); ++i)
        SendMessageW(lb, LB_ADDSTRING, 0, reinterpret_cast<LPARAM>(toWide(texts[i]).c_str()));
}

// ------------------------------------------------------------------ actions
static void startCamera(App *a, int index)
{
    if (index < 0 || index >= static_cast<int>(a->cams.size())) return;
    std::string err;
    if (!a->camera.start(a->cams[index], err))
        setText(GetDlgItem(a->hwnd, IDC_STATUS), "Camera error: " + err);
}

static std::vector<std::wstring> pickPhotos(HWND owner)
{
    std::vector<wchar_t> buf(65536, 0);
    OPENFILENAMEW ofn = {};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = owner;
    ofn.lpstrFilter = L"Images (*.jpg;*.jpeg;*.png;*.bmp)\0*.jpg;*.jpeg;*.png;*.bmp\0All files\0*.*\0";
    ofn.lpstrFile = &buf[0];
    ofn.nMaxFile = static_cast<DWORD>(buf.size());
    ofn.Flags = OFN_ALLOWMULTISELECT | OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
    std::vector<std::wstring> files;
    if (!GetOpenFileNameW(&ofn)) return files;
    const wchar_t *p = &buf[0];
    std::wstring dir = p;
    p += dir.size() + 1;
    if (*p == 0) { files.push_back(dir); return files; }  // a single file: the full path
    while (*p) { std::wstring f = p; files.push_back(dir + L"\\" + f); p += f.size() + 1; }
    return files;
}

static void onCommand(App *a, int id, int code)
{
    switch (id) {
    case IDC_CAMERA:
        if (code == CBN_SELCHANGE) {
            const int idx = static_cast<int>(SendMessageW(GetDlgItem(a->hwnd, IDC_CAMERA), CB_GETCURSEL, 0, 0));
            startCamera(a, idx);
            WritePrivateProfileStringW(L"app", L"camera", std::to_wstring(idx).c_str(), a->settingsFile.c_str());
        }
        break;
    case IDC_IR: {
        const bool on = SendMessageW(GetDlgItem(a->hwnd, IDC_IR), BM_GETCHECK, 0, 0) == BST_CHECKED;
        a->engine->setIr(on);
        WritePrivateProfileStringW(L"app", L"ir", on ? L"1" : L"0", a->settingsFile.c_str());
        break;
    }
    case IDC_BTN_SEL: {
        if (a->selected < 0) { setText(GetDlgItem(a->hwnd, IDC_STATUS), "Click on a face in the video first."); break; }
        std::string pid, name;
        if (askIdName(a->hwnd, pid, name)) a->engine->requestEnroll(a->selected, pid, name);
        break;
    }
    case IDC_BTN_PHOTOS: {
        std::string pid, name;
        if (!askIdName(a->hwnd, pid, name)) break;
        std::vector<std::wstring> files = pickPhotos(a->hwnd);
        if (files.empty()) break;
        setText(GetDlgItem(a->hwnd, IDC_STATUS), "Processing photos...");
        a->engine->enrollImages(pid, name, files);
        break;
    }
    case IDC_BTN_FOLDER: {
        BROWSEINFOW bi = {};
        bi.hwndOwner = a->hwnd;
        bi.lpszTitle = L"Folder containing ID_Name sub-folders (e.g. 1001_Alice)";
        bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
        LPITEMIDLIST pidl = SHBrowseForFolderW(&bi);
        if (!pidl) break;
        wchar_t path[MAX_PATH];
        if (SHGetPathFromIDListW(pidl, path)) {
            setText(GetDlgItem(a->hwnd, IDC_STATUS), "Importing...");
            a->engine->enrollFolder(path);
        }
        CoTaskMemFree(pidl);
        break;
    }
    case IDC_BTN_REMOVE: {
        const int sel = static_cast<int>(SendMessageW(GetDlgItem(a->hwnd, IDC_PERSONS), LB_GETCURSEL, 0, 0));
        std::string pid;
        {
            std::lock_guard<std::mutex> lk(a->shared.m);
            if (sel >= 0 && sel < static_cast<int>(a->shared.personIds.size())) pid = a->shared.personIds[sel];
        }
        if (pid.empty()) { setText(GetDlgItem(a->hwnd, IDC_STATUS), "Select a person in the list first."); break; }
        if (MessageBoxW(a->hwnd, (L"Remove " + toWide(pid) + L" and all face templates?").c_str(),
                        L"Remove person", MB_YESNO | MB_ICONQUESTION) == IDYES)
            a->engine->removePerson(pid);
        break;
    }
    case IDC_BTN_CSV: {
        const std::wstring f = exeDir() + L"\\data\\attendance.csv";
        if (GetFileAttributesW(f.c_str()) == INVALID_FILE_ATTRIBUTES)
            setText(GetDlgItem(a->hwnd, IDC_STATUS), "No attendance recorded yet.");
        else
            ShellExecuteW(a->hwnd, L"open", f.c_str(), 0, 0, SW_SHOWNORMAL);
        break;
    }
    }
}

// ------------------------------------------------------------------ window procedure
static HWND make(HWND parent, const wchar_t *cls, const wchar_t *text, DWORD style, int id, DWORD ex = 0)
{
    return CreateWindowExW(ex, cls, text, WS_CHILD | WS_VISIBLE | style, 0, 0, 10, 10, parent,
                           reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)), GetModuleHandleW(0), 0);
}

static void setColumnWidths(App *a)
{
    const int widths[5] = { 70, 70, 130, 45, 50 };
    for (int i = 0; i < 5; ++i) ListView_SetColumnWidth(GetDlgItem(a->hwnd, IDC_TABLE), i, px(a->hwnd, widths[i]));
}

static void createControls(App *a)
{
    HWND p = a->hwnd;
    HWND cb = make(p, L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_VSCROLL | WS_TABSTOP, IDC_CAMERA);
    make(p, L"BUTTON", L"IR / night mode (force grayscale)", BS_AUTOCHECKBOX | WS_TABSTOP, IDC_IR);
    make(p, L"STATIC", L"Match threshold:", 0, IDC_STATIC);
    make(p, TRACKBAR_CLASSW, L"", TBS_HORZ | TBS_NOTICKS | WS_TABSTOP, IDC_THR);
    make(p, L"STATIC", L"0.45", SS_RIGHT, IDC_THRTXT);
    make(p, L"BUTTON", L"Register selected face (click a face first)", BS_PUSHBUTTON | WS_TABSTOP, IDC_BTN_SEL);
    make(p, L"BUTTON", L"Register from photos...", BS_PUSHBUTTON | WS_TABSTOP, IDC_BTN_PHOTOS);
    make(p, L"BUTTON", L"Import folder (ID_Name sub-folders)...", BS_PUSHBUTTON | WS_TABSTOP, IDC_BTN_FOLDER);
    make(p, L"STATIC", L"Registered people (select to remove):", 0, IDC_LBL_PERSONS);
    make(p, L"LISTBOX", L"", LBS_NOTIFY | WS_VSCROLL | WS_BORDER | WS_TABSTOP, IDC_PERSONS);
    make(p, L"BUTTON", L"Remove selected person", BS_PUSHBUTTON | WS_TABSTOP, IDC_BTN_REMOVE);
    make(p, L"STATIC", L"Today's attendance", 0, IDC_LBL_TODAY);
    HWND lv = make(p, WC_LISTVIEWW, L"", LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS | WS_BORDER | WS_TABSTOP, IDC_TABLE);
    make(p, L"BUTTON", L"Open attendance CSV (Excel)", BS_PUSHBUTTON | WS_TABSTOP, IDC_BTN_CSV);
    make(p, L"STATIC", L"Starting...", SS_LEFT, IDC_STATUS);

    applyFonts(a);                                        // fonts sized for the current display scaling
    ListView_SetExtendedListViewStyle(lv, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
    const wchar_t *heads[5] = { L"Time", L"ID", L"Name", L"Type", L"Score" };
    for (int i = 0; i < 5; ++i) {
        LVCOLUMNW c = {};
        c.mask = LVCF_TEXT | LVCF_WIDTH;
        c.pszText = const_cast<wchar_t *>(heads[i]);
        c.cx = 50;
        SendMessageW(lv, LVM_INSERTCOLUMNW, i, reinterpret_cast<LPARAM>(&c));
    }
    setColumnWidths(a);

    for (size_t i = 0; i < a->cams.size(); ++i)
        SendMessageW(cb, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(a->cams[i].name.c_str()));
    if (a->cams.empty()) SendMessageW(cb, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(L"(no camera found)"));

    // saved settings
    const int thr = GetPrivateProfileIntW(L"app", L"threshold", 45, a->settingsFile.c_str());
    const int ir = GetPrivateProfileIntW(L"app", L"ir", 1, a->settingsFile.c_str());
    int cam = GetPrivateProfileIntW(L"app", L"camera", 0, a->settingsFile.c_str());
    if (cam < 0 || cam >= static_cast<int>(a->cams.size())) cam = 0;
    SendMessageW(GetDlgItem(p, IDC_THR), TBM_SETRANGE, TRUE, MAKELONG(20, 90));
    SendMessageW(GetDlgItem(p, IDC_THR), TBM_SETPOS, TRUE, thr);
    SendMessageW(GetDlgItem(p, IDC_IR), BM_SETCHECK, ir ? BST_CHECKED : BST_UNCHECKED, 0);
    SendMessageW(cb, CB_SETCURSEL, cam, 0);
    wchar_t t[16];
    swprintf(t, 16, L"%.2f", thr / 100.0);
    SetWindowTextW(GetDlgItem(p, IDC_THRTXT), t);
}

static void layoutControls(App *a)
{
    RECT rc;
    GetClientRect(a->hwnd, &rc);
    auto S = [&](int v96) { return px(a->hwnd, v96); };   // 96-dpi design value -> real pixels
    const int x = rc.right - S(PANEL_W), w = S(PANEL_W) - S(8);
    int y = S(8);
    auto put = [&](int id, int h, int xx, int ww) { MoveWindow(GetDlgItem(a->hwnd, id), xx, y, ww, S(h), TRUE); };
    put(IDC_CAMERA, 200, x, w);                  y += S(28);
    put(IDC_IR, 22, x, w);                       y += S(26);
    put(IDC_STATIC, 20, x, S(110));
    put(IDC_THR, 24, x + S(110), w - S(160));
    put(IDC_THRTXT, 20, x + w - S(44), S(44));   y += S(30);
    put(IDC_BTN_SEL, 28, x, w);                  y += S(32);
    put(IDC_BTN_PHOTOS, 28, x, w);               y += S(32);
    put(IDC_BTN_FOLDER, 28, x, w);               y += S(36);
    // Everything except two lists has a fixed size (364 design px in total). The height that is left is
    // shared by the list of people (35 %) and today's table (65 %), so the panel works down to MIN_CLIENT_H.
    const int flex = std::max(S(80), static_cast<int>(rc.bottom) - S(364));
    const int listH = std::max(S(40), flex * 35 / 100);
    const int tableH = std::max(S(40), flex - listH);
    put(IDC_LBL_PERSONS, 18, x, w);              y += S(20);
    MoveWindow(GetDlgItem(a->hwnd, IDC_PERSONS), x, y, w, listH, TRUE);   y += listH + S(4);
    put(IDC_BTN_REMOVE, 26, x, w);               y += S(32);
    put(IDC_LBL_TODAY, 18, x, w);                y += S(20);
    MoveWindow(GetDlgItem(a->hwnd, IDC_TABLE), x, y, w, tableH, TRUE);    y += tableH + S(4);
    put(IDC_BTN_CSV, 28, x, w);                  y += S(32);
    put(IDC_STATUS, 52, x, w);
}

static void paintAll(HWND hwnd, App *a, HDC dc)
{
    RECT video, rc;
    layoutRects(hwnd, video);
    GetClientRect(hwnd, &rc);
    RECT panel = { video.right, 0, rc.right, rc.bottom };
    FillRect(dc, &panel, GetSysColorBrush(COLOR_BTNFACE));
    if (a) paintVideo(dc, a, video);
}

static LRESULT CALLBACK wndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    App *a = reinterpret_cast<App *>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    switch (msg) {
    case WM_CREATE: {
        a = static_cast<App *>(reinterpret_cast<CREATESTRUCTW *>(lp)->lpCreateParams);
        SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(a));
        a->hwnd = hwnd;
        createControls(a);
        return 0;
    }
    case WM_SIZE:
        if (a && a->hwnd) {
            if (wp == SIZE_RESTORED && !a->adjusting) {   // the system resized us (clamp, snap...): restore the video shape
                RECT rc;
                GetClientRect(hwnd, &rc);
                const double shape = static_cast<double>(rc.right - panelWidth(hwnd)) / std::max<LONG>(rc.bottom, 1);
                if (std::fabs(shape - a->aspect) > 0.015 * a->aspect) fitWindow(a, rc.bottom);
            }
            layoutControls(a);
            InvalidateRect(hwnd, 0, FALSE);
        }
        return 0;
    case WM_ERASEBKGND:
        return 1;                                        // we paint everything ourselves
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC dc = BeginPaint(hwnd, &ps);
        paintAll(hwnd, a, dc);
        EndPaint(hwnd, &ps);
        return 0;
    }
    case WM_PRINTCLIENT:                                 // used by PrintWindow (screenshots of the window)
        paintAll(hwnd, a, reinterpret_cast<HDC>(wp));
        return 0;
    case WM_SIZING:                                      // user drags an edge: keep the video area's shape
        if (a && !a->adjusting) { lockAspect(a, wp, reinterpret_cast<RECT *>(lp)); return TRUE; }
        break;
    case WM_DPICHANGED:                                  // window moved to a monitor with other scaling
        if (a) {
            const RECT *r = reinterpret_cast<const RECT *>(lp);       // size Windows suggests for the new monitor
            a->adjusting = true;
            SetWindowPos(hwnd, 0, r->left, r->top, r->right - r->left, r->bottom - r->top, SWP_NOZORDER | SWP_NOACTIVATE);
            a->adjusting = false;
            applyFonts(a);
            setColumnWidths(a);
            layoutControls(a);
            InvalidateRect(hwnd, 0, FALSE);
        }
        return 0;
    case WM_APP_FRAME:
        if (a) {
            takeFrame(a);
            RECT video;
            layoutRects(hwnd, video);
            InvalidateRect(hwnd, &video, FALSE);
        }
        return 0;
    case WM_APP_STATE:
        if (a) takeState(a);
        return 0;
    case WM_LBUTTONDOWN:                                 // click a face to select it
        if (a && a->image.w > 0) {
            RECT video;
            layoutRects(hwnd, video);
            const RECT ir = imageRect(a, video);
            const double nx = double(LOWORD(lp) - ir.left) / (ir.right - ir.left);
            const double ny = double(HIWORD(lp) - ir.top) / (ir.bottom - ir.top);
            a->selected = -1;
            for (size_t i = 0; i < a->faces.size(); ++i) {
                const FaceView &f = a->faces[i];
                if (nx >= f.x && nx <= f.x + f.w && ny >= f.y && ny <= f.y + f.h) a->selected = f.trackId;
            }
            InvalidateRect(hwnd, &video, FALSE);
        }
        return 0;
    case WM_HSCROLL:                                     // threshold slider
        if (a && reinterpret_cast<HWND>(lp) == GetDlgItem(hwnd, IDC_THR)) {
            const int v = static_cast<int>(SendMessageW(GetDlgItem(hwnd, IDC_THR), TBM_GETPOS, 0, 0));
            wchar_t t[16];
            swprintf(t, 16, L"%.2f", v / 100.0);
            SetWindowTextW(GetDlgItem(hwnd, IDC_THRTXT), t);
            a->engine->setThreshold(v / 100.0f);
            wchar_t n[16];
            swprintf(n, 16, L"%d", v);
            WritePrivateProfileStringW(L"app", L"threshold", n, a->settingsFile.c_str());
        }
        return 0;
    case WM_COMMAND:
        if (a) onCommand(a, LOWORD(wp), HIWORD(wp));
        return 0;
    case WM_GETMINMAXINFO:
        if (a && a->hwnd) {                              // smallest window in which every control fits, in the right shape
            int ncW, ncH;
            frameSize(hwnd, ncW, ncH);
            const int ch = px(hwnd, MIN_CLIENT_H);
            reinterpret_cast<MINMAXINFO *>(lp)->ptMinTrackSize.x = static_cast<LONG>(ch * a->aspect + 0.5) + panelWidth(hwnd) + ncW;
            reinterpret_cast<MINMAXINFO *>(lp)->ptMinTrackSize.y = ch + ncH;
        }
        return 0;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, PWSTR, int nShow)
{
    OleInitialize(0);                                    // COM (STA) for the folder dialog and Media Foundation
    INITCOMMONCONTROLSEX icc = { sizeof(icc), ICC_LISTVIEW_CLASSES | ICC_BAR_CLASSES };
    InitCommonControlsEx(&icc);

    DemoOptions demo;                                    // scripted-run options (none in a normal start)
    parseDemoArgs(demo);
    g_scalePct = demo.scalePct;
    if (demo.screenW > 0) { g_screen.left = 0; g_screen.top = 0; g_screen.right = demo.screenW; g_screen.bottom = demo.screenH; }
    const std::wstring base = exeDir();
    const std::wstring dataDir = demo.dataDir.empty() ? base + L"\\data" : demo.dataDir;

    App app;
    app.settingsFile = (demo.dataDir.empty() ? base : demo.dataDir) + L"\\settings.ini";
    if (!demo.dataDir.empty()) CreateDirectoryW(demo.dataDir.c_str(), 0);
    if (demo.ir >= 0) WritePrivateProfileStringW(L"app", L"ir", demo.ir ? L"1" : L"0", app.settingsFile.c_str());
    if (!demo.noCamera) app.cams = listCameras();        // --no-camera: no camera is even listed

    WNDCLASSW wc = {};
    wc.lpfnWndProc = wndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursorW(0, IDC_ARROW);
    wc.lpszClassName = kClass;
    RegisterClassW(&wc);
    HWND hwnd = CreateWindowExW(0, kClass, L"Face Attendance", WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
                                CW_USEDEFAULT, CW_USEDEFAULT, 1280, 760, 0, 0, hInst, &app);
    if (!hwnd) return 1;

    // initial size: 780 px (at 96 dpi) high, but at most 90 % of the monitor's work area; the width
    // follows from the video shape, so the window never starts with the wrong proportions
    {
        int ncW, ncH;
        frameSize(hwnd, ncW, ncH);
        const RECT work = workArea(hwnd);
        fitWindow(&app, std::min<int>(px(hwnd, 780), static_cast<int>(work.bottom - work.top) * 9 / 10 - ncH));
    }

    // the engine thread starts only now: it posts messages to the window
    app.engine = new Engine(&app.camera, &app.shared, hwnd);
    app.engine->setThreshold(GetPrivateProfileIntW(L"app", L"threshold", 45, app.settingsFile.c_str()) / 100.0f);
    app.engine->setIr(GetPrivateProfileIntW(L"app", L"ir", 1, app.settingsFile.c_str()) != 0);
    app.engine->start(dataDir, base + L"\\models");
    layoutControls(&app);
    ShowWindow(hwnd, nShow);
    UpdateWindow(hwnd);
    if (!demo.noCamera) {
        startCamera(&app, static_cast<int>(SendMessageW(GetDlgItem(hwnd, IDC_CAMERA), CB_GETCURSEL, 0, 0)));
        if (app.cams.empty()) setText(GetDlgItem(hwnd, IDC_STATUS), "No camera found.");
    }
    DemoDriver driver;
    driver.start(hwnd, &app.camera, app.engine, demo);

    MSG m;
    while (GetMessageW(&m, 0, 0, 0) > 0) {
        if (!IsDialogMessageW(hwnd, &m)) { TranslateMessage(&m); DispatchMessageW(&m); }
    }

    driver.stop();
    app.engine->stop();
    app.camera.stop();
    delete app.engine;
    OleUninitialize();
    return 0;
}
