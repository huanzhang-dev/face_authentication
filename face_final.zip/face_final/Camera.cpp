#include "Camera.h"
#include "Util.h"
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <mferror.h>
#include <wrl/client.h>
#include <algorithm>
#include <cstdlib>

using Microsoft::WRL::ComPtr;

static void ensureMF()
{
    static bool done = false;                 // MFStartup once; the process exit cleans up
    if (!done) { MFStartup(MF_VERSION); done = true; }
}

// KSCATEGORY_SENSOR_CAMERA: where Windows lists the IR cameras.
static const GUID kSensorCamera =
    { 0x24e552d7, 0x6523, 0x47f7, { 0xa6, 0x47, 0xd3, 0x46, 0x5b, 0xf1, 0xf5, 0xca } };

static void enumCategory(bool sensor, std::vector<CameraInfo> &out)
{
    ComPtr<IMFAttributes> a;
    if (FAILED(MFCreateAttributes(&a, 2))) return;
    a->SetGUID(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE, MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_GUID);
#ifdef NTDDI_WIN10_TH2
    if (sensor) a->SetGUID(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_CATEGORY, kSensorCamera);
#else
    if (sensor) return;                       // SDK too old to ask for IR / sensor cameras
#endif
    IMFActivate **devs = 0;
    UINT32 n = 0;
    if (FAILED(MFEnumDeviceSources(a.Get(), &devs, &n))) return;
    for (UINT32 i = 0; i < n; ++i) {
        CameraInfo ci;
        ci.sensor = sensor;
        WCHAR *s = 0; UINT32 len = 0;
        if (SUCCEEDED(devs[i]->GetAllocatedString(MF_DEVSOURCE_ATTRIBUTE_FRIENDLY_NAME, &s, &len))) {
            ci.name = s; CoTaskMemFree(s);
        }
        s = 0;
        if (SUCCEEDED(devs[i]->GetAllocatedString(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_SYMBOLIC_LINK, &s, &len))) {
            ci.link = s; CoTaskMemFree(s);
        }
        devs[i]->Release();
        bool dup = false;
        for (size_t k = 0; k < out.size(); ++k) if (out[k].link == ci.link) dup = true;
        if (!dup && !ci.link.empty()) {
            if (sensor) ci.name += L"  [IR]";
            out.push_back(ci);
        }
    }
    CoTaskMemFree(devs);
}

std::vector<CameraInfo> listCameras()
{
    ensureMF();
    std::vector<CameraInfo> v;
    enumCategory(false, v);                   // normal cameras
    enumCategory(true, v);                    // IR / sensor cameras
    return v;
}

// ------------------------------------------------------------------ pixel conversion
static inline unsigned char clamp8(int v) { return static_cast<unsigned char>(v < 0 ? 0 : (v > 255 ? 255 : v)); }

static inline void yuv2rgb(int y, int u, int v, unsigned char *p)
{
    int c = y - 16, d = u - 128, e = v - 128;
    p[0] = clamp8((298 * c + 409 * e + 128) >> 8);
    p[1] = clamp8((298 * c - 100 * d - 208 * e + 128) >> 8);
    p[2] = clamp8((298 * c + 516 * d + 128) >> 8);
}

enum PixFmt { FMT_UNKNOWN, FMT_RGB32, FMT_RGB24, FMT_YUY2, FMT_NV12, FMT_L8, FMT_L16 };

static PixFmt fmtOf(const GUID &g)
{
    if (g == MFVideoFormat_RGB32 || g == MFVideoFormat_ARGB32) return FMT_RGB32;
    if (g == MFVideoFormat_RGB24) return FMT_RGB24;
    if (g == MFVideoFormat_YUY2)  return FMT_YUY2;
    if (g == MFVideoFormat_NV12)  return FMT_NV12;
    if (g == MFVideoFormat_L8)    return FMT_L8;
    if (g == MFVideoFormat_L16)   return FMT_L16;
    return FMT_UNKNOWN;
}

// stride: bytes per row; negative = bottom-up (usual for RGB)
static bool convertFrame(const BYTE *p, DWORD len, int w, int h, LONG stride, PixFmt f, RgbImage &out)
{
    const size_t ab = static_cast<size_t>(stride < 0 ? -stride : stride);
    const bool flip = stride < 0;
    out.w = w; out.h = h;
    out.data.resize(static_cast<size_t>(w) * h * 3);
    unsigned char *dst = &out.data[0];
    size_t need = ab * h;
    if (f == FMT_NV12) need = ab * h * 3 / 2;
    if (len < need) return false;

    for (int y = 0; y < h; ++y) {
        const int sy = flip ? (h - 1 - y) : y;
        const BYTE *row = p + ab * sy;
        unsigned char *d = dst + static_cast<size_t>(y) * w * 3;
        switch (f) {
        case FMT_RGB32:  for (int x = 0; x < w; ++x, d += 3) { d[0] = row[x*4+2]; d[1] = row[x*4+1]; d[2] = row[x*4]; } break;
        case FMT_RGB24:  for (int x = 0; x < w; ++x, d += 3) { d[0] = row[x*3+2]; d[1] = row[x*3+1]; d[2] = row[x*3]; } break;
        case FMT_YUY2:   for (int x = 0; x + 1 < w; x += 2, d += 6) {
                             const BYTE *s = row + x * 2;           // Y0 U Y1 V
                             yuv2rgb(s[0], s[1], s[3], d); yuv2rgb(s[2], s[1], s[3], d + 3); } break;
        case FMT_NV12:   { const BYTE *uv = p + ab * h + ab * (y / 2);
                           for (int x = 0; x < w; ++x, d += 3) yuv2rgb(row[x], uv[(x / 2) * 2], uv[(x / 2) * 2 + 1], d); } break;
        case FMT_L8:     for (int x = 0; x < w; ++x, d += 3) d[0] = d[1] = d[2] = row[x]; break;
        case FMT_L16:    for (int x = 0; x < w; ++x, d += 3) d[0] = d[1] = d[2] = row[x*2+1]; break;   // high byte
        default: return false;
        }
    }
    return true;
}

// ------------------------------------------------------------------ Camera
struct Camera::Impl
{
    ComPtr<IMFMediaSource> source;
    ComPtr<IMFSourceReader> reader;
    int w, h;
    LONG stride;
    PixFmt fmt;
    Impl() : w(0), h(0), stride(0), fmt(FMT_UNKNOWN) {}
};

Camera::Camera() : m_impl(0), m_running(false), m_seq(0) {}
Camera::~Camera() { stop(); }

bool Camera::start(const CameraInfo &info, std::string &err)
{
    stop();
    ensureMF();
    Impl *im = new Impl;

    ComPtr<IMFAttributes> a;
    MFCreateAttributes(&a, 3);
    a->SetGUID(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE, MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_GUID);
    a->SetString(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_SYMBOLIC_LINK, info.link.c_str());
#ifdef NTDDI_WIN10_TH2
    if (info.sensor) a->SetGUID(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_CATEGORY, kSensorCamera);
#endif
    if (FAILED(MFCreateDeviceSource(a.Get(), &im->source))) { err = "cannot open the camera (in use?)"; delete im; return false; }

    ComPtr<IMFAttributes> ra;
    MFCreateAttributes(&ra, 1);
    ra->SetUINT32(MF_SOURCE_READER_ENABLE_VIDEO_PROCESSING, TRUE);   // lets MF convert YUY2/NV12/MJPG -> RGB32
    if (FAILED(MFCreateSourceReaderFromMediaSource(im->source.Get(), ra.Get(), &im->reader))) {
        err = "cannot create the source reader"; delete im; return false;
    }

    const DWORD stream = MF_SOURCE_READER_FIRST_VIDEO_STREAM;
    // 1) pick the native mode closest to 640x480 (big frames only cost time)
    ComPtr<IMFMediaType> best;
    UINT32 bw = 0, bh = 0;
    long bestScore = 1L << 30;
    for (DWORD i = 0;; ++i) {
        ComPtr<IMFMediaType> t;
        if (FAILED(im->reader->GetNativeMediaType(stream, i, &t))) break;
        UINT32 w = 0, h = 0;
        MFGetAttributeSize(t.Get(), MF_MT_FRAME_SIZE, &w, &h);
        if (w < 320) continue;
        long sc = labs(static_cast<long>(w) - 640) + labs(static_cast<long>(h) - 480);
        if (sc < bestScore) { bestScore = sc; best = t; bw = w; bh = h; }
    }
    if (best) im->reader->SetCurrentMediaType(stream, 0, best.Get());      // selects size / frame rate

    // 2) ask for RGB32; if the device cannot, keep the native format and convert ourselves
    ComPtr<IMFMediaType> rgb;
    MFCreateMediaType(&rgb);
    rgb->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
    rgb->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_RGB32);
    if (bw) MFSetAttributeSize(rgb.Get(), MF_MT_FRAME_SIZE, bw, bh);
    im->reader->SetCurrentMediaType(stream, 0, rgb.Get());

    ComPtr<IMFMediaType> cur;
    if (FAILED(im->reader->GetCurrentMediaType(stream, &cur))) { err = "no media type"; delete im; return false; }
    UINT32 w = 0, h = 0;
    MFGetAttributeSize(cur.Get(), MF_MT_FRAME_SIZE, &w, &h);
    GUID sub = GUID_NULL;
    cur->GetGUID(MF_MT_SUBTYPE, &sub);
    im->fmt = fmtOf(sub);
    if (im->fmt == FMT_UNKNOWN || w == 0) { err = "camera format not supported (e.g. raw MJPG without conversion)"; delete im; return false; }
    im->w = static_cast<int>(w); im->h = static_cast<int>(h);
    UINT32 s = 0;
    LONG stride = 0;
    if (SUCCEEDED(cur->GetUINT32(MF_MT_DEFAULT_STRIDE, &s))) stride = static_cast<LONG>(static_cast<INT32>(s));
    else if (FAILED(MFGetStrideForBitmapInfoHeader(sub.Data1, w, &stride))) stride = (im->fmt == FMT_RGB32) ? -static_cast<LONG>(w) * 4 : static_cast<LONG>(w);
    im->stride = stride;

    m_impl = im;
    m_running = true;
    m_thread = std::thread(&Camera::captureLoop, this);
    return true;
}

void Camera::stop()
{
    m_running = false;
    if (m_thread.joinable()) m_thread.join();
    if (m_impl) {
        if (m_impl->source) m_impl->source->Shutdown();
        delete m_impl;
        m_impl = 0;
    }
}

void Camera::captureLoop()
{
    CoInitializeEx(0, COINIT_MULTITHREADED);
    Impl *im = m_impl;
    while (m_running) {
        DWORD idx = 0, flags = 0;
        LONGLONG ts = 0;
        ComPtr<IMFSample> sample;
        HRESULT hr = im->reader->ReadSample(MF_SOURCE_READER_FIRST_VIDEO_STREAM, 0, &idx, &flags, &ts, &sample);
        if (FAILED(hr) || (flags & MF_SOURCE_READERF_ERROR)) break;
        if (!sample) continue;

        ComPtr<IMFMediaBuffer> buf;
        if (FAILED(sample->ConvertToContiguousBuffer(&buf))) continue;
        BYTE *p = 0; DWORD maxLen = 0, curLen = 0;
        if (FAILED(buf->Lock(&p, &maxLen, &curLen))) continue;
        RgbImage img;
        bool ok = convertFrame(p, curLen, im->w, im->h, im->stride, im->fmt, img);
        buf->Unlock();
        if (!ok) continue;

        {
            std::lock_guard<std::mutex> lk(m_mutex);
            m_frame.w = img.w; m_frame.h = img.h; m_frame.data.swap(img.data);
            ++m_seq;
        }
        m_cv.notify_all();
    }
    m_running = false;
    CoUninitialize();
}

void Camera::injectFrame(const RgbImage &img)
{
    {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_frame = img;
        ++m_seq;
    }
    m_cv.notify_all();
}

bool Camera::waitFrame(RgbImage &out, unsigned long long &lastSeq, int timeoutMs)
{
    std::unique_lock<std::mutex> lk(m_mutex);
    if (!m_cv.wait_for(lk, std::chrono::milliseconds(timeoutMs), [&] { return m_seq != lastSeq; }))
        return false;
    out.w = m_frame.w; out.h = m_frame.h; out.data = m_frame.data;    // copy: the camera keeps writing
    lastSeq = m_seq;
    return !out.data.empty();
}
