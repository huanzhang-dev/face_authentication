#include "FaceRecognizer.h"
#include <algorithm>
#include <cmath>

static const int FACE = 112;    // aligned face is FACE x FACE pixels

// Standard ArcFace 5-point template for a 112x112 crop.
static const float kTplX[5] = { 38.2946f, 73.5318f, 56.0252f, 41.5493f, 70.7299f };
static const float kTplY[5] = { 51.6963f, 51.5014f, 71.7366f, 92.3655f, 92.2041f };

FaceRecognizer::FaceRecognizer()
    : m_mean(127.5f), m_norm(1.f / 128.f), m_stretch(true), m_loaded(false) {}

bool FaceRecognizer::load(const std::string &paramPath, const std::string &binPath,
                          const std::string &inputName, const std::string &outputName,
                          float mean, float norm, bool contrastStretch, int threads)
{
    m_net.opt.num_threads = threads;
    m_net.opt.use_vulkan_compute = false;
    m_in = inputName;  m_out = outputName;
    m_mean = mean;     m_norm = norm;
    m_stretch = contrastStretch;
    // paths must be in the ANSI code page: ncnn opens them with fopen()
    if (m_net.load_param(paramPath.c_str()) != 0) return false;
    if (m_net.load_model(binPath.c_str()) != 0) return false;
    m_loaded = true;
    return true;
}

// Bilinear sample of one channel, coordinates clamped to the image border.
static inline float sampleChannel(const RgbImage &im, float x, float y, int c)
{
    x = std::max(0.f, std::min(x, static_cast<float>(im.w - 1)));
    y = std::max(0.f, std::min(y, static_cast<float>(im.h - 1)));
    int x0 = static_cast<int>(x), y0 = static_cast<int>(y);
    int x1 = std::min(x0 + 1, im.w - 1), y1 = std::min(y0 + 1, im.h - 1);
    float fx = x - x0, fy = y - y0;
    const unsigned char *d = im.data.data();
    float a = d[(y0 * im.w + x0) * 3 + c], b = d[(y0 * im.w + x1) * 3 + c];
    float e = d[(y1 * im.w + x0) * 3 + c], f = d[(y1 * im.w + x1) * 3 + c];
    return (a * (1 - fx) + b * fx) * (1 - fy) + (e * (1 - fx) + f * fx) * fy;
}

// Similarity transform (rotation + uniform scale + translation) that maps the
// detected landmarks onto the template, solved in closed form (2-D Umeyama).
// With centred points s_i, d_i and complex numbers: (a + ib) = sum(conj(s)*d) / sum(|s|^2)
static void alignFace(const RgbImage &img, const FaceDet &f, unsigned char *out /*112*112*3*/)
{
    float msx = 0, msy = 0, mdx = 0, mdy = 0;
    for (int i = 0; i < 5; ++i) { msx += f.lx[i]; msy += f.ly[i]; mdx += kTplX[i]; mdy += kTplY[i]; }
    msx /= 5; msy /= 5; mdx /= 5; mdy /= 5;

    float num_a = 0, num_b = 0, den = 0;
    for (int i = 0; i < 5; ++i) {
        float sx = f.lx[i] - msx, sy = f.ly[i] - msy;
        float dx = kTplX[i] - mdx, dy = kTplY[i] - mdy;
        num_a += sx * dx + sy * dy;
        num_b += sx * dy - sy * dx;
        den   += sx * sx + sy * sy;
    }
    if (den < 1e-6f) den = 1e-6f;
    const float a = num_a / den, b = num_b / den;        // matrix M = [a -b; b a]
    const float tx = mdx - (a * msx - b * msy);          // translation: d = M*s + t
    const float ty = mdy - (b * msx + a * msy);
    const float inv = 1.f / (a * a + b * b + 1e-12f);    // M^-1 = inv * [a b; -b a]

    // Inverse mapping: for every output pixel find where it comes from in the source.
    for (int y = 0; y < FACE; ++y) {
        for (int x = 0; x < FACE; ++x) {
            float ux = x - tx, uy = y - ty;
            float srcX = (a * ux + b * uy) * inv;
            float srcY = (-b * ux + a * uy) * inv;
            unsigned char *p = out + (y * FACE + x) * 3;
            for (int c = 0; c < 3; ++c)
                p[c] = static_cast<unsigned char>(sampleChannel(img, srcX, srcY, c) + 0.5f);
        }
    }
}

// Robust brightness/contrast normalisation: map the 1%..99% luminance range of the
// face to 0..255. This is what makes dim IR / night frames comparable to well-lit photos.
static void stretchContrast(unsigned char *p, int nPixels)
{
    int hist[256] = { 0 };
    for (int i = 0; i < nPixels; ++i)
        hist[(77 * p[i * 3] + 150 * p[i * 3 + 1] + 29 * p[i * 3 + 2]) >> 8]++;
    int lo = 0, hi = 255, acc = 0;
    const int cut = nPixels / 100;
    for (int v = 0; v < 256; ++v) { acc += hist[v]; if (acc > cut) { lo = v; break; } }
    acc = 0;
    for (int v = 255; v >= 0; --v) { acc += hist[v]; if (acc > cut) { hi = v; break; } }
    if (hi - lo < 16) return;                          // flat image: nothing sensible to stretch
    const float k = 255.f / (hi - lo);
    for (int i = 0; i < nPixels * 3; ++i) {
        float v = (p[i] - lo) * k;
        p[i] = static_cast<unsigned char>(v < 0 ? 0 : (v > 255 ? 255 : v));
    }
}

bool FaceRecognizer::extract(const RgbImage &img, const FaceDet &face, FloatVec &emb) const
{
    if (!m_loaded || img.data.empty()) return false;

    unsigned char crop[FACE * FACE * 3];
    alignFace(img, face, crop);
    if (m_stretch) stretchContrast(crop, FACE * FACE);

    ncnn::Mat in = ncnn::Mat::from_pixels(crop, ncnn::Mat::PIXEL_RGB, FACE, FACE);
    const float mean[3] = { m_mean, m_mean, m_mean };
    const float norm[3] = { m_norm, m_norm, m_norm };
    in.substract_mean_normalize(mean, norm);

    ncnn::Extractor ex = m_net.create_extractor();
    ex.input(m_in.c_str(), in);
    ncnn::Mat out;
    if (ex.extract(m_out.c_str(), out) != 0) return false;

    const int n = out.w * out.h * out.c;
    const float *p = out;
    emb.assign(p, p + n);

    float len = 0.f;                                   // L2 normalise
    for (int i = 0; i < n; ++i) len += emb[i] * emb[i];
    len = std::sqrt(len);
    if (len < 1e-6f) return false;
    for (int i = 0; i < n; ++i) emb[i] /= len;
    return true;
}
