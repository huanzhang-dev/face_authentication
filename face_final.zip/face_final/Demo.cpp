#include "Demo.h"
#include "Camera.h"
#include "Engine.h"
#include "ImageIO.h"
#include <shellapi.h>
#include <wincodec.h>
#include <wrl/client.h>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <fstream>

using Microsoft::WRL::ComPtr;

#ifndef PW_RENDERFULLCONTENT
#define PW_RENDERFULLCONTENT 0x00000002
#endif

// A minimised window has no client area (0x0): if something on the desktop minimised it, bring it
// back before measuring or taking a screenshot.
static void restoreIfMinimized(HWND hwnd)
{
    if (!IsIconic(hwnd)) return;
    ShowWindow(hwnd, SW_RESTORE);
    Sleep(500);                                          // let the window re-layout itself
}

// ------------------------------------------------------------------ command line
static bool splitAt(const std::wstring &s, std::wstring &arg, int &ms)
{
    const size_t at = s.rfind(L'@');
    if (at == std::wstring::npos) return false;
    arg = s.substr(0, at);
    ms = _wtoi(s.substr(at + 1).c_str());
    return true;
}

bool parseDemoArgs(DemoOptions &o)
{
    int n = 0;
    wchar_t **v = CommandLineToArgvW(GetCommandLineW(), &n);
    if (!v) return true;
    bool ok = true;
    for (int i = 1; i < n; ++i) {
        const std::wstring a = v[i];
        const bool more = i + 1 < n;
        if (a == L"--no-camera") o.noCamera = true;
        else if (a == L"--data" && more) o.dataDir = v[++i];
        else if (a == L"--ir" && more) o.ir = _wtoi(v[++i]);
        else if (a == L"--scale" && more) o.scalePct = _wtoi(v[++i]);
        else if (a == L"--screen" && more) { if (swscanf(v[++i], L"%dx%d", &o.screenW, &o.screenH) != 2) ok = false; }
        else if ((a == L"--import" || a == L"--feed" || a == L"--shot" || a == L"--report") && more) {
            DemoAction d;
            d.kind = toUtf8(a.substr(2));
            if (!splitAt(v[++i], d.arg, d.ms)) ok = false; else o.actions.push_back(d);
        } else if (a.compare(0, 7, L"--quit@") == 0) {
            DemoAction d;
            d.kind = "quit"; d.ms = _wtoi(a.c_str() + 7);
            o.actions.push_back(d);
        }
        // unknown options are ignored on purpose (a normal start has none)
    }
    LocalFree(v);
    std::stable_sort(o.actions.begin(), o.actions.end(),
                     [](const DemoAction &x, const DemoAction &y) { return x.ms < y.ms; });
    return ok;
}

// ------------------------------------------------------------------ screenshot as PNG
static bool savePng(const std::wstring &path, int w, int h, const std::vector<unsigned char> &bgra)
{
    ComPtr<IWICImagingFactory> f;
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, 0, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&f)))) return false;
    ComPtr<IWICStream> stream;
    if (FAILED(f->CreateStream(&stream)) || FAILED(stream->InitializeFromFilename(path.c_str(), GENERIC_WRITE))) return false;
    ComPtr<IWICBitmapEncoder> enc;
    if (FAILED(f->CreateEncoder(GUID_ContainerFormatPng, 0, &enc)) || FAILED(enc->Initialize(stream.Get(), WICBitmapEncoderNoCache))) return false;
    ComPtr<IWICBitmapFrameEncode> fr;
    ComPtr<IPropertyBag2> props;
    if (FAILED(enc->CreateNewFrame(&fr, &props)) || FAILED(fr->Initialize(props.Get()))) return false;
    fr->SetSize(w, h);
    WICPixelFormatGUID fmt = GUID_WICPixelFormat32bppBGRA;
    fr->SetPixelFormat(&fmt);
    if (FAILED(fr->WritePixels(h, w * 4, static_cast<UINT>(bgra.size()), const_cast<BYTE *>(&bgra[0])))) return false;
    return SUCCEEDED(fr->Commit()) && SUCCEEDED(enc->Commit());
}

static bool shot(HWND hwnd, const std::wstring &path)
{
    restoreIfMinimized(hwnd);
    RECT rc;
    GetClientRect(hwnd, &rc);
    const int w = rc.right, h = rc.bottom;
    if (w <= 0 || h <= 0) return false;
    HDC wdc = GetDC(hwnd);
    HDC mem = CreateCompatibleDC(wdc);
    HBITMAP bm = CreateCompatibleBitmap(wdc, w, h);
    HGDIOBJ old = SelectObject(mem, bm);
    PrintWindow(hwnd, mem, 1 /*PW_CLIENTONLY*/ | PW_RENDERFULLCONTENT);   // works even if parts are off-screen
    BITMAPINFO bi = {};
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = w; bi.bmiHeader.biHeight = -h; bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
    std::vector<unsigned char> px(static_cast<size_t>(w) * h * 4);
    GetDIBits(mem, bm, 0, h, &px[0], &bi, DIB_RGB_COLORS);
    for (size_t i = 3; i < px.size(); i += 4) px[i] = 255;               // opaque
    SelectObject(mem, old); DeleteObject(bm); DeleteDC(mem); ReleaseDC(hwnd, wdc);
    return savePng(path, w, h, px);
}

// ------------------------------------------------------------------ layout report
static BOOL CALLBACK reportChild(HWND c, LPARAM lp)
{
    std::ofstream *o = reinterpret_cast<std::ofstream *>(lp);
    HWND parent = GetParent(c);
    if (parent != GetAncestor(c, GA_ROOT)) return TRUE;    // only the window's own controls, not parts inside them
    RECT r;
    GetWindowRect(c, &r);
    POINT a = { r.left, r.top }, b = { r.right, r.bottom };
    ScreenToClient(parent, &a); ScreenToClient(parent, &b);
    wchar_t cls[64] = L"";
    GetClassNameW(c, cls, 64);
    *o << "control " << GetDlgCtrlID(c) << ' ' << toUtf8(cls) << ' ' << a.x << ' ' << a.y << ' ' << b.x << ' ' << b.y << '\n';
    return TRUE;
}

static void report(HWND hwnd, const std::wstring &path)
{
    restoreIfMinimized(hwnd);
    std::ofstream o(path.c_str());
    RECT c, w;
    GetClientRect(hwnd, &c);
    GetWindowRect(hwnd, &w);
    typedef UINT (WINAPI *Fn)(HWND);
    Fn fn = reinterpret_cast<Fn>(GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetDpiForWindow"));
    o << "client " << c.right << ' ' << c.bottom << '\n';
    o << "window " << (w.right - w.left) << ' ' << (w.bottom - w.top) << '\n';
    o << "system_dpi " << (fn ? fn(hwnd) : 96) << '\n';
    EnumChildWindows(hwnd, reportChild, reinterpret_cast<LPARAM>(&o));
}

// ------------------------------------------------------------------ driver thread
DemoDriver::DemoDriver() : m_hwnd(0), m_cam(0), m_eng(0), m_stop(false) {}
DemoDriver::~DemoDriver() { stop(); }

void DemoDriver::start(HWND hwnd, Camera *cam, Engine *eng, const DemoOptions &o)
{
    m_hwnd = hwnd; m_cam = cam; m_eng = eng; m_opt = o;
    m_stop = false;
    if (!m_opt.actions.empty()) m_thread = std::thread(&DemoDriver::run, this);
}

void DemoDriver::stop()
{
    m_stop = true;
    if (m_thread.joinable()) m_thread.join();
}

void DemoDriver::run()
{
    CoInitializeEx(0, COINIT_MULTITHREADED);
    const ULONGLONG t0 = GetTickCount64();
    RgbImage feed;
    bool feeding = false;
    size_t next = 0;
    while (!m_stop && next <= m_opt.actions.size()) {
        const ULONGLONG now = GetTickCount64() - t0;
        while (next < m_opt.actions.size() && static_cast<ULONGLONG>(m_opt.actions[next].ms) <= now) {
            const DemoAction &a = m_opt.actions[next++];
            if (a.kind == "import") m_eng->enrollFolder(a.arg);
            else if (a.kind == "feed") {
                if (a.arg == L"none") feeding = false;
                else { RgbImage im; if (loadImageRgb(a.arg, im)) { feed = im; feeding = true; } }
            }
            else if (a.kind == "shot") shot(m_hwnd, a.arg);
            else if (a.kind == "report") report(m_hwnd, a.arg);
            else if (a.kind == "quit") { PostMessage(m_hwnd, WM_CLOSE, 0, 0); CoUninitialize(); return; }
        }
        if (feeding) m_cam->injectFrame(feed);       // ~10 frames per second, like a slow camera
        Sleep(100);
    }
    CoUninitialize();
}
