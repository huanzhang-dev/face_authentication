// ImageIO.h - photo loading (Windows Imaging Component) and simple image helpers.
#pragma once
#include <string>
#include "Types.h"

// Loads JPG/PNG/BMP/... as packed RGB. Honours the EXIF rotation of phone photos.
// COM must be initialised on the calling thread.
bool loadImageRgb(const std::wstring &path, RgbImage &out);

// In place: R = G = B = luminance. Used for IR / night mode.
void toGray(RgbImage &img);

// In place: bilinear down-scale so that the width is at most maxW.
void shrinkToWidth(RgbImage &img, int maxW);
