# Instructions for working in this project (Face Attendance)

## Keep the code walkthrough in step with the code (mandatory)

`CODE_WALKTHROUGH.md` explains every statement of the program, in execution order, with line numbers.
Whenever you add, remove or change code in any `.cpp`, `.h`, `.rc` file of this project:

1. Update the matching section(s) of `CODE_WALKTHROUGH.md` in the same task: corrected line numbers, new or changed behaviour, new files (add a heading and a table row), removed code (remove its text).
2. Add a one-line entry to the change log at the end of the document.
3. Run `powershell -File tools\check_docs.ps1`. It must list every file you changed. After the text is correct, run `powershell -File tools\check_docs.ps1 -Update` and then `powershell -File tools\check_docs.ps1` again, which must say "up to date".
4. If the change affects what the user sees or how to build/run, also update `README.md`.

Never run `-Update` just to silence the check: it records that the text matches the code.

## Build and test
* Build: `MSBuild FaceAttendance.sln /p:Configuration=Release /p:Platform=x64` (add `/p:PlatformToolset=v142 /p:WindowsTargetPlatformVersion=10.0.19041.0` on VS2019 machines). Binary: `bin\Release\FaceAttendance.exe`.
* Test harnesses without a GUI (they run the real Engine with an injected camera frame; paths are `Z:\face\...`): `tools\build_app_test.bat` then `tools\app_test.exe` (end to end: register, recognise, attendance; create `tools\testdata\apptest_data` first), and `tools\build_app_test.bat app_test_bugs` then `tools\app_test_bugs.exe` (data-loss regression: damaged gallery, locked CSV; must print "ALL TESTS PASSED"). Run both after changing Engine, Store or Camera.
* UI / layout / workflow check: `powershell -File tools\run_demo.ps1` (about 2 minutes; builds nothing, uses `bin\Release\FaceAttendance.exe`; needs `tools\venv`). It must end with "Layout runs with failures: 0 of 14" and three attendance rows. Run it after changing `main.cpp`, `Demo.cpp`, `app.manifest` or the engine. If the numbers or screenshots change, update `WORKFLOW_DEMO.md` (copies of the key pictures are in `demo\`).
* Do not open the live camera in automated tests (privacy); use `--no-camera` with `--feed`, or `Camera::injectFrame`.
