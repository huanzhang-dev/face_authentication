// Demo.h - scripted runs without a camera: feed a picture as if the camera delivered it, import
// a folder of photos, take screenshots of the window, write a layout report, quit. Used for the
// workflow demonstration and for the screen-size / display-scaling tests (tools\run_demo.ps1).
//
// Command line (all optional; nothing changes for a normal start):
//   --no-camera              do not list or open any camera
//   --data <folder>          keep data and settings.ini in this folder (instead of the exe folder)
//   --ir <0|1>               set IR / night mode
//   --scale <percent>        pretend Windows display scaling (100, 125, 150, 200 ...)
//   --screen <W>x<H>         pretend the work area of the monitor has this size
//   --import <folder>@<ms>   at <ms> after start: register people from ID_Name sub-folders
//   --feed <image>@<ms>      at <ms>: send this picture as camera frames ("none" stops)
//   --shot <png>@<ms>        at <ms>: save the window's client area as PNG
//   --report <txt>@<ms>      at <ms>: write client size, scaling and the rectangle of every control
//   --quit@<ms>              at <ms>: close the program
#pragma once
#include <atomic>
#include <string>
#include <thread>
#include <vector>
#include "Util.h"

class Camera;
class Engine;

struct DemoAction
{
    int ms;                     // time after start
    std::string kind;           // import | feed | shot | report | quit
    std::wstring arg;
    DemoAction() : ms(0) {}
};

struct DemoOptions
{
    bool noCamera;
    std::wstring dataDir;
    int scalePct, screenW, screenH, ir;
    std::vector<DemoAction> actions;
    DemoOptions() : noCamera(false), scalePct(0), screenW(0), screenH(0), ir(-1) {}
    bool active() const { return noCamera || !actions.empty(); }
};

bool parseDemoArgs(DemoOptions &o);     // reads the process command line; false = a bad option

class DemoDriver
{
public:
    DemoDriver();
    ~DemoDriver();
    void start(HWND hwnd, Camera *cam, Engine *eng, const DemoOptions &o);
    void stop();

private:
    void run();
    HWND m_hwnd;
    Camera *m_cam;
    Engine *m_eng;
    DemoOptions m_opt;
    std::thread m_thread;
    std::atomic<bool> m_stop;
};
