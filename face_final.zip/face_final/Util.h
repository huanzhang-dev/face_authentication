// Util.h - Windows string helpers. Inside the program text is UTF-8 (std::string);
// the Win32 UI and file APIs use UTF-16 (std::wstring).
#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <objbase.h>        // CoInitializeEx
#include <string>

inline std::wstring toWide(const std::string &s)
{
    if (s.empty()) return std::wstring();
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), 0, 0);
    std::wstring w(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), &w[0], n);
    return w;
}

inline std::string toUtf8(const std::wstring &w)
{
    if (w.empty()) return std::string();
    int n = WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), 0, 0, 0, 0);
    std::string s(n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), &s[0], n, 0, 0);
    return s;
}

// ncnn opens model files with fopen(), which wants the ANSI code page.
inline std::string toAnsi(const std::wstring &w)
{
    if (w.empty()) return std::string();
    int n = WideCharToMultiByte(CP_ACP, 0, w.data(), (int)w.size(), 0, 0, 0, 0);
    std::string s(n, '\0');
    WideCharToMultiByte(CP_ACP, 0, w.data(), (int)w.size(), &s[0], n, 0, 0);
    return s;
}

inline std::wstring exeDir()
{
    wchar_t b[MAX_PATH];
    GetModuleFileNameW(0, b, MAX_PATH);
    std::wstring p(b);
    return p.substr(0, p.find_last_of(L"\\/"));
}
