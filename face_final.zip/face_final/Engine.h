// Engine.h - the "brain": camera frame -> detect -> track -> recognise -> decide.
// Runs in its own thread so the window never waits for the networks.
#pragma once
#include <atomic>
#include <functional>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include "Camera.h"
#include "FaceDetector.h"
#include "FaceRecognizer.h"
#include "Store.h"
#include "Util.h"

// Messages the engine posts to the window.
enum { WM_APP_FRAME = WM_APP + 1, WM_APP_STATE = WM_APP + 2 };

// Data handed from the engine thread to the window thread (guard with 'm').
struct SharedState
{
    std::mutex m;
    RgbImage frame;                     // the frame that was analysed (grey in IR mode)
    FaceViewList faces;
    double ms;                          // analysis time of that frame
    bool frameNew;
    std::string message;                // last status text
    std::vector<AttRow> today;          // today's attendance
    std::vector<std::string> personIds, personTexts;
    SharedState() : ms(0), frameNew(false) {}
};

class Engine
{
public:
    Engine(Camera *cam, SharedState *st, HWND hwnd);
    ~Engine();

    void start(const std::wstring &dataDir, const std::wstring &modelDir);
    void stop();

    // thread-safe settings
    void setThreshold(float t) { m_thr = t; }
    void setIr(bool v)         { m_ir = v; }

    // thread-safe commands, executed in the engine thread
    void requestEnroll(int trackId, const std::string &id, const std::string &name);
    void enrollImages(const std::string &id, const std::string &name, const std::vector<std::wstring> &files);
    void enrollFolder(const std::wstring &dir);
    void removePerson(const std::string &id);

private:
    struct Track {
        int  id;
        FaceDet det;                     // latest detection (pixel coordinates)
        float bx0, by0, bx1, by1;        // smoothed box
        int  missed, age, lastRecog;
        std::string candId;              // person currently voted for
        int  streak;                     // consecutive agreeing votes
        bool confirmed, reported;
        std::string personId, name;
        float score;
        bool enrolling;                  // collecting templates for manual registration
        std::string enrollId, enrollName;
        std::vector<FloatVec> enrollEmbs;
        Track() : id(0), det(), bx0(0.f), by0(0.f), bx1(0.f), by1(0.f), missed(0), age(0),
                  lastRecog(-100), streak(0), confirmed(false), reported(false), score(0.f),
                  enrolling(false) {}      // det() value-initialises: every coordinate starts at 0
    };
    struct Match { std::string id, name; float score; bool ok; Match() : score(0.f), ok(false) {} };

    void   run();
    bool   init();
    void   post(const std::function<void()> &fn);
    void   runCommands();
    void   processFrame(RgbImage &img);
    Match  match(const FloatVec &e) const;
    bool   goodQuality(const FaceDet &f) const;
    bool   embedBest(const RgbImage &img, FloatVec &emb, std::string &err) const;
    void   addTemplate(const std::string &id, const std::string &name, const FloatVec &emb);
    void   doEnrollFiles(const std::string &id, const std::string &name, const std::vector<std::wstring> &files);
    void   setMessage(const std::string &msg);
    void   publishState();

    Camera      *m_cam;
    SharedState *m_st;
    HWND         m_hwnd;
    std::wstring m_dataDir, m_modelDir;

    std::thread       m_thread;
    std::atomic<bool> m_stop;
    std::mutex        m_cmdMutex;
    std::vector<std::function<void()> > m_cmds;

    FaceDetector   m_det;
    FaceRecognizer m_rec;
    Gallery        m_gal;
    AttendanceLog  m_att;
    bool           m_ready;
    bool           m_galLocked;         // gallery.bin was damaged and could not be moved aside: never write it
    int            m_detSize;
    float          m_detThr;
    std::atomic<float> m_thr;           // cosine threshold for "same person"
    std::atomic<bool>  m_ir;
    float          m_margin;            // best must beat the best OTHER person by this
    int            m_votes;             // agreeing frames needed before confirming
    std::vector<Track> m_tracks;
    int            m_nextId;
    unsigned long long m_seq;
};
